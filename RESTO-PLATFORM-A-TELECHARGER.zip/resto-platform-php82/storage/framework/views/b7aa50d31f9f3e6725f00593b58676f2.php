<?php $__env->startSection('title', 'Plan de salle — ' . $est->name); ?>

<?php $__env->startSection('head'); ?>
<style>
    .table-card { transition: all .15s; }
    .table-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.08); }
    .status-free { background:#f0fdf4; border-color:#bbf7d0; }
    .status-occupied { background:#eff6ff; border-color:#bfdbfe; }
    .status-order_sent { background:#fefce8; border-color:#fde68a; }
    .status-ready { background:#fef2f2; border-color:#fecaca; }
    .status-bill_requested { background:#f5f3ff; border-color:#ddd6fe; }
    .status-to_clean { background:#f8fafc; border-color:#e2e8f0; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="min-h-screen flex">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex-1 flex flex-col min-w-0">
        <?php echo $__env->make('partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                            <div>
                                <h1 class="text-2xl font-bold">Plan de salle</h1>
                                <p class="text-gray-500 text-sm">Cliquez sur une table pour prendre une commande</p>
                            </div>
                            <div class="flex items-center gap-3">
                                <!-- IA-07 : commande vocale -->
                                <button id="voiceBtn" onclick="toggleVoice()" class="px-3 py-2 rounded-lg text-sm font-medium bg-white border hover:bg-gray-50" title="Commande vocale">
                                    🎤 <span id="voiceLabel">Commande vocale</span>
                                </button>
                                <div class="hidden lg:flex gap-3 text-xs">
                                    <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-green-100 border border-green-300"></span> Libre</span>
                                    <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-blue-100 border border-blue-300"></span> Occupée</span>
                                    <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-yellow-100 border border-yellow-300"></span> En cuisine</span>
                                    <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-red-100 border border-red-300"></span> Plat prêt</span>
                                    <span class="flex items-center gap-1"><span class="w-3 h-3 rounded bg-purple-100 border border-purple-300"></span> Addition</span>
                                </div>
                            </div>
                        </div>

            <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-8">
                    <h2 class="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                        <span class="text-brand-600">▮</span> <?php echo e($zone->name); ?>

                    </h2>
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                        <?php $__currentLoopData = $zone->tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $order = $activeOrders->get($table->id)?->first();
                                $status = $order ? $order->status : $table->status;
                                $statusClass = 'status-' . $status;
                                $itemCount = $order ? $order->items->count() : 0;
                            ?>
                            <button
                                                            onclick="openOrder(<?php echo e($table->id); ?>, '<?php echo e($table->name); ?>', '<?php echo e($table->qr_token); ?>')"
                                                            class="table-card border-2 rounded-xl p-4 text-left <?php echo e($statusClass); ?>">
                                                            <div class="flex items-center justify-between mb-2">
                                                                <span class="font-bold text-lg"><?php echo e($table->name); ?></span>
                                                                <span class="flex items-center gap-2">
                                                                    <a href="<?php echo e(route('client.menu', $table->qr_token)); ?>" target="_blank" class="text-[11px] bg-white rounded px-2 py-1 font-medium text-brand-700 hover:bg-brand-50" title="Ouvrir le menu de la table">📱 Menu</a>
                                                                    <span class="text-xs text-gray-400"><?php echo e($table->capacity); ?> pers.</span>
                                                                </span>
                                                            </div>
                                                            <?php if($order): ?>
                                                                <p class="text-xs text-gray-600 font-medium"><?php echo e($order->order_number); ?></p>
                                                                <p class="text-xs text-gray-500"><?php echo e($itemCount); ?> article(s)</p>
                                                                <p class="text-xs font-semibold text-brand-700 mt-1"><?php echo e(number_format($order->total, 0, ',', ' ')); ?> FCFA</p>
                                                            <?php else: ?>
                                                            <p class="text-xs text-gray-400">Table libre</p>
                                                        <?php endif; ?>
                                                    </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>
</div>

<!-- Modal de commande -->
<div id="orderModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="closeOrder()"></div>
    <div class="absolute inset-y-0 right-0 w-full max-w-2xl bg-white shadow-2xl flex flex-col">
        <div class="p-4 border-b flex items-center justify-between bg-brand-800 text-white">
                    <div>
                        <h2 class="font-bold text-lg" id="modalTitle">Commande</h2>
                        <p class="text-xs text-brand-200" id="modalOrderInfo"></p>
                    </div>
                    <div class="flex items-center gap-3">
                        <a id="qrLink" href="#" target="_blank" class="text-xs bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg transition">
                            📱 Menu client
                        </a>
                        <button onclick="closeOrder()" class="text-white/70 hover:text-white text-2xl">&times;</button>
                    </div>
                </div>

                <!-- Accès menu client -->
                <div class="px-4 py-3 bg-gray-50 border-b flex items-center gap-3">
                    <span class="text-xl">📱</span>
                    <div class="flex-1">
                        <p class="text-sm font-semibold">Menu client de la table</p>
                        <p class="text-xs text-gray-500">Ouvrez le menu pour commander depuis un téléphone</p>
                    </div>
                    <a id="qrLink2" href="#" target="_blank" class="text-xs text-brand-600 font-medium hover:underline whitespace-nowrap">Ouvrir →</a>
                </div>

        <div class="flex-1 flex min-h-0">
            <!-- Catalogue -->
            <div class="w-1/2 border-r flex flex-col min-h-0">
                <div class="p-3">
                    <input id="searchInput" oninput="filterProducts()" placeholder="🔍 Rechercher un plat..."
                        class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div class="flex gap-1 px-3 pb-2 overflow-x-auto scrollbar-thin">
                    <button onclick="filterCategory('all')" data-cat="all" class="cat-btn px-3 py-1.5 rounded-full text-xs font-medium bg-brand-600 text-white">Tous</button>
                    <?php $__currentLoopData = $est->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button onclick="filterCategory('<?php echo e($cat->id); ?>')" data-cat="<?php echo e($cat->id); ?>" class="cat-btn px-3 py-1.5 rounded-full text-xs font-medium bg-gray-100 hover:bg-gray-200"><?php echo e($cat->name); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div id="productGrid" class="flex-1 overflow-y-auto p-3 grid grid-cols-2 gap-2 content-start scrollbar-thin">
                    <?php $__currentLoopData = $est->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button data-cat="<?php echo e($p->category_id); ?>" data-name="<?php echo e(strtolower($p->name)); ?>"
                            onclick="addToCart(<?php echo e($p->id); ?>, '<?php echo e(addslashes($p->name)); ?>', <?php echo e($p->price); ?>, <?php echo e($p->station_id ?? 'null'); ?>)"
                            class="product-card border rounded-lg p-3 text-left hover:border-brand-500 hover:bg-brand-50 transition <?php echo e($p->is_available ? '' : 'opacity-40'); ?>">
                            <p class="font-medium text-sm"><?php echo e($p->name); ?></p>
                            <p class="text-xs text-gray-500"><?php echo e(number_format($p->price, 0, ',', ' ')); ?> FCFA</p>
                            <?php if($p->spice_level > 0): ?>
                                <p class="text-xs text-red-500"><?php echo e(str_repeat('🌶️', $p->spice_level)); ?></p>
                            <?php endif; ?>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Panier -->
            <div class="w-1/2 flex flex-col min-h-0">
                <div class="p-3 border-b flex items-center justify-between">
                    <span class="font-semibold">Panier</span>
                    <span class="text-xs text-gray-500" id="cartCount">0 article</span>
                </div>
                <div id="cartItems" class="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin"></div>
                <div class="p-3 border-t space-y-2">
                    <div class="flex justify-between text-sm">
                        <span>Sous-total</span><span id="subtotal">0 FCFA</span>
                    </div>
                    <div class="flex justify-between font-bold text-lg">
                        <span>Total</span><span id="total" class="text-brand-700">0 FCFA</span>
                    </div>
                    <button onclick="placeOrder()" class="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-semibold rounded-lg">
                        Envoyer en cuisine →
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let currentTableId = null;
let currentOrderId = null;
let cart = [];

function openOrder(tableId, tableName, qrToken) {
    currentTableId = tableId;
    if (document.getElementById('modalTitle')) document.getElementById('modalTitle').textContent = 'Table ' + tableName;
    if (document.getElementById('modalOrderInfo')) document.getElementById('modalOrderInfo').textContent = 'Nouvelle commande';
    // Ouvrir le menu client (sans QR image) — liens optionnels
    const menuUrl = '/m/' + qrToken;
    if (document.getElementById('qrLink')) document.getElementById('qrLink').href = menuUrl;
    if (document.getElementById('qrLink2')) document.getElementById('qrLink2').href = menuUrl;
    const modal = document.getElementById('orderModal');
    if (modal) modal.classList.remove('hidden');
    cart = [];
    renderCart();
}

function closeOrder() {
    document.getElementById('orderModal').classList.add('hidden');
    currentTableId = null;
    currentOrderId = null;
}

function addToCart(productId, name, price, stationId) {
    const existing = cart.find(c => c.product_id === productId);
    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ product_id: productId, name, price, station_id: stationId, quantity: 1, notes: '' });
    }
    renderCart();
}

function changeQty(index, delta) {
    cart[index].quantity += delta;
    if (cart[index].quantity <= 0) cart.splice(index, 1);
    renderCart();
}

function renderCart() {
    const container = document.getElementById('cartItems');
    const count = cart.reduce((s, c) => s + c.quantity, 0);
    const subtotal = cart.reduce((s, c) => s + c.price * c.quantity, 0);
    document.getElementById('cartCount').textContent = count + ' article(s)';
    document.getElementById('subtotal').textContent = subtotal.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('total').textContent = subtotal.toLocaleString('fr-FR') + ' FCFA';

    container.innerHTML = cart.map((c, i) => `
        <div class="flex items-center justify-between bg-gray-50 rounded-lg p-2">
            <div class="flex-1">
                <p class="text-sm font-medium">${c.name}</p>
                <p class="text-xs text-gray-500">${c.price.toLocaleString('fr-FR')} FCFA</p>
            </div>
            <div class="flex items-center gap-2">
                <button onclick="changeQty(${i}, -1)" class="w-6 h-6 bg-gray-200 rounded hover:bg-gray-300">−</button>
                <span class="w-6 text-center text-sm font-semibold">${c.quantity}</span>
                <button onclick="changeQty(${i}, 1)" class="w-6 h-6 bg-gray-200 rounded hover:bg-gray-300">+</button>
            </div>
        </div>
    `).join('');
}

async function placeOrder() {
    if (cart.length === 0) return;
    // 1. Créer / récupérer la commande
    const res = await fetch('/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
        body: JSON.stringify({ table_id: currentTableId, channel: 'dine_in', guest_count: 1 })
    });
    const { order } = await res.json();
    currentOrderId = order.id;

    // 2. Ajouter les articles
    for (const item of cart) {
        await fetch('/orders/' + order.id + '/items', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
            body: JSON.stringify({ product_id: item.product_id, quantity: item.quantity, notes: item.notes })
        });
    }

    // 3. Envoyer en cuisine
    await fetch('/orders/' + order.id + '/send', {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' }
    });

    closeOrder();
    location.reload();
}

function filterProducts() {
    const q = document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('.product-card').forEach(card => {
        const name = card.dataset.name;
        card.style.display = name.includes(q) ? '' : 'none';
    });
}

function filterCategory(catId) {
    document.querySelectorAll('.cat-btn').forEach(b => {
        b.classList.toggle('bg-brand-600', b.dataset.cat === catId);
        b.classList.toggle('text-white', b.dataset.cat === catId);
        b.classList.toggle('bg-gray-100', b.dataset.cat !== catId);
    });
    document.querySelectorAll('.product-card').forEach(card => {
        card.style.display = (catId === 'all' || card.dataset.cat === catId) ? '' : 'none';
    });
}

// IA-07 : commande vocale (Web Speech API)
let recognition = null;
let voiceActive = false;
function toggleVoice() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert('La reconnaissance vocale n\'est pas supportée par ce navigateur. Utilisez Chrome.');
        return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!recognition) {
        recognition = new SR();
        recognition.lang = 'fr-FR';
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.onresult = (e) => {
            const text = e.results[0][0].transcript.toLowerCase();
            document.getElementById('voiceLabel').textContent = 'Commande vocale';
            voiceActive = false;
            document.getElementById('voiceBtn').classList.remove('bg-brand-600', 'text-white');
            // Chercher un produit correspondant dans le catalogue
            const cards = document.querySelectorAll('.product-card');
            let found = null;
            cards.forEach(card => {
                if (card.dataset.name.includes(text.trim()) || text.includes(card.dataset.name)) {
                    found = card;
                }
            });
            if (found) {
                found.click();
                alert('🎤 Ajouté : ' + found.querySelector('p').textContent);
            } else {
                alert('🎤 Aucun produit trouvé pour : "' + text + '"');
            }
        };
        recognition.onerror = () => {
            document.getElementById('voiceLabel').textContent = 'Commande vocale';
            voiceActive = false;
            document.getElementById('voiceBtn').classList.remove('bg-brand-600', 'text-white');
        };
    }
    if (voiceActive) {
        recognition.stop();
        voiceActive = false;
        document.getElementById('voiceLabel').textContent = 'Commande vocale';
        document.getElementById('voiceBtn').classList.remove('bg-brand-600', 'text-white');
    } else {
        recognition.start();
        voiceActive = true;
        document.getElementById('voiceLabel').textContent = '🎤 Écoute...';
        document.getElementById('voiceBtn').classList.add('bg-brand-600', 'text-white');
    }
}

// Temps réel SSE
function connectSSE() {
    const es = new EventSource('/sse');
    // Ne recharge la page que si aucune modal n'est ouverte,
    // sinon la fenêtre de commande se fermerait au rechargement.
    const reloadIfNoModal = () => {
        const modal = document.getElementById('orderModal');
        if (modal && !modal.classList.contains('hidden')) return;
        location.reload();
    };
    es.addEventListener('order.sent', reloadIfNoModal);
    es.addEventListener('table.status', reloadIfNoModal);
    es.addEventListener('item.status', reloadIfNoModal);
    es.addEventListener('order.paid', reloadIfNoModal);
    es.onerror = () => { es.close(); setTimeout(connectSSE, 3000); };
}
connectSSE();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/resto-platform-php82/resources/views/floor/index.blade.php ENDPATH**/ ?>