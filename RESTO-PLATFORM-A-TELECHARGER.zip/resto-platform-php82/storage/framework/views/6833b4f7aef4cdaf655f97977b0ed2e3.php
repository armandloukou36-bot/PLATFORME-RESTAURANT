<header class="bg-white border-b border-gray-200 px-4 lg:px-6 py-3 flex items-center justify-between">
    <div class="flex items-center gap-3">
        <button @click="$store.sidebar.toggle()" class="lg:hidden text-gray-500 hover:text-brand-600 text-xl" title="Menu">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <span class="hidden sm:inline text-gray-400">📍</span>
        <span class="text-sm text-gray-600"><?php echo e(auth()->user()->establishment?->name ?? '—'); ?></span>
        <span class="text-xs text-gray-400">·</span>
        <span class="text-sm text-gray-500"><?php echo e(now()->format('H:i')); ?></span>
    </div>
    <div class="flex items-center gap-3">
        <span class="hidden sm:inline-flex items-center gap-1.5 text-xs text-green-600 bg-green-50 px-2.5 py-1 rounded-full">
            <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Connecté
        </span>
        <span class="text-sm font-medium text-gray-700 hidden md:inline">
            <?php echo e(auth()->user()->name); ?>

            <span class="text-xs text-gray-400 capitalize">(<?php echo e(auth()->user()->role); ?>)</span>
        </span>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" title="Se déconnecter"
                class="inline-flex items-center gap-1.5 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-sm font-medium transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
                <span class="hidden sm:inline">Déconnexion</span>
            </button>
        </form>
    </div>
</header>
<?php /**PATH /root/resto-platform-php82/resources/views/partials/topbar.blade.php ENDPATH**/ ?>