<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Resto Platform'); ?></title>
    <script src="<?php echo e(asset('vendor/tailwind/cdn.js')); ?>"></script>
    <script defer src="<?php echo e(asset('vendor/alpine/cdn.min.js')); ?>"></script>
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.store('sidebar', {
                open: <?php echo e(auth()->check() && in_array(auth()->user()->role, ['superadmin', 'manager']) ? 'true' : 'false'); ?>,
                toggle() { this.open = !this.open; },
                close() { this.open = false; }
            });
        });
    </script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50:'#eef2ff',100:'#e0e7ff',500:'#6366f1',600:'#4f46e5',700:'#4338ca',800:'#3730a3' },
                        accent: { 400:'#fbbf24',500:'#f59e0b',600:'#d97706' }
                    }
                }
            }
        }
    </script>
    <style>
        [x-cloak]{display:none!important}
        .scrollbar-thin::-webkit-scrollbar{width:6px;height:6px}
        .scrollbar-thin::-webkit-scrollbar-thumb{background:#c7c7c7;border-radius:3px}
    </style>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="bg-gray-100 text-gray-900 antialiased">
    <?php echo $__env->yieldContent('body'); ?>

    <!-- Fond assombri mobile quand la sidebar est ouverte -->
    <div x-show="$store.sidebar.open" @click="$store.sidebar.close()"
         class="fixed inset-0 z-30 bg-black/40 lg:hidden" x-cloak></div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /root/resto-platform-php82/resources/views/layouts/app.blade.php ENDPATH**/ ?>