<?php $__env->startSection('title', 'Intelligence — ' . $est->name); ?>

<?php $__env->startSection('body'); ?>
<div class="min-h-screen flex">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex-1 flex flex-col min-w-0">
        <?php echo $__env->make('partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Intelligence</h1>
                    <p class="text-gray-500 text-sm">Prévisions, commandes suggérées, menu engineering</p>
                </div>
                <a href="<?php echo e(route('reservations')); ?>" class="px-4 py-2 bg-white border rounded-lg font-medium hover:bg-gray-50">Réservations</a>
            </div>

            <!-- IA-01 : Prévisions 7 jours -->
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden mb-6">
                <div class="px-4 py-3 bg-gray-50 font-semibold flex items-center justify-between">
                    <span>📈 Prévisions de ventes (7 jours)</span>
                    <span class="text-xs text-gray-400">IA-01</span>
                </div>
                <div class="p-4">
                    <div class="grid grid-cols-7 gap-2">
                        <?php $__currentLoopData = $weekForecast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-3 rounded-lg border <?php echo e($f['confidence'] === 'haute' ? 'bg-brand-50 border-brand-200' : 'bg-gray-50 border-gray-200'); ?>">
                                <p class="text-xs text-gray-500 font-medium"><?php echo e(\Carbon\Carbon::parse($f['date'])->translatedFormat('D d/m')); ?></p>
                                <p class="text-lg font-bold text-brand-700 mt-1"><?php echo e(number_format($f['revenue_forecast'], 0, ',', ' ')); ?></p>
                                <p class="text-xs text-gray-400">FCFA · <?php echo e($f['orders_forecast']); ?> cmd</p>
                                <span class="text-[10px] px-1.5 py-0.5 rounded mt-1 inline-block
                                    <?php echo e($f['confidence'] === 'haute' ? 'bg-green-100 text-green-700' : ($f['confidence'] === 'moyenne' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-500')); ?>">
                                    conf. <?php echo e($f['confidence']); ?>

                                </span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="grid lg:grid-cols-2 gap-6">
                <!-- IA-02 : Commandes fournisseurs suggérées -->
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <div class="px-4 py-3 bg-gray-50 font-semibold flex items-center justify-between">
                        <span>📦 Commandes fournisseurs suggérées</span>
                        <span class="text-xs text-gray-400">IA-02</span>
                    </div>
                    <div class="p-4">
                        <?php $__empty_1 = true; $__currentLoopData = $purchaseSuggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex items-center justify-between py-2 border-b border-gray-50">
                                <div>
                                    <p class="font-medium text-sm"><?php echo e($s['ingredient']); ?></p>
                                    <p class="text-xs text-gray-400"><?php echo e($s['stock_qty']); ?> <?php echo e($s['unit']); ?> en stock · couvre <?php echo e($s['stock_days']); ?>j</p>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold text-red-600">Commander <?php echo e($s['to_order']); ?> <?php echo e($s['unit']); ?></p>
                                    <p class="text-xs text-gray-400">cons. <?php echo e($s['daily_use']); ?>/jour</p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-400 text-sm">Aucune commande nécessaire — stock suffisant.</p>
                            <p class="text-xs text-gray-400 mt-2">Les suggestions apparaissent quand un ingrédient couvre moins de 7 jours de consommation.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- IA-06 : Menu engineering -->
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <div class="px-4 py-3 bg-gray-50 font-semibold flex items-center justify-between">
                        <span>🍽️ Menu engineering</span>
                        <span class="text-xs text-gray-400">IA-06</span>
                    </div>
                    <div class="p-4">
                        <?php if(empty($menuMatrix)): ?>
                            <p class="text-gray-400 text-sm">Pas assez de données de vente. Le classement apparaîtra après quelques commandes payées.</p>
                        <?php else: ?>
                        <div class="grid grid-cols-2 gap-3">
                            <?php
                                $config = [
                                    'star' => ['⭐', 'Stars', 'Forts et populaires — mettez en avant', 'bg-green-50 border-green-200'],
                                    'cash_cow' => ['🐄', 'Vaches à lait', 'Rentables, peu vendus — à promouvoir', 'bg-blue-50 border-blue-200'],
                                    'puzzle' => ['🧩', 'Énigmes', 'Populaires mais peu rentables — à re-pricer', 'bg-amber-50 border-amber-200'],
                                    'dog' => ['🐕', 'Poids morts', 'Peu vendus et peu rentables — à retirer', 'bg-gray-50 border-gray-200'],
                                ];
                            ?>
                            <?php $__currentLoopData = $config; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => [$icon, $title, $desc, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-3 rounded-lg border <?php echo e($color); ?>">
                                    <p class="font-semibold text-sm"><?php echo e($icon); ?> <?php echo e($title); ?></p>
                                    <p class="text-[11px] text-gray-500 mb-2"><?php echo e($desc); ?></p>
                                    <?php $__currentLoopData = $menuGroups->get($key, collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="text-sm flex justify-between"><span><?php echo e($item['name']); ?></span><span class="text-gray-400"><?php echo e($item['qty']); ?> vds</span></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($menuGroups->get($key, collect())->isEmpty()): ?>
                                        <p class="text-xs text-gray-400">—</p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/resto-platform-php82/resources/views/intelligence/index.blade.php ENDPATH**/ ?>