<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($est->name); ?> — Menu</title>
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f9fafb;color:#111827}
        .header{background:#4f46e5;color:#fff;padding:24px 16px}
        .header h1{font-size:22px;font-weight:700}
        .header p{color:#c7d2fe;font-size:13px;margin-top:4px}
        .wrap{max-width:512px;margin:0 auto;padding:16px;padding-bottom:120px}
        .cats{display:flex;gap:8px;overflow-x:auto;margin-bottom:16px;padding-bottom:4px}
        .cat{white-space:nowrap;padding:8px 16px;border-radius:999px;font-size:13px;font-weight:500;border:1px solid #e5e7eb;background:#fff;cursor:pointer}
        .cat.active{background:#4f46e5;color:#fff;border-color:#4f46e5}
        .prod{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;display:flex;gap:12px;margin-bottom:12px}
        .prod .info{flex:1}
        .prod h3{font-size:15px;font-weight:600}
        .prod .desc{color:#6b7280;font-size:13px;margin-top:2px}
        .prod .meta{color:#9ca3af;font-size:12px;margin-top:4px}
        .prod .allergen{color:#dc2626;font-size:12px;margin-top:4px}
        .prod .price{color:#4f46e5;font-weight:700;margin-top:8px}
        .add{width:40px;height:40px;border-radius:50%;background:#4f46e5;color:#fff;font-size:22px;font-weight:700;border:none;cursor:pointer;align-self:center;flex-shrink:0}
        .add:active{transform:scale(.95)}
        .cartbar{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid #e5e7eb;padding:16px;box-shadow:0 -4px 12px rgba(0,0,0,.08)}
        .cartbar .inner{max-width:512px;margin:0 auto}
        .cartbtn{width:100%;padding:14px;background:#4f46e5;color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:600;display:flex;justify-content:space-between;align-items:center;cursor:pointer}
        .badge{background:#fff;color:#4f46e5;padding:2px 10px;border-radius:999px;font-weight:700;font-size:13px}
        .overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:50;display:none}
        .panel{position:fixed;bottom:0;left:0;right:0;max-width:512px;margin:0 auto;background:#fff;border-radius:16px 16px 0 0;padding:24px;z-index:51;max-height:80vh;overflow-y:auto;display:none}
        .panel h2{font-size:18px;font-weight:700;margin-bottom:16px}
        .cartitem{display:flex;justify-content:space-between;align-items:center;background:#f9fafb;border-radius:8px;padding:8px;margin-bottom:8px}
        .cartitem .nm{font-size:14px;font-weight:500}
        .cartitem .pr{color:#6b7280;font-size:12px}
        .qty{display:flex;align-items:center;gap:8px}
        .qty button{width:24px;height:24px;border-radius:6px;border:1px solid #d1d5db;background:#fff;cursor:pointer;font-weight:700}
        .qty span{width:24px;text-align:center;font-weight:600}
        .total{display:flex;justify-content:space-between;font-size:20px;font-weight:700;margin:16px 0}
        .total .v{color:#4f46e5}
        .sugg{background:#eef2ff;border:1px solid #c7d2fe;border-radius:8px;padding:12px;margin-bottom:12px}
        .sugg p{font-size:13px;font-weight:600;color:#4338ca;margin-bottom:8px}
        .sugg button{width:100%;display:flex;justify-content:space-between;background:#fff;border:1px solid #c7d2fe;border-radius:8px;padding:8px;margin-bottom:6px;font-size:13px;cursor:pointer}
        .sugg button .p{color:#4f46e5;font-weight:600}
        label{display:block;font-size:13px;font-weight:500;margin-bottom:4px}
        input{width:100%;padding:10px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;margin-bottom:12px}
        .confirm{width:100%;padding:14px;background:#16a34a;color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:600;cursor:pointer}
        .close{float:right;font-size:24px;color:#9ca3af;background:none;border:none;cursor:pointer}
        .track{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:60;display:none;align-items:center;justify-content:center;padding:16px}
        .trackcard{background:#fff;border-radius:16px;padding:24px;max-width:400px;width:100%;text-align:center}
        .trackcard h2{font-size:18px;font-weight:700;margin:8px 0}
        .step{display:flex;align-items:center;gap:8px;text-align:left;margin:8px 0;font-size:14px}
        .dot{width:20px;height:20px;border-radius:50%;background:#e5e7eb;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;flex-shrink:0}
        .dot.done{background:#16a34a}
        .again{width:100%;padding:12px;background:#4f46e5;color:#fff;border:none;border-radius:10px;font-weight:600;margin-top:12px;cursor:pointer}
    </style>
</head>
<body>
    <div class="header">
        <div class="wrap" style="padding:0">
            <h1><?php echo e($est->name); ?></h1>
            <p>Table <?php echo e($table->name); ?> · Scannez le QR pour commander</p>
        </div>
    </div>

    <div class="wrap">
        <div class="cats" id="cats">
            <button class="cat active" data-cat="all">Tout</button>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="cat" data-cat="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div id="products">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="prod" data-cat="<?php echo e($p->category_id); ?>">
                    <div class="info">
                        <h3><?php echo e($p->name); ?> <?php if($p->spice_level > 0): ?><?php echo e(str_repeat('🌶️', $p->spice_level)); ?><?php endif; ?></h3>
                        <p class="desc"><?php echo e($p->description); ?></p>
                        <p class="meta">⏱️ ~<?php echo e($p->prep_time_min); ?> min</p>
                        <?php if(!empty($p->allergens)): ?><p class="allergen">⚠️ Allergènes : <?php echo e(implode(', ', $p->allergens)); ?></p><?php endif; ?>
                        <p class="price"><?php echo e(number_format($p->price, 0, ',', ' ')); ?> FCFA</p>
                    </div>
                    <button class="add" onclick="addToCart(<?php echo e($p->id); ?>, '<?php echo e(addslashes($p->name)); ?>', <?php echo e($p->price); ?>, '<?php echo e($p->category?->name); ?>')">+</button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="cartbar">
        <div class="inner">
            <button class="cartbtn" onclick="toggleCart()">
                <span>🛒 Voir le panier</span>
                <span class="badge" id="badge">0</span>
            </button>
        </div>
    </div>

    <div class="overlay" id="overlay" onclick="toggleCart()"></div>
    <div class="panel" id="panel">
        <button class="close" onclick="toggleCart()">&times;</button>
        <h2>Votre commande</h2>
        <div id="cartItems"></div>
        <div class="total"><span>Total</span><span class="v" id="cartTotal">0 FCFA</span></div>
        <div class="sugg" id="sugg" style="display:none">
            <p>💡 Vous pourriez aimer :</p>
            <div id="suggItems"></div>
        </div>
        <label>Votre téléphone (pour la fidélité)</label>
        <input id="phone" placeholder="+225 07 00 00 00 00">
        <button class="confirm" onclick="placeOrder()">Confirmer la commande</button>
    </div>

    <div class="track" id="track">
        <div class="trackcard">
            <p style="font-size:36px">🍽️</p>
            <h2>Commande envoyée !</h2>
            <p style="color:#6b7280;font-size:14px;margin-bottom:12px">N° <b id="trackNum"></b></p>
            <div class="step"><span class="dot done">✓</span> Commande reçue</div>
            <div class="step"><span class="dot" id="s2">•</span> En préparation</div>
            <div class="step"><span class="dot" id="s3">•</span> Prête</div>
            <div class="step"><span class="dot" id="s4">•</span> Servie</div>
            <button class="again" onclick="location.reload()">Commander à nouveau</button>
        </div>
    </div>

<script>
let cart = [];
let orderId = null;
const allProducts = <?php echo $productsJson; ?>;

// Filtre par catégorie (JS pur, sans Alpine)
document.querySelectorAll('.cat').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.cat').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.dataset.cat;
        document.querySelectorAll('.prod').forEach(p => {
            p.style.display = (cat === 'all' || p.dataset.cat === cat) ? '' : 'none';
        });
    });
});

function addToCart(id, name, price, category) {
    const ex = cart.find(c => c.product_id === id);
    if (ex) ex.quantity++;
    else cart.push({ product_id: id, name, price, category, quantity: 1 });
    renderCart();
    renderSugg();
}

function changeQty(i, d) {
    cart[i].quantity += d;
    if (cart[i].quantity <= 0) cart.splice(i, 1);
    renderCart();
    renderSugg();
}

function renderCart() {
    const count = cart.reduce((s, c) => s + c.quantity, 0);
    const total = cart.reduce((s, c) => s + c.price * c.quantity, 0);
    document.getElementById('badge').textContent = count;
    document.getElementById('cartTotal').textContent = total.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('cartItems').innerHTML = cart.map((c, i) => `
        <div class="cartitem">
            <div><p class="nm">${c.name}</p><p class="pr">${c.price.toLocaleString('fr-FR')} FCFA</p></div>
            <div class="qty">
                <button onclick="changeQty(${i},-1)">−</button>
                <span>${c.quantity}</span>
                <button onclick="changeQty(${i},1)">+</button>
            </div>
        </div>`).join('');
}

function renderSugg() {
    const mainCats = ['Plats', 'Grillades', 'Poissons'];
    const ids = cart.map(c => c.product_id);
    const hasMain = cart.some(c => mainCats.includes(c.category));
    const hasDessert = cart.some(c => c.category === 'Desserts');
    const hasDrink = cart.some(c => ['Boissons', 'Cocktails'].includes(c.category));
    const hasStarter = cart.some(c => c.category === 'Entrées');
    const sugg = [];
    if (hasMain && !hasDessert) { const d = allProducts.find(p => p.category === 'Desserts' && !ids.includes(p.id)); if (d) sugg.push(['🍰', d]); }
    if (!hasDrink) { const d = allProducts.find(p => p.category === 'Boissons' && !ids.includes(p.id)); if (d) sugg.push(['🥤', d]); }
    if (hasMain && !hasStarter) { const d = allProducts.find(p => p.category === 'Entrées' && !ids.includes(p.id)); if (d) sugg.push(['🥗', d]); }
    const box = document.getElementById('sugg');
    if (sugg.length === 0) { box.style.display = 'none'; return; }
    box.style.display = '';
    document.getElementById('suggItems').innerHTML = sugg.map(([ic, p]) =>
        `<button onclick="addToCart(${p.id},'${p.name}',${p.price},'${p.category}')"><span>${ic} ${p.name}</span><span class="p">+${p.price.toLocaleString('fr-FR')}</span></button>`
    ).join('');
}

function toggleCart() {
    const p = document.getElementById('panel');
    const o = document.getElementById('overlay');
    const show = p.style.display === 'none' || p.style.display === '';
    p.style.display = show ? 'block' : 'none';
    o.style.display = show ? 'block' : 'none';
}

async function placeOrder() {
    if (cart.length === 0) return;
    const phone = document.getElementById('phone').value;
    const res = await fetch('/m/<?php echo e($table->qr_token); ?>/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
        body: JSON.stringify({ items: cart.map(c => ({ product_id: c.product_id, quantity: c.quantity })), customer_phone: phone })
    });
    const data = await res.json();
    orderId = data.order_id;
    document.getElementById('trackNum').textContent = data.order_number;
    document.getElementById('panel').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
    document.getElementById('track').style.display = 'flex';
    startTracking();
}

function startTracking() {
    setInterval(async () => {
        const res = await fetch('/m/order/' + orderId + '/track');
        const data = await res.json();
        const statuses = ['open', 'sent', 'in_progress', 'ready', 'served', 'paid'];
        const idx = statuses.indexOf(data.status);
        const steps = [document.getElementById('s2'), document.getElementById('s3'), document.getElementById('s4')];
        steps.forEach((s, i) => {
            if (i + 1 <= Math.min(idx, 3)) { s.className = 'dot done'; s.textContent = '✓'; }
        });
    }, 3000);
}
</script>
</body>
</html>
<?php /**PATH /root/resto-platform-php82/resources/views/client/menu.blade.php ENDPATH**/ ?>