<?php $__env->startSection('title', 'Expansion — ' . $est->name); ?>

<?php $__env->startSection('body'); ?>
<div class="min-h-screen flex" x-data="{ tab: 'delivery' }">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex-1 flex flex-col min-w-0">
        <?php echo $__env->make('partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h1 class="text-2xl font-bold">Expansion</h1>
                    <p class="text-gray-500 text-sm">Livraison, tarification dynamique, mode événement</p>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <!-- Onglets -->
            <div class="flex gap-1 bg-gray-200 p-1 rounded-lg mb-6 w-fit">
                <button @click="tab='delivery'" :class="tab==='delivery' ? 'bg-white shadow' : 'text-gray-600'" class="px-4 py-2 rounded-md text-sm font-medium">🛵 Livraison</button>
                <button @click="tab='pricing'" :class="tab==='pricing' ? 'bg-white shadow' : 'text-gray-600'" class="px-4 py-2 rounded-md text-sm font-medium">🏷️ Tarifs dynamiques</button>
                <button @click="tab='event'" :class="tab==='event' ? 'bg-white shadow' : 'text-gray-600'" class="px-4 py-2 rounded-md text-sm font-medium">🎉 Événements</button>
            </div>

            <!-- ===== LIVRAISON ===== -->
            <div x-show="tab==='delivery'" x-cloak>
                <div class="grid lg:grid-cols-3 gap-4 mb-4">
                    <!-- Commandes à livrer -->
                    <div class="bg-white rounded-xl border border-gray-200 p-4 lg:col-span-2">
                        <h2 class="font-semibold mb-3">📦 Commandes en attente de livraison</h2>
                        <?php $__empty_1 = true; $__currentLoopData = $pendingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex items-center justify-between py-2 border-b border-gray-50">
                                <div>
                                    <p class="font-medium text-sm"><?php echo e($o->order_number); ?> — <?php echo e($o->total); ?> FCFA</p>
                                    <p class="text-xs text-gray-400"><?php echo e($o->items->count()); ?> article(s) · <?php echo e($o->customer_name ?? 'Client'); ?></p>
                                </div>
                                <button onclick="document.getElementById('dlv-<?php echo e($o->id); ?>').classList.remove('hidden')" class="text-xs bg-brand-600 text-white px-3 py-1.5 rounded-lg">Créer la livraison</button>
                            </div>

                            <!-- Modal création livraison -->
                            <div id="dlv-<?php echo e($o->id); ?>" class="fixed inset-0 z-50 hidden">
                                <div class="absolute inset-0 bg-black/50" onclick="this.closest('#dlv-<?php echo e($o->id); ?>').classList.add('hidden')"></div>
                                <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl p-6">
                                    <h3 class="font-bold mb-4">Livraison <?php echo e($o->order_number); ?></h3>
                                    <form method="POST" action="<?php echo e(route('expansion.deliveries.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="order_id" value="<?php echo e($o->id); ?>">
                                        <div class="space-y-3 text-sm">
                                            <div class="grid grid-cols-2 gap-2">
                                                <div><label class="block text-xs font-medium mb-1">Contact</label><input name="contact_name" required class="w-full px-3 py-2 border rounded-lg"></div>
                                                <div><label class="block text-xs font-medium mb-1">Téléphone</label><input name="contact_phone" required class="w-full px-3 py-2 border rounded-lg"></div>
                                            </div>
                                            <div><label class="block text-xs font-medium mb-1">Adresse</label><input name="address" required class="w-full px-3 py-2 border rounded-lg"></div>
                                            <div class="grid grid-cols-2 gap-2">
                                                <div><label class="block text-xs font-medium mb-1">Ville</label><input name="city" class="w-full px-3 py-2 border rounded-lg"></div>
                                                <div><label class="block text-xs font-medium mb-1">Point de repère</label><input name="landmark" class="w-full px-3 py-2 border rounded-lg"></div>
                                            </div>
                                            <div class="grid grid-cols-2 gap-2">
                                                <div>
                                                    <label class="block text-xs font-medium mb-1">Livreur</label>
                                                    <select name="courier_id" class="w-full px-3 py-2 border rounded-lg">
                                                        <option value="">—</option>
                                                        <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div><label class="block text-xs font-medium mb-1">Frais (FCFA)</label><input name="delivery_fee" type="number" min="0" value="1000" class="w-full px-3 py-2 border rounded-lg"></div>
                                            </div>
                                        </div>
                                        <div class="flex gap-2 mt-4">
                                            <button type="button" onclick="this.closest('[id^=dlv-]').classList.add('hidden')" class="flex-1 py-2 border rounded-lg">Annuler</button>
                                            <button type="submit" class="flex-1 py-2 bg-brand-600 text-white rounded-lg font-medium">Créer</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-400 text-sm">Aucune commande de livraison en attente.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Ajouter livreur + liste -->
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">🛵 Livreurs</h2>
                        <form method="POST" action="<?php echo e(route('expansion.couriers.store')); ?>" class="mb-3">
                            <?php echo csrf_field(); ?>
                            <div class="flex gap-2">
                                <input name="name" placeholder="Nom" required class="flex-1 px-3 py-2 border rounded-lg text-sm">
                                <input name="phone" placeholder="Tél" required class="flex-1 px-3 py-2 border rounded-lg text-sm">
                            </div>
                            <button class="w-full mt-2 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">+ Ajouter</button>
                        </form>
                        <div class="space-y-1">
                            <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between py-1 border-b border-gray-50">
                                    <div>
                                        <p class="text-sm font-medium"><?php echo e($c->name); ?></p>
                                        <p class="text-xs text-gray-400"><?php echo e($c->vehicle ?? '—'); ?> · <?php echo e($c->deliveries_count); ?> course(s)</p>
                                    </div>
                                    <span class="text-xs <?php echo e($c->is_available ? 'text-green-600' : 'text-gray-400'); ?>"><?php echo e($c->is_available ? 'Disponible' : 'Occupé'); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($couriers->isEmpty()): ?><p class="text-gray-400 text-sm">Aucun livreur.</p><?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Livraisons en cours -->
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <div class="px-4 py-3 bg-gray-50 font-semibold">Livraisons (50 dernières)</div>
                    <table class="w-full text-sm">
                        <thead class="bg-gray-50 text-left text-gray-500">
                            <tr><th class="px-4 py-2">N°</th><th class="px-4 py-2">Livreur</th><th class="px-4 py-2">Adresse</th><th class="px-4 py-2 text-right">Frais</th><th class="px-4 py-2">Statut</th><th class="px-4 py-2 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-2 font-medium"><?php echo e($d->order?->order_number); ?></td>
                                    <td class="px-4 py-2"><?php echo e($d->courier?->name ?? '—'); ?></td>
                                    <td class="px-4 py-2 text-xs"><?php echo e($d->address); ?></td>
                                    <td class="px-4 py-2 text-right"><?php echo e(number_format($d->delivery_fee, 0)); ?></td>
                                    <td class="px-4 py-2">
                                        <form method="POST" action="<?php echo e(route('expansion.deliveries.status', $d)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <select name="status" onchange="this.form.submit()" class="text-xs border rounded px-2 py-1">
                                                <?php $__currentLoopData = ['pending','assigned','picked_up','in_transit','delivered','returned','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($s); ?>" <?php echo e($d->status===$s ? 'selected' : ''); ?>><?php echo e($s); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </form>
                                    </td>
                                    <td class="px-4 py-2 text-right text-xs">
                                        <?php if(in_array($d->status, ['in_transit', 'assigned']) && !$d->order?->paid_at): ?>
                                            <form method="POST" action="<?php echo e(route('expansion.deliveries.status', $d)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="delivered">
                                                <input type="hidden" name="payment_method" value="cash">
                                                <input type="hidden" name="collected_amount" value="<?php echo e($d->order?->total + $d->delivery_fee); ?>">
                                                <button class="text-green-600 font-medium">Encaisser & livrer</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if($deliveries->isEmpty()): ?><p class="p-4 text-center text-gray-400 text-sm">Aucune livraison.</p><?php endif; ?>
                </div>
            </div>

            <!-- ===== TARIFICATION DYNAMIQUE ===== -->
            <div x-show="tab==='pricing'" x-cloak>
                <div class="grid lg:grid-cols-2 gap-4">
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">🏷️ Règles de prix (IA-10)</h2>
                        <form method="POST" action="<?php echo e(route('expansion.prices.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="space-y-2 text-sm">
                                <div><label class="block text-xs font-medium mb-1">Nom de la règle</label><input name="name" value="Happy hour" required class="w-full px-3 py-2 border rounded-lg"></div>
                                <div class="grid grid-cols-2 gap-2">
                                    <div>
                                        <label class="block text-xs font-medium mb-1">Produit</label>
                                        <select name="product_id" class="w-full px-3 py-2 border rounded-lg">
                                            <option value="">Tous les produits</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium mb-1">Jour</label>
                                        <select name="day_of_week" class="w-full px-3 py-2 border rounded-lg">
                                            <?php $__currentLoopData = ['all'=>'Tous','monday'=>'Lundi','tuesday'=>'Mardi','wednesday'=>'Mercredi','thursday'=>'Jeudi','friday'=>'Vendredi','saturday'=>'Samedi','sunday'=>'Dimanche']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="grid grid-cols-3 gap-2">
                                    <div><label class="block text-xs font-medium mb-1">Début</label><input name="start_time" type="time" value="15:00" class="w-full px-3 py-2 border rounded-lg"></div>
                                    <div><label class="block text-xs font-medium mb-1">Fin</label><input name="end_time" type="time" value="18:00" class="w-full px-3 py-2 border rounded-lg"></div>
                                    <div><label class="block text-xs font-medium mb-1">-%</label><input name="discount_percent" type="number" min="0" max="90" value="20" required class="w-full px-3 py-2 border rounded-lg"></div>
                                </div>
                            </div>
                            <button class="w-full mt-3 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">Ajouter la règle</button>
                        </form>
                    </div>

                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">Règles actives</h2>
                        <?php $__empty_1 = true; $__currentLoopData = $priceRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="flex items-center justify-between py-2 border-b border-gray-50">
                                <div>
                                    <p class="text-sm font-medium"><?php echo e($r->name); ?> <span class="text-red-600 font-semibold">-<?php echo e($r->discount_percent); ?>%</span></p>
                                    <p class="text-xs text-gray-400"><?php echo e($r->product?->name ?? 'Tous produits'); ?> · <?php echo e(ucfirst($r->day_of_week)); ?> <?php echo e($r->start_time?->format('H:i')); ?>–<?php echo e($r->end_time?->format('H:i')); ?></p>
                                </div>
                                <form method="POST" action="<?php echo e(route('expansion.prices.toggle', $r)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="text-xs px-2 py-1 rounded <?php echo e($r->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'); ?>"><?php echo e($r->is_active ? 'Active' : 'Inactive'); ?></button>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-400 text-sm">Aucune règle de prix. Ajoutez une happy hour ci-contre.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- ===== MODE ÉVÉNEMENT ===== -->
            <div x-show="tab==='event'" x-cloak>
                <div class="grid lg:grid-cols-2 gap-4">
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">🎉 Créer un événement (INN-06)</h2>
                        <form method="POST" action="<?php echo e(route('expansion.events.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="space-y-2 text-sm">
                                <div><label class="block text-xs font-medium mb-1">Nom</label><input name="name" required class="w-full px-3 py-2 border rounded-lg"></div>
                                <div class="grid grid-cols-2 gap-2">
                                    <div><label class="block text-xs font-medium mb-1">Début</label><input name="starts_at" type="datetime-local" class="w-full px-3 py-2 border rounded-lg"></div>
                                    <div><label class="block text-xs font-medium mb-1">Fin</label><input name="ends_at" type="datetime-local" class="w-full px-3 py-2 border rounded-lg"></div>
                                </div>
                                <div><label class="block text-xs font-medium mb-1">Entrée (FCFA)</label><input name="entry_fee" type="number" min="0" value="5000" class="w-full px-3 py-2 border rounded-lg"></div>
                            </div>
                            <button class="w-full mt-3 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">Créer l'événement</button>
                        </form>
                    </div>

                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">Événements</h2>
                        <?php $__empty_1 = true; $__currentLoopData = $eventModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="py-2 border-b border-gray-50">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium"><?php echo e($e->name); ?></p>
                                        <p class="text-xs text-gray-400">Entrée <?php echo e(number_format($e->entry_fee, 0)); ?> FCFA · <?php echo e($e->products->count()); ?> produit(s)</p>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('expansion.events.toggle', $e)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="text-xs px-2 py-1 rounded <?php echo e($e->is_active ? 'bg-brand-600 text-white' : 'bg-gray-100'); ?>"><?php echo e($e->is_active ? 'Actif' : 'Activer'); ?></button>
                                    </form>
                                </div>
                                <!-- Ajouter produit au menu événement -->
                                <form method="POST" action="<?php echo e(route('expansion.events.products', $e)); ?>" class="flex gap-2 mt-2">
                                    <?php echo csrf_field(); ?>
                                    <select name="product_id" class="flex-1 px-2 py-1 border rounded-lg text-xs">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="px-2 py-1 bg-gray-100 rounded-lg text-xs">+ Ajouter</button>
                                </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-gray-400 text-sm">Aucun événement créé.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /root/resto-platform-php82/resources/views/expansion/index.blade.php ENDPATH**/ ?>