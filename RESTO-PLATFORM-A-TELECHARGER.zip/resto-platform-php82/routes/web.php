<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ConsolidationController;
use App\Http\Controllers\CopilotController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExpansionController;
use App\Http\Controllers\FloorController;
use App\Http\Controllers\IntelligenceController;
use App\Http\Controllers\KdsController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PosController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SseController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\TicketController;
use Illuminate\Support\Facades\Route;

// ===== App client (QR code, public) =====
Route::get('/m/{qrToken}', [ClientController::class, 'menu'])->name('client.menu');
Route::post('/m/{qrToken}/order', [ClientController::class, 'store'])->name('client.order');
Route::get('/m/order/{orderId}/track', [ClientController::class, 'track'])->name('client.track');

// ===== Auth =====
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post')->middleware('throttle:5,1'); // 5 tentatives/min
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/', fn () => redirect()->route('dashboard'));

    // Dashboard (tous les rôles)
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Plan de salle (serveur, gérant)
    Route::get('/floor', [FloorController::class, 'index'])->name('floor');

    // Commandes (API + actions) — tous les rôles opérationnels
    Route::prefix('orders')->group(function () {
        Route::post('/', [OrderController::class, 'store'])->name('orders.store');
        Route::get('/{order}', [OrderController::class, 'show'])->name('orders.show');
        Route::post('/{order}/send', [OrderController::class, 'send'])->name('orders.send');
        Route::post('/{order}/items', [OrderController::class, 'addItem'])->name('orders.addItem');
        Route::post('/items/{item}/status', [OrderController::class, 'updateItemStatus'])->name('orders.itemStatus');
        Route::post('/{order}/pay', [OrderController::class, 'pay'])->name('orders.pay');
        Route::post('/{order}/cancel', [OrderController::class, 'cancel'])->name('orders.cancel');
        Route::post('/{order}/discount', [OrderController::class, 'discount'])->name('orders.discount');
    });

    // Caisse POS (caissier, gérant)
    Route::get('/pos', [PosController::class, 'index'])->name('pos');
    Route::post('/pos/quick-sale', [PosController::class, 'quickSale'])->name('pos.quickSale');
    Route::get('/pos/orders', [PosController::class, 'orders'])->name('pos.orders');
    Route::get('/pos/order/{order}', [PosController::class, 'orderDetail'])->name('pos.orderDetail');

    // Écran cuisine / bar (KDS) — cuisinier, barman, gérant
    Route::get('/kds', [KdsController::class, 'index'])->name('kds');

    // ===== Back-office : réservé au gérant / propriétaire =====
    Route::middleware('role:manager,owner')->group(function () {
        // Menu
        Route::get('/menu', [MenuController::class, 'index'])->name('menu');
        Route::post('/menu/products', [MenuController::class, 'storeProduct'])->name('menu.products.store');
        Route::post('/menu/products/{product}', [MenuController::class, 'updateProduct'])->name('menu.products.update');
        Route::post('/menu/products/{product}/toggle', [MenuController::class, 'toggleProduct'])->name('menu.products.toggle');
        Route::delete('/menu/products/{product}', [MenuController::class, 'destroyProduct'])->name('menu.products.destroy');

        // Rapports
        Route::get('/reports', [ReportController::class, 'index'])->name('reports');

        // Intelligence (IA)
        Route::get('/intelligence', [IntelligenceController::class, 'index'])->name('intelligence');
        Route::get('/reservations', [IntelligenceController::class, 'reservations'])->name('reservations');
        Route::post('/reservations', [IntelligenceController::class, 'storeReservation'])->name('reservations.store');
        Route::post('/reservations/{reservation}/status', [IntelligenceController::class, 'updateReservation'])->name('reservations.status');

        // Expansion (livraison, tarification, événements)
        Route::get('/expansion', [ExpansionController::class, 'index'])->name('expansion');
        Route::post('/expansion/couriers', [ExpansionController::class, 'storeCourier'])->name('expansion.couriers.store');
        Route::post('/expansion/deliveries', [ExpansionController::class, 'createDelivery'])->name('expansion.deliveries.store');
        Route::post('/expansion/deliveries/{delivery}/status', [ExpansionController::class, 'updateDeliveryStatus'])->name('expansion.deliveries.status');
        Route::post('/expansion/prices', [ExpansionController::class, 'storePriceRule'])->name('expansion.prices.store');
        Route::post('/expansion/prices/{rule}/toggle', [ExpansionController::class, 'togglePriceRule'])->name('expansion.prices.toggle');
        Route::post('/expansion/events', [ExpansionController::class, 'storeEvent'])->name('expansion.events.store');
        Route::post('/expansion/events/{event}/toggle', [ExpansionController::class, 'toggleEvent'])->name('expansion.events.toggle');
        Route::post('/expansion/events/{event}/products', [ExpansionController::class, 'addEventProduct'])->name('expansion.events.products');

        // Stocks (gérant + magasinier)
        Route::get('/stock', [StockController::class, 'index'])->name('stock');
        Route::get('/stock/movements', [StockController::class, 'movements'])->name('stock.movements');
        Route::post('/stock/ingredients', [StockController::class, 'storeIngredient'])->name('stock.ingredients.store');
        Route::post('/stock/receive', [StockController::class, 'receive'])->name('stock.receive');
        Route::post('/stock/loss', [StockController::class, 'loss'])->name('stock.loss');
        Route::post('/stock/recipes', [StockController::class, 'storeRecipe'])->name('stock.recipes.store');

        // Copilote IA
        Route::get('/copilot', [CopilotController::class, 'index'])->name('copilot');
        Route::post('/copilot/ask', [CopilotController::class, 'ask'])->name('copilot.ask');

        // Consolidation multi-sites (direction)
                Route::get('/consolidation', [ConsolidationController::class, 'index'])->name('consolidation');
            });

            // ===== Console super-administrateur (SaaS) =====
            Route::middleware('role:superadmin')->group(function () {
                Route::get('/admin', [SuperAdminController::class, 'index'])->name('superadmin.index');
                Route::post('/admin/establishments', [SuperAdminController::class, 'storeEstablishment'])->name('superadmin.establishments.store');
                Route::post('/admin/establishments/{establishment}', [SuperAdminController::class, 'updateEstablishment'])->name('superadmin.establishments.update');
                Route::post('/admin/establishments/{establishment}/logo', [SuperAdminController::class, 'uploadLogo'])->name('superadmin.establishments.logo');
                Route::get('/admin/establishments/{establishment}/agents', [SuperAdminController::class, 'agents'])->name('superadmin.agents');
                Route::post('/admin/establishments/{establishment}/agents', [SuperAdminController::class, 'storeAgent'])->name('superadmin.agents.store');
                Route::post('/admin/agents/{user}/toggle', [SuperAdminController::class, 'toggleAgent'])->name('superadmin.agents.toggle');
            });

    // Tickets / impression (tous les rôles opérationnels)
    Route::get('/tickets/{order}/receipt', [TicketController::class, 'receipt'])->name('tickets.receipt');
    Route::get('/tickets/{order}/kitchen', [TicketController::class, 'kitchen'])->name('tickets.kitchen');
    Route::get('/tickets/{order}/bill', [TicketController::class, 'bill'])->name('tickets.bill');

    // Temps réel (SSE)
    Route::get('/sse', [SseController::class, 'stream'])->name('sse');
});
