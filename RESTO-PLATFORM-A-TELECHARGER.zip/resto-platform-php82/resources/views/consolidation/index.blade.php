@extends('layouts.app')

@section('title', 'Consolidation multi-sites')

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
            <div class="mb-6">
                <h1 class="text-2xl font-bold">🌍 Consolidation multi-sites</h1>
                <p class="text-gray-500 text-sm">Vue direction — tous les établissements, {{ $today->format('d/m/Y') }}</p>
            </div>

            <!-- Totaux -->
            <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Établissements</p>
                    <p class="text-2xl font-bold">{{ $establishments->count() }}</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">CA total du jour</p>
                    <p class="text-2xl font-bold text-brand-700">{{ number_format($totalRevenue, 0, ',', ' ') }} FCFA</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Commandes du jour</p>
                    <p class="text-2xl font-bold">{{ $totalOrders }}</p>
                </div>
            </div>

            <!-- Tableau par site -->
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-left text-gray-500">
                        <tr>
                            <th class="px-4 py-3">Établissement</th>
                            <th class="px-4 py-3">Pays</th>
                            <th class="px-4 py-3">Devise</th>
                            <th class="px-4 py-3 text-right">CA du jour</th>
                            <th class="px-4 py-3 text-center">Commandes</th>
                            <th class="px-4 py-3 text-center">En cours</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach($rows as $r)
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 font-medium">{{ $r['name'] }}</td>
                                <td class="px-4 py-3">{{ $r['country'] }}</td>
                                <td class="px-4 py-3">{{ $r['currency'] }}</td>
                                <td class="px-4 py-3 text-right font-semibold">{{ number_format($r['revenue'], 0, ',', ' ') }}</td>
                                <td class="px-4 py-3 text-center">{{ $r['orders'] }}</td>
                                <td class="px-4 py-3 text-center {{ $r['open'] > 0 ? 'text-accent-600' : '' }}">{{ $r['open'] }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @if($rows->isEmpty())
                    <p class="p-6 text-center text-gray-400">Aucun établissement actif.</p>
                @endif
            </div>

            <p class="text-xs text-gray-400 mt-3">💡 Pour ajouter un établissement dans un autre pays, créez-le dans la base avec sa devise (ex: XOF, GNF, NGN) et son pays.</p>
        </main>
    </div>
</div>
@endsection
