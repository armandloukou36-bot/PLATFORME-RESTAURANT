@extends('layouts.app')

@section('title', 'Caisse POS — ' . $est->name)

@section('head')
<style>
    .pos-product { transition: all .12s; }
    .pos-product:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.08); }
    .pos-product:active { transform: scale(.97); }
</style>
@endsection

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-4 overflow-hidden flex flex-col">
            <div class="flex items-center justify-between mb-4">
                <h1 class="text-2xl font-bold">Caisse (POS)</h1>
                <div class="flex gap-2">
                    <button onclick="newCounterSale()" class="px-4 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700">+ Vente comptoir</button>
                    <button onclick="showOrders()" class="px-4 py-2 bg-white border rounded-lg font-medium hover:bg-gray-50">Commandes en attente</button>
                </div>
            </div>

            <div class="flex-1 flex gap-4 min-h-0">
                <!-- Grille produits -->
                <div class="flex-1 flex flex-col min-h-0 bg-white rounded-xl border border-gray-200">
                    <div class="p-3 border-b flex gap-2">
                        <input id="posSearch" oninput="filterPosProducts()" placeholder="🔍 Rechercher / scanner code-barres..."
                            class="flex-1 px-3 py-2 border rounded-lg text-sm">
                        <select onchange="filterPosCategory(this.value)" class="px-3 py-2 border rounded-lg text-sm">
                            <option value="all">Toutes catégories</option>
                            @foreach($categories as $c)
                                <option value="{{ $c->id }}">{{ $c->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div id="posGrid" class="flex-1 overflow-y-auto p-3 grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 content-start scrollbar-thin">
                        @foreach($products as $p)
                            <button data-cat="{{ $p->category_id }}" data-name="{{ strtolower($p->name) }}"
                                onclick="posAdd({{ $p->id }}, '{{ addslashes($p->name) }}', {{ $p->price }})"
                                class="pos-product border rounded-lg p-3 text-left {{ $p->is_available ? 'hover:border-brand-500 hover:bg-brand-50' : 'opacity-40' }}">
                                <p class="font-medium text-sm">{{ $p->name }}</p>
                                <p class="text-xs text-gray-500">{{ number_format($p->price, 0, ',', ' ') }} FCFA</p>
                            </button>
                        @endforeach
                    </div>
                </div>

                <!-- Panier / encaissement -->
                <div class="w-96 flex flex-col min-h-0 bg-white rounded-xl border border-gray-200">
                    <div class="p-3 border-b">
                        <div class="flex items-center justify-between mb-2">
                            <span class="font-semibold">Vente en cours</span>
                            <span class="text-xs text-gray-500" id="posCount">0 article</span>
                        </div>
                        <div class="flex gap-2">
                            <select id="posChannel" class="flex-1 px-2 py-1.5 border rounded text-sm">
                                <option value="dine_in">Sur place</option>
                                <option value="takeaway">À emporter</option>
                                <option value="delivery">Livraison</option>
                                <option value="counter">Comptoir</option>
                            </select>
                            <input id="posTable" placeholder="Table" class="w-20 px-2 py-1.5 border rounded text-sm">
                        </div>
                    </div>

                    <div id="posCart" class="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin"></div>

                    <div class="p-3 border-t space-y-2">
                        <div class="flex justify-between text-sm">
                            <span>Sous-total</span><span id="posSubtotal">0 FCFA</span>
                        </div>
                        <div class="flex justify-between font-bold text-xl">
                            <span>Total</span><span id="posTotal" class="text-brand-700">0 FCFA</span>
                        </div>
                        <button onclick="openPayment()" class="w-full py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg">
                            Encaisser →
                        </button>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modal paiement -->
<div id="payModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="closePayment()"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-1">Encaissement</h2>
        <p class="text-sm text-gray-500 mb-4">Total à payer : <span id="payTotal" class="font-bold text-brand-700">0 FCFA</span></p>

        <div class="grid grid-cols-2 gap-2 mb-4">
            <button onclick="addPayment('cash')" class="p-3 border rounded-lg hover:bg-gray-50 text-sm font-medium">💵 Espèces</button>
            <button onclick="addPayment('card')" class="p-3 border rounded-lg hover:bg-gray-50 text-sm font-medium">💳 Carte</button>
            <button onclick="addPayment('orange_money')" class="p-3 border rounded-lg hover:bg-gray-50 text-sm font-medium">🟠 Orange Money</button>
            <button onclick="addPayment('mtn_momo')" class="p-3 border rounded-lg hover:bg-gray-50 text-sm font-medium">🟡 MTN MoMo</button>
            <button onclick="addPayment('moov')" class="p-3 border rounded-lg hover:bg-gray-50 text-sm font-medium">🔵 Moov</button>
            <button onclick="addPayment('wave')" class="p-3 border rounded-lg hover:bg-gray-50 text-sm font-medium">🌊 Wave</button>
        </div>

        <div id="paymentsList" class="space-y-2 mb-4"></div>

        <div class="flex justify-between text-sm mb-4">
            <span>Reste à payer</span><span id="remaining" class="font-bold">0 FCFA</span>
        </div>

        <div class="flex gap-2">
            <button onclick="closePayment()" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
            <button onclick="confirmPayment()" id="confirmPayBtn" class="flex-1 py-2.5 bg-green-600 text-white rounded-lg font-semibold disabled:opacity-40" disabled>Confirmer</button>
        </div>
    </div>
</div>

<script>
let posCart = [];
let posOrderId = null;
let payments = [];

function posAdd(productId, name, price) {
    const existing = posCart.find(c => c.product_id === productId);
    if (existing) existing.quantity++;
    else posCart.push({ product_id: productId, name, price, quantity: 1 });
    renderPosCart();
}

function posChangeQty(i, d) {
    posCart[i].quantity += d;
    if (posCart[i].quantity <= 0) posCart.splice(i, 1);
    renderPosCart();
}

function renderPosCart() {
    const count = posCart.reduce((s, c) => s + c.quantity, 0);
    const subtotal = posCart.reduce((s, c) => s + c.price * c.quantity, 0);
    document.getElementById('posCount').textContent = count + ' article(s)';
    document.getElementById('posSubtotal').textContent = subtotal.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('posTotal').textContent = subtotal.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('posCart').innerHTML = posCart.map((c, i) => `
        <div class="flex items-center justify-between bg-gray-50 rounded-lg p-2">
            <div class="flex-1">
                <p class="text-sm font-medium">${c.name}</p>
                <p class="text-xs text-gray-500">${c.price.toLocaleString('fr-FR')} FCFA</p>
            </div>
            <div class="flex items-center gap-2">
                <button onclick="posChangeQty(${i}, -1)" class="w-6 h-6 bg-gray-200 rounded hover:bg-gray-300">−</button>
                <span class="w-6 text-center text-sm font-semibold">${c.quantity}</span>
                <button onclick="posChangeQty(${i}, 1)" class="w-6 h-6 bg-gray-200 rounded hover:bg-gray-300">+</button>
            </div>
        </div>
    `).join('');
}

function newCounterSale() {
    posCart = [];
    posOrderId = null;
    document.getElementById('posChannel').value = 'counter';
    document.getElementById('posTable').value = '';
    renderPosCart();
}

function openPayment() {
    if (posCart.length === 0) return;
    payments = [];
    const total = posCart.reduce((s, c) => s + c.price * c.quantity, 0);
    document.getElementById('payTotal').textContent = total.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('payModal').classList.remove('hidden');
    renderPayments();
}

function addPayment(method) {
    const total = posCart.reduce((s, c) => s + c.price * c.quantity, 0);
    const paid = payments.reduce((s, p) => s + p.amount, 0);
    const remaining = total - paid;
    if (remaining <= 0) return;
    let amount = remaining;
    if (method === 'cash') {
        amount = prompt('Montant reçu en espèces ?', remaining);
        if (amount === null) return;
        amount = parseFloat(amount) || remaining;
    }
    payments.push({ method, amount: Math.min(amount, remaining) });
    renderPayments();
}

function renderPayments() {
    const total = posCart.reduce((s, c) => s + c.price * c.quantity, 0);
    const paid = payments.reduce((s, p) => s + p.amount, 0);
    const remaining = total - paid;
    document.getElementById('remaining').textContent = remaining.toLocaleString('fr-FR') + ' FCFA';
    document.getElementById('confirmPayBtn').disabled = remaining > 0;
    document.getElementById('paymentsList').innerHTML = payments.map((p, i) => `
        <div class="flex items-center justify-between bg-gray-50 rounded-lg p-2 text-sm">
            <span class="capitalize">${p.method.replace('_', ' ')}</span>
            <span class="font-semibold">${p.amount.toLocaleString('fr-FR')} FCFA</span>
            <button onclick="payments.splice(${i},1);renderPayments()" class="text-red-500">✕</button>
        </div>
    `).join('');
}

async function confirmPayment() {
    const total = posCart.reduce((s, c) => s + c.price * c.quantity, 0);
    const paid = payments.reduce((s, p) => s + p.amount, 0);
    const change = paid - total;

    // Si une commande existante a été chargée (showOrders), on suit l'ancien flux
    if (posOrderId) {
        if (posChannelVal() === 'dine_in') {
            await fetch('/orders/' + posOrderId + '/send', {
                method: 'POST', headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
            });
        }
        await fetch('/orders/' + posOrderId + '/pay', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
            body: JSON.stringify({ payments: payments.map(p => ({ ...p, change_due: p.method === 'cash' ? change : 0 })) })
        });
        closePayment();
        newCounterSale();
        alert('Paiement encaissé' + (change > 0 ? ' — Rendu monnaie : ' + change.toLocaleString('fr-FR') + ' FCFA' : ''));
        return;
    }

    // Sinon : vente rapide en UN SEUL appel
    const tableName = document.getElementById('posTable').value;
    const tables = @json($tables ?? []);
    const t = tables.find(x => x.name === tableName);
    const res = await fetch('/pos/quick-sale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        body: JSON.stringify({
            channel: posChannelVal(),
            table_id: t ? t.id : null,
            items: posCart.map(c => ({ product_id: c.product_id, quantity: c.quantity })),
            payments: payments.map(p => ({ ...p, change_due: p.method === 'cash' ? change : 0 }))
        })
    });
    if (!res.ok) {
        alert('Erreur lors de l\'encaissement. Vérifiez votre panier.');
        return;
    }
    closePayment();
    newCounterSale();
    alert('Paiement encaissé' + (change > 0 ? ' — Rendu monnaie : ' + change.toLocaleString('fr-FR') + ' FCFA' : ''));
}

function posChannelVal() {
    return document.getElementById('posChannel').value;
}

function closePayment() {
    document.getElementById('payModal').classList.add('hidden');
}

function filterPosProducts() {
    const q = document.getElementById('posSearch').value.toLowerCase();
    document.querySelectorAll('#posGrid .pos-product').forEach(card => {
        card.style.display = card.dataset.name.includes(q) ? '' : 'none';
    });
}

function filterPosCategory(catId) {
    document.querySelectorAll('#posGrid .pos-product').forEach(card => {
        card.style.display = (catId === 'all' || card.dataset.cat === catId) ? '' : 'none';
    });
}

async function showOrders() {
    const res = await fetch('/pos/orders');
    const orders = await res.json();
    const open = orders.filter(o => !['paid', 'cancelled'].includes(o.status));
    if (open.length === 0) { alert('Aucune commande en attente.'); return; }
    const list = open.map(o => `${o.order_number} — Table ${o.table?.name ?? '—'} — ${o.items.length} art. — ${o.total.toLocaleString('fr-FR')} FCFA`).join('\n');
    const choice = prompt('Commandes en attente :\n\n' + list + '\n\nEntrez le numéro de commande (ex: #0001) :');
    if (!choice) return;
    const order = open.find(o => o.order_number === choice.trim());
    if (!order) { alert('Commande introuvable.'); return; }
    // Charger dans le panier
    posCart = order.items.map(i => ({ product_id: i.product_id, name: i.product_name, price: i.unit_price, quantity: i.quantity }));
    posOrderId = order.id;
    document.getElementById('posChannel').value = order.channel;
    document.getElementById('posTable').value = order.table?.name || '';
    renderPosCart();
}

// Temps réel
function connectSSE() {
    const es = new EventSource('/sse');
    es.addEventListener('order.sent', () => {});
    es.onerror = () => { es.close(); setTimeout(connectSSE, 3000); };
}
connectSSE();
</script>
@endsection
