@extends('layouts.app')

@section('title', 'Agents — ' . $establishment->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">👥 Agents — {{ $establishment->name }}</h1>
                    <p class="text-gray-500 text-sm">Comptes des employés de cet établissement</p>
                </div>
                <div class="flex gap-2">
                    <a href="{{ route('superadmin.index') }}" class="px-4 py-2 bg-white border rounded-lg font-medium hover:bg-gray-50">← Établissements</a>
                    <button onclick="document.getElementById('agentModal').classList.remove('hidden')" class="px-4 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700">+ Nouvel agent</button>
                </div>
            </div>

            @if(session('success'))
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{{ session('success') }}</div>
            @endif

            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-left text-gray-500">
                        <tr>
                            <th class="px-4 py-3">Nom</th>
                            <th class="px-4 py-3">Email</th>
                            <th class="px-4 py-3">Rôle</th>
                            <th class="px-4 py-3">PIN</th>
                            <th class="px-4 py-3">Statut</th>
                            <th class="px-4 py-3 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach($agents as $a)
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 font-medium">{{ $a->name }}</td>
                                <td class="px-4 py-3">{{ $a->email }}</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-0.5 rounded text-xs font-medium
                                        {{ match($a->role) { 'manager' => 'bg-purple-100 text-purple-700', 'cashier' => 'bg-green-100 text-green-700', 'server' => 'bg-blue-100 text-blue-700', 'kitchen' => 'bg-amber-100 text-amber-700', 'bar' => 'bg-pink-100 text-pink-700', 'stock' => 'bg-gray-100 text-gray-700', default => 'bg-gray-100' } }}">
                                        {{ $a->role }}
                                    </span>
                                </td>
                                <td class="px-4 py-3">{{ $a->pin ?? '—' }}</td>
                                <td class="px-4 py-3">
                                    <span class="text-xs {{ $a->is_active ? 'text-green-600' : 'text-red-600' }}">{{ $a->is_active ? 'Actif' : 'Désactivé' }}</span>
                                </td>
                                <td class="px-4 py-3 text-right">
                                    <form method="POST" action="{{ route('superadmin.agents.toggle', $a) }}">
                                        @csrf
                                        <button class="text-xs px-2 py-1 rounded {{ $a->is_active ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600' }}">
                                            {{ $a->is_active ? 'Désactiver' : 'Activer' }}
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @if($agents->isEmpty())
                    <p class="p-6 text-center text-gray-400">Aucun agent. Créez le premier.</p>
                @endif
            </div>
        </main>
    </div>
</div>

<!-- Modal nouvel agent -->
<div id="agentModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-4">Nouvel agent — {{ $establishment->name }}</h2>
        <form method="POST" action="{{ route('superadmin.agents.store', $establishment) }}">
            @csrf
            <div class="space-y-3">
                <div><label class="block text-sm font-medium mb-1">Nom complet</label><input name="name" required class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                <div><label class="block text-sm font-medium mb-1">Email</label><input name="email" type="email" required class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Rôle</label>
                        <select name="role" class="w-full px-3 py-2 border rounded-lg text-sm">
                            <option value="manager">Gérant</option>
                            <option value="cashier">Caissier</option>
                            <option value="server">Serveur</option>
                            <option value="kitchen">Cuisinier</option>
                            <option value="bar">Barman</option>
                            <option value="stock">Magasinier</option>
                        </select>
                    </div>
                    <div><label class="block text-sm font-medium mb-1">PIN (4 chiffres)</label><input name="pin" maxlength="4" pattern="[0-9]{4}" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                </div>
                <div><label class="block text-sm font-medium mb-1">Mot de passe</label><input name="password" type="password" minlength="6" required class="w-full px-3 py-2 border rounded-lg text-sm"></div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#agentModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-brand-600 text-white rounded-lg font-semibold">Créer l'agent</button>
            </div>
        </form>
    </div>
</div>
@endsection
