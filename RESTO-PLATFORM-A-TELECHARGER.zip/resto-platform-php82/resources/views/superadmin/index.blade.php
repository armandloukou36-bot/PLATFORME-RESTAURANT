@extends('layouts.app')

@section('title', 'Console Super Admin')

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">🛡️ Console Super Admin</h1>
                    <p class="text-gray-500 text-sm">Gestion des établissements et de leurs agents (SaaS)</p>
                </div>
                <button onclick="document.getElementById('estModal').classList.remove('hidden')" class="px-4 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700">+ Nouvel établissement</button>
            </div>

            @if(session('success'))
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{{ session('success') }}</div>
            @endif

            <div class="grid lg:grid-cols-2 gap-4">
                @foreach($establishments as $est)
                    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                        <div class="p-4 flex items-center gap-3 border-b bg-gray-50">
                            @if($est->logo_path)
                                <img src="{{ asset('storage/' . $est->logo_path) }}" class="w-12 h-12 rounded-lg object-cover border" alt="logo">
                            @else
                                <div class="w-12 h-12 rounded-lg bg-brand-600 text-white flex items-center justify-center font-bold text-lg">{{ strtoupper(substr($est->name, 0, 1)) }}</div>
                            @endif
                            <div class="flex-1">
                                <p class="font-semibold">{{ $est->name }}</p>
                                <p class="text-xs text-gray-500">{{ $est->country }} · {{ $est->currency_symbol }} · {{ $est->users_count }} agent(s)</p>
                            </div>
                            <span class="text-xs px-2 py-1 rounded {{ $est->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500' }}">{{ $est->is_active ? 'Actif' : 'Inactif' }}</span>
                        </div>

                        <div class="p-4 space-y-3">
                            <!-- Logo -->
                            <form method="POST" action="{{ route('superadmin.establishments.logo', $est) }}" enctype="multipart/form-data" class="flex gap-2 items-center">
                                @csrf
                                <input type="file" name="logo" accept="image/*" class="text-xs flex-1" required>
                                <button class="px-3 py-1.5 bg-gray-100 rounded-lg text-xs font-medium">Upload logo</button>
                            </form>

                            <!-- Modifier -->
                            <form method="POST" action="{{ route('superadmin.establishments.update', $est) }}" class="space-y-2">
                                @csrf
                                <div class="grid grid-cols-2 gap-2">
                                    <input name="name" value="{{ $est->name }}" class="px-2 py-1.5 border rounded-lg text-sm" required>
                                    <input name="legal_name" value="{{ $est->legal_name }}" placeholder="Raison sociale" class="px-2 py-1.5 border rounded-lg text-sm">
                                </div>
                                <div class="grid grid-cols-3 gap-2">
                                    <input name="country" value="{{ $est->country }}" class="px-2 py-1.5 border rounded-lg text-sm">
                                    <input name="currency_symbol" value="{{ $est->currency_symbol }}" class="px-2 py-1.5 border rounded-lg text-sm">
                                    <input name="ncc" value="{{ $est->ncc }}" placeholder="NCC" class="px-2 py-1.5 border rounded-lg text-sm">
                                </div>
                                <div class="flex gap-2">
                                    <input name="phone" value="{{ $est->phone }}" placeholder="Téléphone" class="flex-1 px-2 py-1.5 border rounded-lg text-sm">
                                    <input name="address" value="{{ $est->address }}" placeholder="Adresse" class="flex-1 px-2 py-1.5 border rounded-lg text-sm">
                                </div>
                                <div class="flex gap-2 items-center">
                                    <label class="text-xs text-gray-500 flex items-center gap-1"><input type="checkbox" name="is_active" value="1" {{ $est->is_active ? 'checked' : '' }}> Actif</label>
                                    <button class="px-3 py-1.5 bg-brand-600 text-white rounded-lg text-xs font-medium ml-auto">Enregistrer</button>
                                </div>
                            </form>

                            <a href="{{ route('superadmin.agents', $est) }}" class="block text-center px-3 py-2 bg-gray-50 border rounded-lg text-sm font-medium hover:bg-gray-100">
                                👥 Gérer les agents ({{ $est->users_count }})
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>

            @if($establishments->isEmpty())
                <p class="text-center text-gray-400 py-10">Aucun établissement. Créez le premier.</p>
            @endif
        </main>
    </div>
</div>

<!-- Modal nouvel établissement -->
<div id="estModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-4">Nouvel établissement</h2>
        <form method="POST" action="{{ route('superadmin.establishments.store') }}">
            @csrf
            <div class="space-y-3">
                <div><label class="block text-sm font-medium mb-1">Nom</label><input name="name" required class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                <div><label class="block text-sm font-medium mb-1">Raison sociale</label><input name="legal_name" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                <div class="grid grid-cols-2 gap-3">
                    <div><label class="block text-sm font-medium mb-1">Pays</label><input name="country" value="Côte d'Ivoire" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                    <div><label class="block text-sm font-medium mb-1">Devise</label><input name="currency_symbol" value="FCFA" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                </div>
                <div><label class="block text-sm font-medium mb-1">NCC</label><input name="ncc" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                <div><label class="block text-sm font-medium mb-1">Téléphone</label><input name="phone" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
                <div><label class="block text-sm font-medium mb-1">Adresse</label><input name="address" class="w-full px-3 py-2 border rounded-lg text-sm"></div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#estModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-brand-600 text-white rounded-lg font-semibold">Créer</button>
            </div>
        </form>
    </div>
</div>
@endsection
