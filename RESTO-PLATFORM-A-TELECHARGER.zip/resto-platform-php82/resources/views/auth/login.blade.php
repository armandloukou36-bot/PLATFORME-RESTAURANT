@extends('layouts.app')

@section('title', 'Connexion — Resto Platform')

@section('body')
<div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-700 via-brand-600 to-brand-800 p-4">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 backdrop-blur mb-4">
                <svg class="w-9 h-9 text-accent-400" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <h1 class="text-3xl font-bold text-white">Resto Platform</h1>
            <p class="text-brand-100 mt-1">Gestion de restaurant nouvelle génération</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-8">
            @if($errors->any())
                <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
                    {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Adresse e-mail</label>
                    <input type="email" name="email" value="{{ old('email') }}" required autofocus
                        class="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none">
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Mot de passe</label>
                    <input type="password" name="password" required
                        class="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none">
                </div>
                <button type="submit"
                    class="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-semibold rounded-lg transition">
                    Se connecter
                </button>
            </form>

            <div class="mt-6 pt-4 border-t border-gray-100">
                <p class="text-xs text-gray-500 mb-2">Comptes de démonstration :</p>
                <div class="grid grid-cols-2 gap-2 text-xs">
                    <button onclick="fill('gerant@lebaobab.ci')" class="p-2 bg-gray-50 hover:bg-gray-100 rounded border text-left">👔 Gérant<br><span class="text-gray-400">gerant@lebaobab.ci</span></button>
                    <button onclick="fill('caisse@lebaobab.ci')" class="p-2 bg-gray-50 hover:bg-gray-100 rounded border text-left">💵 Caissier<br><span class="text-gray-400">caisse@lebaobab.ci</span></button>
                    <button onclick="fill('serveur1@lebaobab.ci')" class="p-2 bg-gray-50 hover:bg-gray-100 rounded border text-left">🛎️ Serveur<br><span class="text-gray-400">serveur1@lebaobab.ci</span></button>
                    <button onclick="fill('cuisine@lebaobab.ci')" class="p-2 bg-gray-50 hover:bg-gray-100 rounded border text-left">👨‍🍳 Cuisinier<br><span class="text-gray-400">cuisine@lebaobab.ci</span></button>
                </div>
                <p class="text-[11px] text-gray-400 mt-2">Mot de passe : <code>password</code></p>
            </div>
        </div>
    </div>
</div>

<script>
function fill(email){
    document.querySelector('input[name=email]').value = email;
    document.querySelector('input[name=password]').value = 'password';
}
</script>
@endsection
