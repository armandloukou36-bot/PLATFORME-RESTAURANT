@extends('layouts.app')

@section('title', 'Rapports — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Rapports</h1>
                    <p class="text-gray-500 text-sm">Analyse des ventes</p>
                </div>
                <form method="GET" class="flex gap-2 items-center">
                    <input type="date" name="from" value="{{ $from }}" class="px-3 py-2 border rounded-lg text-sm">
                    <span class="text-gray-400">→</span>
                    <input type="date" name="to" value="{{ $to }}" class="px-3 py-2 border rounded-lg text-sm">
                    <button class="px-4 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">Filtrer</button>
                </form>
            </div>

            <!-- KPIs -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Chiffre d'affaires</p>
                    <p class="text-2xl font-bold text-brand-700">{{ number_format($revenue, 0, ',', ' ') }} FCFA</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Commandes</p>
                    <p class="text-2xl font-bold">{{ $orderCount }}</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Panier moyen</p>
                    <p class="text-2xl font-bold">{{ number_format($avgBasket, 0, ',', ' ') }} FCFA</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Annulations</p>
                    <p class="text-2xl font-bold {{ $cancellations > 0 ? 'text-red-600' : '' }}">{{ $cancellations }}</p>
                </div>
            </div>

            <div class="grid lg:grid-cols-2 gap-6">
                <!-- Par mode de paiement -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Par mode de paiement</h2>
                    @foreach($byMethod as $m)
                        <div class="flex items-center justify-between py-2 border-b border-gray-50">
                            <span class="capitalize">{{ str_replace('_', ' ', $m->method) }}</span>
                            <span class="font-semibold">{{ number_format($m->total, 0, ',', ' ') }} FCFA</span>
                        </div>
                    @endforeach
                    @if($byMethod->isEmpty())<p class="text-gray-400 text-sm">Aucune donnée.</p>@endif
                </div>

                <!-- Par canal -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Par canal</h2>
                    @foreach($byChannel as $channel => $total)
                        <div class="flex items-center justify-between py-2 border-b border-gray-50">
                            <span class="capitalize">{{ $channel }}</span>
                            <span class="font-semibold">{{ number_format($total, 0, ',', ' ') }} FCFA</span>
                        </div>
                    @endforeach
                    @if($byChannel->isEmpty())<p class="text-gray-400 text-sm">Aucune donnée.</p>@endif
                </div>

                <!-- Top produits -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Top produits</h2>
                    <table class="w-full text-sm">
                        <thead class="text-gray-500 text-left">
                            <tr><th class="py-1">Produit</th><th class="py-1 text-right">Qté</th><th class="py-1 text-right">CA</th></tr>
                        </thead>
                        <tbody>
                            @foreach($topProducts as $p)
                                <tr class="border-b border-gray-50">
                                    <td class="py-2">{{ $p->product_name }}</td>
                                    <td class="py-2 text-right font-semibold">{{ $p->qty }}</td>
                                    <td class="py-2 text-right">{{ number_format($p->total, 0, ',', ' ') }} FCFA</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @if($topProducts->isEmpty())<p class="text-gray-400 text-sm mt-2">Aucune donnée.</p>@endif
                </div>

                <!-- Par serveur -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Par serveur</h2>
                    @foreach($byServer as $s)
                        <div class="flex items-center justify-between py-2 border-b border-gray-50">
                            <span>{{ $s['name'] }}</span>
                            <span class="font-semibold">{{ number_format($s['total'], 0, ',', ' ') }} FCFA <span class="text-gray-400 text-sm">({{ $s['count'] }})</span></span>
                        </div>
                    @endforeach
                    @if($byServer->isEmpty())<p class="text-gray-400 text-sm">Aucune donnée.</p>@endif
                </div>
            </div>
        </main>
    </div>
</div>
@endsection
