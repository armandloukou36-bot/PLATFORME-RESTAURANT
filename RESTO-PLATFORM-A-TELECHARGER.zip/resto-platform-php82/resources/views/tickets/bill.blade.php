<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Note {{ $order->order_number }}</title>
    <style>
        body { font-family: 'Courier New', monospace; width: 80mm; margin: 0 auto; font-size: 12px; }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .line { border-top: 1px dashed #000; margin: 6px 0; }
        .row { display: flex; justify-content: space-between; }
        @media print { body { width: 80mm; } }
    </style>
</head>
<body>
    <div class="center bold" style="font-size:14px">{{ $est->name }}</div>
    <div class="center bold">NOTE PROVISOIRE</div>
    <div class="line"></div>
    <div class="row"><span>N°</span><span>{{ $order->order_number }}</span></div>
    <div class="row"><span>Table</span><span>{{ $order->table?->name ?? '—' }}</span></div>
    <div class="row"><span>Serveur</span><span>{{ $order->user?->name }}</span></div>
    <div class="row"><span>Date</span><span>{{ $order->created_at->format('d/m/Y H:i') }}</span></div>
    <div class="line"></div>
    @foreach($order->items as $item)
        <div class="row"><span>{{ $item->quantity }}x {{ $item->product_name }}</span><span>{{ number_format($item->lineTotal(), 0, ',', ' ') }}</span></div>
        @foreach($item->options as $opt)
            <div style="padding-left:12px">+ {{ $opt->choice_name }}</div>
        @endforeach
    @endforeach
    <div class="line"></div>
    <div class="row bold" style="font-size:14px"><span>TOTAL</span><span>{{ number_format($order->total, 0, ',', ' ') }} FCFA</span></div>
    <div class="center mt">Merci de votre visite !</div>
    <script>window.print();</script>
</body>
</html>
