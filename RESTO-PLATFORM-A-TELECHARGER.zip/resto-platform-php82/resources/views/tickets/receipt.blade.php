<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Reçu {{ $order->order_number }}</title>
    <style>
        body { font-family: 'Courier New', monospace; margin: 0; background:#eee; }
        #ticket { width: 80mm; margin: 10px auto; background:#fff; padding: 8px; font-size: 12px; }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .line { border-top: 1px dashed #000; margin: 6px 0; }
        .row { display: flex; justify-content: space-between; }
        .mt { margin-top: 4px; }
        .toolbar { text-align:center; padding: 12px; }
        .btn { display:inline-block; margin:0 4px; padding:10px 16px; border:none; border-radius:8px; font-size:14px; cursor:pointer; color:#fff; text-decoration:none; font-family:sans-serif; }
        .btn-print { background:#16a34a; }
        .btn-wa { background:#25d366; }
        @media print {
            body { background:#fff; }
            #ticket { margin:0; padding:0; border:none; }
            .toolbar, .no-print { display:none !important; }
        }
    </style>
</head>
<body>
    <div class="toolbar no-print">
        <button onclick="window.print()" class="btn btn-print">🖨️ Imprimer (80mm)</button>
        @if($order->customer_phone)
            <a class="btn btn-wa" href="https://wa.me/{{ preg_replace('/[^0-9]/', '', $order->customer_phone) }}?text={{ urlencode('Votre reçu ' . $order->order_number) }}" target="_blank">💬 Reçu WhatsApp</a>
        @else
            <button class="btn btn-wa" style="opacity:.6" title="Ajoutez le téléphone du client pour envoyer son reçu par WhatsApp">💬 Reçu WhatsApp</button>
        @endif
    </div>

    <div id="ticket">
            @if($est->logo_path)
                <div class="center">
                    <img src="{{ asset('storage/' . $est->logo_path) }}" style="max-width:50mm; max-height:20mm; object-fit:contain;" alt="logo">
                </div>
            @endif
            <div class="center bold" style="font-size:14px">{{ $est->legal_name ?? $est->name }}</div>
            <div class="center">{{ $est->address }}</div>
            <div class="center">NCC : {{ $est->ncc }}</div>
            <div class="center">Tél : {{ $est->phone }}</div>
        <div class="line"></div>
        <div class="center bold">TICKET DE CAISSE</div>
        <div class="line"></div>
        <div class="row"><span>N°</span><span>{{ $order->order_number }}</span></div>
        <div class="row"><span>Date</span><span>{{ $order->created_at->format('d/m/Y H:i') }}</span></div>
        <div class="row"><span>Caissier</span><span>{{ $order->user?->name }}</span></div>
        @if($order->table)<div class="row"><span>Table</span><span>{{ $order->table->name }}</span></div>@endif
        <div class="row"><span>Canal</span><span class="capitalize">{{ $order->channel }}</span></div>
        @if($order->customer_phone)<div class="row"><span>Client</span><span>{{ $order->customer_phone }}</span></div>@endif
        <div class="line"></div>
        @foreach($order->items as $item)
            <div class="row"><span>{{ $item->quantity }}x {{ $item->product_name }}</span><span>{{ number_format($item->lineTotal(), 0, ',', ' ') }}</span></div>
            @foreach($item->options as $opt)
                <div style="padding-left:12px">+ {{ $opt->choice_name }}</div>
            @endforeach
        @endforeach
        <div class="line"></div>
        <div class="row"><span>Sous-total</span><span>{{ number_format($order->subtotal, 0, ',', ' ') }}</span></div>
        @if($order->discount > 0)
            <div class="row"><span>Remise</span><span>-{{ number_format($order->discount, 0, ',', ' ') }}</span></div>
        @endif
        <div class="row bold" style="font-size:14px"><span>TOTAL</span><span>{{ number_format($order->total, 0, ',', ' ') }} {{ $est->currency_symbol ?? 'FCFA' }}</span></div>
        <div class="line"></div>
        @foreach($order->payments as $pay)
            <div class="row"><span class="capitalize">{{ str_replace('_', ' ', $pay->method) }}</span><span>{{ number_format($pay->amount, 0, ',', ' ') }}</span></div>
            @if($pay->change_due > 0)
                <div class="row"><span>Rendu</span><span>{{ number_format($pay->change_due, 0, ',', ' ') }}</span></div>
            @endif
        @endforeach
        <div class="line"></div>
        <div class="center mt">Merci de votre visite !</div>
        <div class="center">À bientôt chez {{ $est->name }}</div>
        <div class="center mt">🔗 Scannez pour nous noter</div>
    </div>

    <script>
        // Impression automatique puis fermeture
        window.onload = function () { setTimeout(() => window.print(), 300); };
        window.onafterprint = function () { setTimeout(() => window.close(), 200); };
    </script>
</body>
</html>
