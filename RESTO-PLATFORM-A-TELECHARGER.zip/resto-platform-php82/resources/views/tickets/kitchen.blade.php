<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bon cuisine {{ $order->order_number }}</title>
    <style>
        body { font-family: 'Courier New', monospace; width: 80mm; margin: 0 auto; font-size: 14px; }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .line { border-top: 1px dashed #000; margin: 6px 0; }
        .row { display: flex; justify-content: space-between; }
        .note { color: #c00; font-weight: bold; }
        @media print { body { width: 80mm; } }
    </style>
</head>
<body>
    <div class="center bold" style="font-size:16px">BON DE COMMANDE</div>
    <div class="center bold" style="font-size:20px">{{ $order->order_number }}</div>
    <div class="line"></div>
    <div class="row"><span>Table</span><span class="bold">{{ $order->table?->name ?? '—' }}</span></div>
    <div class="row"><span>Serveur</span><span>{{ $order->user?->name }}</span></div>
    <div class="row"><span>Heure</span><span>{{ $order->sent_at?->format('H:i') }}</span></div>
    <div class="line"></div>
    @foreach($order->items as $item)
        <div style="font-size:16px" class="bold">{{ $item->quantity }}x {{ $item->product_name }}</div>
        @foreach($item->options as $opt)
            <div style="padding-left:10px">+ {{ $opt->choice_name }}</div>
        @endforeach
        @if($item->notes)
            <div class="note">⚠️ {{ $item->notes }}</div>
        @endif
    @endforeach
    <div class="line"></div>
    <div class="center">Bon de cuisine</div>
    <script>window.print();</script>
</body>
</html>
