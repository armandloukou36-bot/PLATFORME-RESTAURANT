@extends('layouts.app')

@section('title', 'Cuisine / Bar — ' . $est->name)

@section('head')
<style>
    .kds-ticket { transition: all .15s; }
    .kds-ticket:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.08); }
    .status-new { border-left: 4px solid #f59e0b; }
    .status-in_progress { border-left: 4px solid #3b82f6; }
    .status-ready { border-left: 4px solid #22c55e; }
    .timer-red { color:#dc2626; font-weight:700; }
    .timer-orange { color:#ea580c; font-weight:600; }
    .timer-green { color:#16a34a; }
</style>
@endsection

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Écran Cuisine / Bar</h1>
                    <p class="text-gray-500 text-sm">Tickets en cours — mise à jour en temps réel</p>
                </div>
                <div class="flex gap-2">
                    <a href="{{ route('kds') }}" class="px-3 py-1.5 rounded-lg text-sm font-medium {{ !$stationFilter ? 'bg-brand-600 text-white' : 'bg-white border' }}">Tous</a>
                    @foreach($stations as $s)
                        <a href="{{ route('kds', ['station' => $s->id]) }}" class="px-3 py-1.5 rounded-lg text-sm font-medium {{ $stationFilter == $s->id ? 'bg-brand-600 text-white' : 'bg-white border' }}">{{ $s->name }}</a>
                    @endforeach
                </div>
            </div>

            @if($orders->isEmpty())
                <div class="text-center py-20 text-gray-400">
                    <p class="text-5xl mb-3">🍽️</p>
                    <p class="font-medium">Aucun ticket en attente</p>
                    <p class="text-sm">Les commandes envoyées par les serveurs apparaîtront ici.</p>
                </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                @foreach($orders as $order)
                    <div class="kds-ticket bg-white rounded-xl shadow-sm border border-gray-200 {{ $order->status === 'in_progress' ? 'status-in_progress' : 'status-new' }}">
                        <div class="p-3 border-b flex items-center justify-between bg-gray-50 rounded-t-xl">
                            <div>
                                <span class="font-bold text-lg">{{ $order->order_number }}</span>
                                <span class="text-sm text-gray-500 ml-2">Table {{ $order->table?->name ?? '—' }}</span>
                            </div>
                            <div class="text-right">
                                <p class="text-xs text-gray-500">{{ $order->user?->name }}</p>
                                <p class="text-xs text-gray-400">{{ $order->sent_at?->format('H:i') }}</p>
                            </div>
                        </div>

                        <div class="p-3 space-y-2">
                            @foreach($order->items as $item)
                                <div class="flex items-start justify-between gap-2 p-2 rounded-lg {{ $item->status === 'ready' ? 'bg-green-50' : ($item->status === 'in_progress' ? 'bg-blue-50' : 'bg-gray-50') }}">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2">
                                            <span class="font-bold text-lg">{{ $item->quantity }}×</span>
                                            <span class="font-medium">{{ $item->product_name }}</span>
                                        </div>
                                        @if($item->notes)
                                            <p class="text-xs text-red-600 font-semibold mt-1">⚠️ {{ $item->notes }}</p>
                                        @endif
                                        @foreach($item->options as $opt)
                                            <p class="text-xs text-gray-500">+ {{ $opt->choice_name }}</p>
                                        @endforeach
                                    </div>
                                    <div class="flex flex-col items-end gap-1">
                                        <span class="text-xs text-gray-400">{{ $item->station?->name }}</span>
                                        <div class="flex gap-1">
                                            @if($item->status === 'new')
                                                <button onclick="setItemStatus({{ $item->id }}, 'in_progress')" class="px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600">Commencer</button>
                                            @endif
                                            @if(in_array($item->status, ['new', 'in_progress']))
                                                <button onclick="setItemStatus({{ $item->id }}, 'ready')" class="px-2 py-1 text-xs bg-green-500 text-white rounded hover:bg-green-600">Prêt</button>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <div class="p-3 border-t flex items-center justify-between">
                            <span class="text-xs text-gray-500">{{ $order->items->count() }} article(s)</span>
                            <span class="text-xs font-medium {{ $order->status === 'in_progress' ? 'text-blue-600' : 'text-amber-600' }}">
                                {{ $order->status === 'in_progress' ? 'En préparation' : 'Nouveau' }}
                            </span>
                        </div>
                    </div>
                @endforeach
            </div>
        </main>
    </div>
</div>

<script>
async function setItemStatus(itemId, status) {
    await fetch('/orders/items/' + itemId + '/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        body: JSON.stringify({ status })
    });
    location.reload();
}

// Temps réel SSE
function connectSSE() {
    const es = new EventSource('/sse');
    es.addEventListener('order.sent', () => location.reload());
    es.addEventListener('item.status', () => location.reload());
    es.onerror = () => { es.close(); setTimeout(connectSSE, 3000); };
}
connectSSE();

// ===== Son + lecture vocale à l'arrivée d'une commande en cuisine =====
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function beep() {
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = 'sine'; o.frequency.value = 880;
    g.gain.setValueAtTime(0.5, audioCtx.currentTime);
    o.connect(g); g.connect(audioCtx.destination);
    o.start(); o.stop(audioCtx.currentTime + 0.15);
    // double bip plus grave
    setTimeout(() => {
        const o2 = audioCtx.createOscillator();
        const g2 = audioCtx.createGain();
        o2.type = 'sine'; o2.frequency.value = 660;
        g2.gain.setValueAtTime(0.5, audioCtx.currentTime);
        o2.connect(g2); g2.connect(audioCtx.destination);
        o2.start(); o2.stop(audioCtx.currentTime + 0.15);
    }, 220);
}

// Lecture vocale de la commande reçue
function speakOrder() {
    if (!('speechSynthesis' in window)) return;
    const items = @json($orders->map(fn($o) => optional($o->items->first())->product_name ?? null)->filter());
    const names = items.filter(Boolean).slice(0, 3);
    if (names.length === 0) return;
    const u = new SpeechSynthesisUtterance('Nouvelle commande : ' + names.join(', '));
    u.lang = 'fr-FR'; u.rate = 1;
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
    beep(); // son en plus de la voix
}

// Se déclenche à chaque nouvelle commande envoyée (via SSE)
const kdsEs = new EventSource('/sse');
kdsEs.addEventListener('order.sent', () => { speakOrder(); });
kdsEs.onerror = () => { kdsEs.close(); };
// Rejouer les commandes en attente au chargement si présence (débloque le clavier auto après lien autorisé par utilisateur)
window.addEventListener('load', () => {
    const pending = @json($orders->filter(fn($o) => $o->status === 'new')->count());
    if (pending > 0) { speakOrder(); }
});
</script>
@endsection
