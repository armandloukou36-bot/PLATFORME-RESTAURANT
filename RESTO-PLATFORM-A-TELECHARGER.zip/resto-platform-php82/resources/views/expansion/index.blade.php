@extends('layouts.app')

@section('title', 'Expansion — ' . $est->name)

@section('body')
<div class="min-h-screen flex" x-data="{ tab: 'delivery' }">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h1 class="text-2xl font-bold">Expansion</h1>
                    <p class="text-gray-500 text-sm">Livraison, tarification dynamique, mode événement</p>
                </div>
            </div>

            @if(session('success'))
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{{ session('success') }}</div>
            @endif

            <!-- Onglets -->
            <div class="flex gap-1 bg-gray-200 p-1 rounded-lg mb-6 w-fit">
                <button @click="tab='delivery'" :class="tab==='delivery' ? 'bg-white shadow' : 'text-gray-600'" class="px-4 py-2 rounded-md text-sm font-medium">🛵 Livraison</button>
                <button @click="tab='pricing'" :class="tab==='pricing' ? 'bg-white shadow' : 'text-gray-600'" class="px-4 py-2 rounded-md text-sm font-medium">🏷️ Tarifs dynamiques</button>
                <button @click="tab='event'" :class="tab==='event' ? 'bg-white shadow' : 'text-gray-600'" class="px-4 py-2 rounded-md text-sm font-medium">🎉 Événements</button>
            </div>

            <!-- ===== LIVRAISON ===== -->
            <div x-show="tab==='delivery'" x-cloak>
                <div class="grid lg:grid-cols-3 gap-4 mb-4">
                    <!-- Commandes à livrer -->
                    <div class="bg-white rounded-xl border border-gray-200 p-4 lg:col-span-2">
                        <h2 class="font-semibold mb-3">📦 Commandes en attente de livraison</h2>
                        @forelse($pendingOrders as $o)
                            <div class="flex items-center justify-between py-2 border-b border-gray-50">
                                <div>
                                    <p class="font-medium text-sm">{{ $o->order_number }} — {{ $o->total }} FCFA</p>
                                    <p class="text-xs text-gray-400">{{ $o->items->count() }} article(s) · {{ $o->customer_name ?? 'Client' }}</p>
                                </div>
                                <button onclick="document.getElementById('dlv-{{ $o->id }}').classList.remove('hidden')" class="text-xs bg-brand-600 text-white px-3 py-1.5 rounded-lg">Créer la livraison</button>
                            </div>

                            <!-- Modal création livraison -->
                            <div id="dlv-{{ $o->id }}" class="fixed inset-0 z-50 hidden">
                                <div class="absolute inset-0 bg-black/50" onclick="this.closest('#dlv-{{ $o->id }}').classList.add('hidden')"></div>
                                <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl p-6">
                                    <h3 class="font-bold mb-4">Livraison {{ $o->order_number }}</h3>
                                    <form method="POST" action="{{ route('expansion.deliveries.store') }}">
                                        @csrf
                                        <input type="hidden" name="order_id" value="{{ $o->id }}">
                                        <div class="space-y-3 text-sm">
                                            <div class="grid grid-cols-2 gap-2">
                                                <div><label class="block text-xs font-medium mb-1">Contact</label><input name="contact_name" required class="w-full px-3 py-2 border rounded-lg"></div>
                                                <div><label class="block text-xs font-medium mb-1">Téléphone</label><input name="contact_phone" required class="w-full px-3 py-2 border rounded-lg"></div>
                                            </div>
                                            <div><label class="block text-xs font-medium mb-1">Adresse</label><input name="address" required class="w-full px-3 py-2 border rounded-lg"></div>
                                            <div class="grid grid-cols-2 gap-2">
                                                <div><label class="block text-xs font-medium mb-1">Ville</label><input name="city" class="w-full px-3 py-2 border rounded-lg"></div>
                                                <div><label class="block text-xs font-medium mb-1">Point de repère</label><input name="landmark" class="w-full px-3 py-2 border rounded-lg"></div>
                                            </div>
                                            <div class="grid grid-cols-2 gap-2">
                                                <div>
                                                    <label class="block text-xs font-medium mb-1">Livreur</label>
                                                    <select name="courier_id" class="w-full px-3 py-2 border rounded-lg">
                                                        <option value="">—</option>
                                                        @foreach($couriers as $c)
                                                            <option value="{{ $c->id }}">{{ $c->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div><label class="block text-xs font-medium mb-1">Frais (FCFA)</label><input name="delivery_fee" type="number" min="0" value="1000" class="w-full px-3 py-2 border rounded-lg"></div>
                                            </div>
                                        </div>
                                        <div class="flex gap-2 mt-4">
                                            <button type="button" onclick="this.closest('[id^=dlv-]').classList.add('hidden')" class="flex-1 py-2 border rounded-lg">Annuler</button>
                                            <button type="submit" class="flex-1 py-2 bg-brand-600 text-white rounded-lg font-medium">Créer</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        @empty
                            <p class="text-gray-400 text-sm">Aucune commande de livraison en attente.</p>
                        @endforelse
                    </div>

                    <!-- Ajouter livreur + liste -->
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">🛵 Livreurs</h2>
                        <form method="POST" action="{{ route('expansion.couriers.store') }}" class="mb-3">
                            @csrf
                            <div class="flex gap-2">
                                <input name="name" placeholder="Nom" required class="flex-1 px-3 py-2 border rounded-lg text-sm">
                                <input name="phone" placeholder="Tél" required class="flex-1 px-3 py-2 border rounded-lg text-sm">
                            </div>
                            <button class="w-full mt-2 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">+ Ajouter</button>
                        </form>
                        <div class="space-y-1">
                            @foreach($couriers as $c)
                                <div class="flex items-center justify-between py-1 border-b border-gray-50">
                                    <div>
                                        <p class="text-sm font-medium">{{ $c->name }}</p>
                                        <p class="text-xs text-gray-400">{{ $c->vehicle ?? '—' }} · {{ $c->deliveries_count }} course(s)</p>
                                    </div>
                                    <span class="text-xs {{ $c->is_available ? 'text-green-600' : 'text-gray-400' }}">{{ $c->is_available ? 'Disponible' : 'Occupé' }}</span>
                                </div>
                            @endforeach
                            @if($couriers->isEmpty())<p class="text-gray-400 text-sm">Aucun livreur.</p>@endif
                        </div>
                    </div>
                </div>

                <!-- Livraisons en cours -->
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <div class="px-4 py-3 bg-gray-50 font-semibold">Livraisons (50 dernières)</div>
                    <table class="w-full text-sm">
                        <thead class="bg-gray-50 text-left text-gray-500">
                            <tr><th class="px-4 py-2">N°</th><th class="px-4 py-2">Livreur</th><th class="px-4 py-2">Adresse</th><th class="px-4 py-2 text-right">Frais</th><th class="px-4 py-2">Statut</th><th class="px-4 py-2 text-right">Actions</th></tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @foreach($deliveries as $d)
                                <tr>
                                    <td class="px-4 py-2 font-medium">{{ $d->order?->order_number }}</td>
                                    <td class="px-4 py-2">{{ $d->courier?->name ?? '—' }}</td>
                                    <td class="px-4 py-2 text-xs">{{ $d->address }}</td>
                                    <td class="px-4 py-2 text-right">{{ number_format($d->delivery_fee, 0) }}</td>
                                    <td class="px-4 py-2">
                                        <form method="POST" action="{{ route('expansion.deliveries.status', $d) }}" class="inline">
                                            @csrf
                                            <select name="status" onchange="this.form.submit()" class="text-xs border rounded px-2 py-1">
                                                @foreach(['pending','assigned','picked_up','in_transit','delivered','returned','cancelled'] as $s)
                                                    <option value="{{ $s }}" {{ $d->status===$s ? 'selected' : '' }}>{{ $s }}</option>
                                                @endforeach
                                            </select>
                                        </form>
                                    </td>
                                    <td class="px-4 py-2 text-right text-xs">
                                        @if(in_array($d->status, ['in_transit', 'assigned']) && !$d->order?->paid_at)
                                            <form method="POST" action="{{ route('expansion.deliveries.status', $d) }}">
                                                @csrf
                                                <input type="hidden" name="status" value="delivered">
                                                <input type="hidden" name="payment_method" value="cash">
                                                <input type="hidden" name="collected_amount" value="{{ $d->order?->total + $d->delivery_fee }}">
                                                <button class="text-green-600 font-medium">Encaisser & livrer</button>
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @if($deliveries->isEmpty())<p class="p-4 text-center text-gray-400 text-sm">Aucune livraison.</p>@endif
                </div>
            </div>

            <!-- ===== TARIFICATION DYNAMIQUE ===== -->
            <div x-show="tab==='pricing'" x-cloak>
                <div class="grid lg:grid-cols-2 gap-4">
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">🏷️ Règles de prix (IA-10)</h2>
                        <form method="POST" action="{{ route('expansion.prices.store') }}">
                            @csrf
                            <div class="space-y-2 text-sm">
                                <div><label class="block text-xs font-medium mb-1">Nom de la règle</label><input name="name" value="Happy hour" required class="w-full px-3 py-2 border rounded-lg"></div>
                                <div class="grid grid-cols-2 gap-2">
                                    <div>
                                        <label class="block text-xs font-medium mb-1">Produit</label>
                                        <select name="product_id" class="w-full px-3 py-2 border rounded-lg">
                                            <option value="">Tous les produits</option>
                                            @foreach($products as $p)
                                                <option value="{{ $p->id }}">{{ $p->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium mb-1">Jour</label>
                                        <select name="day_of_week" class="w-full px-3 py-2 border rounded-lg">
                                            @foreach(['all'=>'Tous','monday'=>'Lundi','tuesday'=>'Mardi','wednesday'=>'Mercredi','thursday'=>'Jeudi','friday'=>'Vendredi','saturday'=>'Samedi','sunday'=>'Dimanche'] as $k=>$v)
                                                <option value="{{ $k }}">{{ $v }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="grid grid-cols-3 gap-2">
                                    <div><label class="block text-xs font-medium mb-1">Début</label><input name="start_time" type="time" value="15:00" class="w-full px-3 py-2 border rounded-lg"></div>
                                    <div><label class="block text-xs font-medium mb-1">Fin</label><input name="end_time" type="time" value="18:00" class="w-full px-3 py-2 border rounded-lg"></div>
                                    <div><label class="block text-xs font-medium mb-1">-%</label><input name="discount_percent" type="number" min="0" max="90" value="20" required class="w-full px-3 py-2 border rounded-lg"></div>
                                </div>
                            </div>
                            <button class="w-full mt-3 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">Ajouter la règle</button>
                        </form>
                    </div>

                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">Règles actives</h2>
                        @forelse($priceRules as $r)
                            <div class="flex items-center justify-between py-2 border-b border-gray-50">
                                <div>
                                    <p class="text-sm font-medium">{{ $r->name }} <span class="text-red-600 font-semibold">-{{ $r->discount_percent }}%</span></p>
                                    <p class="text-xs text-gray-400">{{ $r->product?->name ?? 'Tous produits' }} · {{ ucfirst($r->day_of_week) }} {{ $r->start_time?->format('H:i') }}–{{ $r->end_time?->format('H:i') }}</p>
                                </div>
                                <form method="POST" action="{{ route('expansion.prices.toggle', $r) }}">
                                    @csrf
                                    <button class="text-xs px-2 py-1 rounded {{ $r->is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500' }}">{{ $r->is_active ? 'Active' : 'Inactive' }}</button>
                                </form>
                            </div>
                        @empty
                            <p class="text-gray-400 text-sm">Aucune règle de prix. Ajoutez une happy hour ci-contre.</p>
                        @endforelse
                    </div>
                </div>
            </div>

            <!-- ===== MODE ÉVÉNEMENT ===== -->
            <div x-show="tab==='event'" x-cloak>
                <div class="grid lg:grid-cols-2 gap-4">
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">🎉 Créer un événement (INN-06)</h2>
                        <form method="POST" action="{{ route('expansion.events.store') }}">
                            @csrf
                            <div class="space-y-2 text-sm">
                                <div><label class="block text-xs font-medium mb-1">Nom</label><input name="name" required class="w-full px-3 py-2 border rounded-lg"></div>
                                <div class="grid grid-cols-2 gap-2">
                                    <div><label class="block text-xs font-medium mb-1">Début</label><input name="starts_at" type="datetime-local" class="w-full px-3 py-2 border rounded-lg"></div>
                                    <div><label class="block text-xs font-medium mb-1">Fin</label><input name="ends_at" type="datetime-local" class="w-full px-3 py-2 border rounded-lg"></div>
                                </div>
                                <div><label class="block text-xs font-medium mb-1">Entrée (FCFA)</label><input name="entry_fee" type="number" min="0" value="5000" class="w-full px-3 py-2 border rounded-lg"></div>
                            </div>
                            <button class="w-full mt-3 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">Créer l'événement</button>
                        </form>
                    </div>

                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <h2 class="font-semibold mb-3">Événements</h2>
                        @forelse($eventModels as $e)
                            <div class="py-2 border-b border-gray-50">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-sm font-medium">{{ $e->name }}</p>
                                        <p class="text-xs text-gray-400">Entrée {{ number_format($e->entry_fee, 0) }} FCFA · {{ $e->products->count() }} produit(s)</p>
                                    </div>
                                    <form method="POST" action="{{ route('expansion.events.toggle', $e) }}">
                                        @csrf
                                        <button class="text-xs px-2 py-1 rounded {{ $e->is_active ? 'bg-brand-600 text-white' : 'bg-gray-100' }}">{{ $e->is_active ? 'Actif' : 'Activer' }}</button>
                                    </form>
                                </div>
                                <!-- Ajouter produit au menu événement -->
                                <form method="POST" action="{{ route('expansion.events.products', $e) }}" class="flex gap-2 mt-2">
                                    @csrf
                                    <select name="product_id" class="flex-1 px-2 py-1 border rounded-lg text-xs">
                                        @foreach($products as $p)<option value="{{ $p->id }}">{{ $p->name }}</option>@endforeach
                                    </select>
                                    <button class="px-2 py-1 bg-gray-100 rounded-lg text-xs">+ Ajouter</button>
                                </form>
                            </div>
                        @empty
                            <p class="text-gray-400 text-sm">Aucun événement créé.</p>
                        @endforelse
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
@endsection
