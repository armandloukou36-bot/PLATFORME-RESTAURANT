@extends('layouts.app')

@section('title', 'Intelligence — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Intelligence</h1>
                    <p class="text-gray-500 text-sm">Prévisions, commandes suggérées, menu engineering</p>
                </div>
                <a href="{{ route('reservations') }}" class="px-4 py-2 bg-white border rounded-lg font-medium hover:bg-gray-50">Réservations</a>
            </div>

            <!-- IA-01 : Prévisions 7 jours -->
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden mb-6">
                <div class="px-4 py-3 bg-gray-50 font-semibold flex items-center justify-between">
                    <span>📈 Prévisions de ventes (7 jours)</span>
                    <span class="text-xs text-gray-400">IA-01</span>
                </div>
                <div class="p-4">
                    <div class="grid grid-cols-7 gap-2">
                        @foreach($weekForecast as $f)
                            <div class="p-3 rounded-lg border {{ $f['confidence'] === 'haute' ? 'bg-brand-50 border-brand-200' : 'bg-gray-50 border-gray-200' }}">
                                <p class="text-xs text-gray-500 font-medium">{{ \Carbon\Carbon::parse($f['date'])->translatedFormat('D d/m') }}</p>
                                <p class="text-lg font-bold text-brand-700 mt-1">{{ number_format($f['revenue_forecast'], 0, ',', ' ') }}</p>
                                <p class="text-xs text-gray-400">FCFA · {{ $f['orders_forecast'] }} cmd</p>
                                <span class="text-[10px] px-1.5 py-0.5 rounded mt-1 inline-block
                                    {{ $f['confidence'] === 'haute' ? 'bg-green-100 text-green-700' : ($f['confidence'] === 'moyenne' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-500') }}">
                                    conf. {{ $f['confidence'] }}
                                </span>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="grid lg:grid-cols-2 gap-6">
                <!-- IA-02 : Commandes fournisseurs suggérées -->
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <div class="px-4 py-3 bg-gray-50 font-semibold flex items-center justify-between">
                        <span>📦 Commandes fournisseurs suggérées</span>
                        <span class="text-xs text-gray-400">IA-02</span>
                    </div>
                    <div class="p-4">
                        @forelse($purchaseSuggestions as $s)
                            <div class="flex items-center justify-between py-2 border-b border-gray-50">
                                <div>
                                    <p class="font-medium text-sm">{{ $s['ingredient'] }}</p>
                                    <p class="text-xs text-gray-400">{{ $s['stock_qty'] }} {{ $s['unit'] }} en stock · couvre {{ $s['stock_days'] }}j</p>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold text-red-600">Commander {{ $s['to_order'] }} {{ $s['unit'] }}</p>
                                    <p class="text-xs text-gray-400">cons. {{ $s['daily_use'] }}/jour</p>
                                </div>
                            </div>
                        @empty
                            <p class="text-gray-400 text-sm">Aucune commande nécessaire — stock suffisant.</p>
                            <p class="text-xs text-gray-400 mt-2">Les suggestions apparaissent quand un ingrédient couvre moins de 7 jours de consommation.</p>
                        @endforelse
                    </div>
                </div>

                <!-- IA-06 : Menu engineering -->
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                    <div class="px-4 py-3 bg-gray-50 font-semibold flex items-center justify-between">
                        <span>🍽️ Menu engineering</span>
                        <span class="text-xs text-gray-400">IA-06</span>
                    </div>
                    <div class="p-4">
                        @if(empty($menuMatrix))
                            <p class="text-gray-400 text-sm">Pas assez de données de vente. Le classement apparaîtra après quelques commandes payées.</p>
                        @else
                        <div class="grid grid-cols-2 gap-3">
                            @php
                                $config = [
                                    'star' => ['⭐', 'Stars', 'Forts et populaires — mettez en avant', 'bg-green-50 border-green-200'],
                                    'cash_cow' => ['🐄', 'Vaches à lait', 'Rentables, peu vendus — à promouvoir', 'bg-blue-50 border-blue-200'],
                                    'puzzle' => ['🧩', 'Énigmes', 'Populaires mais peu rentables — à re-pricer', 'bg-amber-50 border-amber-200'],
                                    'dog' => ['🐕', 'Poids morts', 'Peu vendus et peu rentables — à retirer', 'bg-gray-50 border-gray-200'],
                                ];
                            @endphp
                            @foreach($config as $key => [$icon, $title, $desc, $color])
                                <div class="p-3 rounded-lg border {{ $color }}">
                                    <p class="font-semibold text-sm">{{ $icon }} {{ $title }}</p>
                                    <p class="text-[11px] text-gray-500 mb-2">{{ $desc }}</p>
                                    @foreach($menuGroups->get($key, collect()) as $item)
                                        <p class="text-sm flex justify-between"><span>{{ $item['name'] }}</span><span class="text-gray-400">{{ $item['qty'] }} vds</span></p>
                                    @endforeach
                                    @if($menuGroups->get($key, collect())->isEmpty())
                                        <p class="text-xs text-gray-400">—</p>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
@endsection
