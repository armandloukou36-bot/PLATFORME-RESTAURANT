@extends('layouts.app')

@section('title', 'Réservations — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Réservations</h1>
                    <p class="text-gray-500 text-sm">Gestion des réservations (INN-02)</p>
                </div>
                <button onclick="document.getElementById('resModal').classList.remove('hidden')" class="px-4 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700">+ Nouvelle réservation</button>
            </div>

            @if(session('success'))
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{{ session('success') }}</div>
            @endif

            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-left text-gray-500">
                        <tr>
                            <th class="px-4 py-3">Client</th>
                            <th class="px-4 py-3">Téléphone</th>
                            <th class="px-4 py-3 text-center">Convives</th>
                            <th class="px-4 py-3">Date</th>
                            <th class="px-4 py-3 text-right">Acompte</th>
                            <th class="px-4 py-3">Statut</th>
                            <th class="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach($reservations as $r)
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 font-medium">{{ $r->customer_name }}</td>
                                <td class="px-4 py-3">{{ $r->customer_phone }}</td>
                                <td class="px-4 py-3 text-center">{{ $r->guests }}</td>
                                <td class="px-4 py-3">{{ $r->reserved_at->format('d/m/Y H:i') }}</td>
                                <td class="px-4 py-3 text-right">{{ number_format($r->deposit, 0, ',', ' ') }} FCFA</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-0.5 rounded text-xs font-medium
                                        {{ match($r->status) { 'confirmed' => 'bg-green-100 text-green-700', 'pending' => 'bg-yellow-100 text-yellow-700', 'cancelled' => 'bg-red-100 text-red-700', 'completed' => 'bg-blue-100 text-blue-700', 'no_show' => 'bg-gray-100 text-gray-700', default => 'bg-gray-100' } }}">
                                        {{ $r->status }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-right">
                                    <form method="POST" action="{{ route('reservations.status', $r) }}" class="inline">
                                        @csrf
                                        <select name="status" onchange="this.form.submit()" class="text-xs border rounded px-2 py-1">
                                            <option value="confirmed" {{ $r->status==='confirmed'?'selected':'' }}>Confirmée</option>
                                            <option value="cancelled" {{ $r->status==='cancelled'?'selected':'' }}>Annulée</option>
                                            <option value="completed" {{ $r->status==='completed'?'selected':'' }}>Terminée</option>
                                            <option value="no_show" {{ $r->status==='no_show'?'selected':'' }}>Non venue</option>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @if($reservations->isEmpty())
                    <p class="p-6 text-center text-gray-400">Aucune réservation.</p>
                @endif
            </div>
        </main>
    </div>
</div>

<!-- Modal réservation -->
<div id="resModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-4">Nouvelle réservation</h2>
        <form method="POST" action="{{ route('reservations.store') }}">
            @csrf
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium mb-1">Nom du client</label>
                    <input name="customer_name" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Téléphone</label>
                    <input name="customer_phone" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Convives</label>
                        <input name="guests" type="number" min="1" value="2" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Acompte (FCFA)</label>
                        <input name="deposit" type="number" min="0" value="0" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Date et heure</label>
                    <input name="reserved_at" type="datetime-local" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Note</label>
                    <textarea name="note" rows="2" class="w-full px-3 py-2 border rounded-lg text-sm"></textarea>
                </div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#resModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-brand-600 text-white rounded-lg font-semibold">Confirmer</button>
            </div>
        </form>
    </div>
</div>
@endsection
