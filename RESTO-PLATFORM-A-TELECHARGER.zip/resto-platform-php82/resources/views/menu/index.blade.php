@extends('layouts.app')

@section('title', 'Menu — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Gestion du menu</h1>
                    <p class="text-gray-500 text-sm">{{ $products->count() }} produits · {{ $categories->count() }} catégories</p>
                </div>
                <button onclick="document.getElementById('addModal').classList.remove('hidden')"
                    class="px-4 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700">+ Nouveau produit</button>
            </div>

            @if(session('success'))
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{{ session('success') }}</div>
            @endif

            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-left text-gray-500">
                        <tr>
                            <th class="px-4 py-3">Produit</th>
                            <th class="px-4 py-3">Catégorie</th>
                            <th class="px-4 py-3">Poste</th>
                            <th class="px-4 py-3 text-right">Prix</th>
                            <th class="px-4 py-3 text-center">Prépa.</th>
                            <th class="px-4 py-3 text-center">Dispo</th>
                            <th class="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach($products as $p)
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3">
                                    <p class="font-medium">{{ $p->name }}</p>
                                    <p class="text-xs text-gray-400">{{ $p->description }}</p>
                                </td>
                                <td class="px-4 py-3">{{ $p->category?->name }}</td>
                                <td class="px-4 py-3">{{ $p->station?->name }}</td>
                                <td class="px-4 py-3 text-right font-semibold">{{ number_format($p->price, 0, ',', ' ') }} FCFA</td>
                                <td class="px-4 py-3 text-center">{{ $p->prep_time_min }} min</td>
                                <td class="px-4 py-3 text-center">
                                    <form method="POST" action="{{ route('menu.products.toggle', $p) }}">
                                        @csrf
                                        <button class="px-2 py-1 rounded text-xs font-medium {{ $p->is_available ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                                            {{ $p->is_available ? 'Disponible' : 'Rupture' }}
                                        </button>
                                    </form>
                                </td>
                                <td class="px-4 py-3 text-right">
                                    <button onclick="editProduct({{ $p->id }}, '{{ addslashes($p->name) }}', {{ $p->price }}, {{ $p->category_id }}, {{ $p->station_id }}, '{{ addslashes($p->description ?? '') }}', {{ $p->prep_time_min }}, {{ $p->spice_level }})"
                                        class="text-brand-600 hover:text-brand-800 text-xs font-medium mr-3">Modifier</button>
                                    <button onclick="if(confirm('Supprimer « {{ addslashes($p->name) }} » du menu ?')){document.getElementById('del-{{ $p->id }}').submit();}"
                                        class="text-red-600 hover:text-red-800 text-xs font-medium">Supprimer</button>
                                    <form id="del-{{ $p->id }}" method="POST" action="{{ route('menu.products.destroy', $p) }}" class="hidden">
                                        @csrf @method('DELETE')
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<!-- Modal ajout -->
<div id="addModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-4">Nouveau produit</h2>
        <form method="POST" action="{{ route('menu.products.store') }}">
            @csrf
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium mb-1">Nom</label>
                    <input name="name" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Catégorie</label>
                        <select name="category_id" required class="w-full px-3 py-2 border rounded-lg text-sm">
                            @foreach($categories as $c)
                                <option value="{{ $c->id }}">{{ $c->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Poste</label>
                        <select name="station_id" required class="w-full px-3 py-2 border rounded-lg text-sm">
                            @foreach($stations as $s)
                                <option value="{{ $s->id }}">{{ $s->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Prix (FCFA)</label>
                    <input name="price" type="number" min="0" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Description</label>
                    <textarea name="description" rows="2" class="w-full px-3 py-2 border rounded-lg text-sm"></textarea>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Temps de prépa (min)</label>
                        <input name="prep_time_min" type="number" min="1" value="10" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Piment (0-3)</label>
                        <input name="spice_level" type="number" min="0" max="3" value="0" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                </div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#addModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-brand-600 text-white rounded-lg font-semibold">Ajouter</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal édition -->
<div id="editModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-4">Modifier le produit</h2>
        <form method="POST" id="editForm">
            @csrf
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium mb-1">Nom</label>
                    <input name="name" id="editName" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Catégorie</label>
                        <select name="category_id" id="editCategory" required class="w-full px-3 py-2 border rounded-lg text-sm">
                            @foreach($categories as $c)
                                <option value="{{ $c->id }}">{{ $c->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Poste</label>
                        <select name="station_id" id="editStation" required class="w-full px-3 py-2 border rounded-lg text-sm">
                            @foreach($stations as $s)
                                <option value="{{ $s->id }}">{{ $s->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Prix (FCFA)</label>
                    <input name="price" id="editPrice" type="number" min="0" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Description</label>
                    <textarea name="description" id="editDesc" rows="2" class="w-full px-3 py-2 border rounded-lg text-sm"></textarea>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Temps de prépa (min)</label>
                        <input name="prep_time_min" id="editPrep" type="number" min="1" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Piment (0-3)</label>
                        <input name="spice_level" id="editSpice" type="number" min="0" max="3" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                </div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#editModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-brand-600 text-white rounded-lg font-semibold">Enregistrer</button>
            </div>
        </form>
    </div>
</div>

<script>
function editProduct(id, name, price, catId, stationId, desc, prep, spice) {
    document.getElementById('editForm').action = '/menu/products/' + id;
    document.getElementById('editName').value = name;
    document.getElementById('editPrice').value = price;
    document.getElementById('editCategory').value = catId;
    document.getElementById('editStation').value = stationId;
    document.getElementById('editDesc').value = desc;
    document.getElementById('editPrep').value = prep;
    document.getElementById('editSpice').value = spice;
    document.getElementById('editModal').classList.remove('hidden');
}
</script>
@endsection
