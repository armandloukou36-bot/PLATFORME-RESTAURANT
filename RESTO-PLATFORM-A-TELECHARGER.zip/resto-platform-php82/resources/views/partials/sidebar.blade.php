<aside id="sidebar" :class="$store.sidebar.open ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 z-40 w-60 bg-brand-800 text-white flex flex-col shrink-0 lg:static transition-transform duration-200 lg:!transform-none">
    <div class="p-5 border-b border-brand-700 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <div class="w-9 h-9 rounded-lg bg-accent-500 flex items-center justify-center font-bold text-brand-900">R</div>
            <div>
                <p class="font-bold leading-tight">Resto Platform</p>
                <p class="text-[11px] text-brand-200 truncate">{{ auth()->user()->establishment?->name ?? '—' }}</p>
            </div>
        </div>
        <button @click="$store.sidebar.close()" class="lg:hidden text-white/70 hover:text-white text-xl font-bold">&times;</button>
    </div>

    <nav class="flex-1 p-3 space-y-1 overflow-y-auto scrollbar-thin">
        @php $role = auth()->user()->role; @endphp

        <a href="{{ route('dashboard') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('dashboard') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>📊</span> Tableau de bord
        </a>

        @if(in_array($role, ['server', 'manager', 'owner']))
        <a href="{{ route('floor') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('floor') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>🗺️</span> Plan de salle
        </a>
        @endif

        @if(in_array($role, ['cashier', 'manager', 'owner']))
        <a href="{{ route('pos') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('pos') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>💵</span> Caisse (POS)
        </a>
        @endif

        @if(in_array($role, ['kitchen', 'bar', 'manager', 'owner']))
        <a href="{{ route('kds') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('kds') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>👨‍🍳</span> Cuisine / Bar
        </a>
        @endif

        @if(in_array($role, ['manager', 'owner', 'stock']))
        <a href="{{ route('menu') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('menu') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>📋</span> Menu
        </a>
        <a href="{{ route('reports') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('reports') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>📈</span> Rapports
        </a>
        <a href="{{ route('stock') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('stock*') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
            <span>📦</span> Stocks
        </a>
        @endif

        @if(in_array($role, ['manager', 'owner']))
                <a href="{{ route('intelligence') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('intelligence*') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
                    <span>🧠</span> Intelligence
                </a>
                <a href="{{ route('copilot') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('copilot') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
                    <span>🤖</span> Copilote
                </a>
                <a href="{{ route('expansion') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('expansion*') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
                    <span>🛵</span> Expansion
                </a>
                <a href="{{ route('consolidation') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('consolidation') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
                    <span>🌍</span> Multi-sites
                </a>
                @endif

                @if($role === 'superadmin')
                <a href="{{ route('superadmin.index') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-brand-700 {{ request()->routeIs('superadmin*') ? 'bg-brand-700' : '' }}" @click="$store.sidebar.close()">
                    <span>🛡️</span> Console Super Admin
                </a>
                @endif
    </nav>

    <div class="p-3 border-t border-brand-700">
        <div class="flex items-center gap-3 px-3 py-2">
            <div class="w-8 h-8 rounded-full bg-brand-600 flex items-center justify-center text-sm font-bold">
                {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-sm font-medium truncate">{{ auth()->user()->name }}</p>
                <p class="text-[11px] text-brand-200 capitalize">{{ auth()->user()->role }}</p>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button title="Déconnexion" class="text-brand-200 hover:text-white">⏻</button>
            </form>
        </div>
    </div>
</aside>
