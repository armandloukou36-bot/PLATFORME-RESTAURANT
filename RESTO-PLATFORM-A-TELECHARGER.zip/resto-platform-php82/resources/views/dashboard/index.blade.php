@extends('layouts.app')

@section('title', 'Tableau de bord — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="mb-6">
                <h1 class="text-2xl font-bold">Tableau de bord</h1>
                <p class="text-gray-500 text-sm">{{ now()->translatedFormat('l d F Y') }} — {{ $est->name }}</p>
            </div>

            <!-- KPIs -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">CA du jour</p>
                    <p class="text-2xl font-bold text-brand-700">{{ number_format($revenueToday, 0, ',', ' ') }} FCFA</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Commandes du jour</p>
                    <p class="text-2xl font-bold">{{ $ordersToday }}</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">En cours</p>
                    <p class="text-2xl font-bold text-accent-600">{{ $openOrders }}</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Panier moyen</p>
                    <p class="text-2xl font-bold">{{ number_format($avgBasket, 0, ',', ' ') }} FCFA</p>
                </div>
            </div>

            <div class="grid lg:grid-cols-2 gap-6">
                <!-- Ventes par jour -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Ventes — 7 derniers jours</h2>
                    <div class="flex items-end gap-2 h-40">
                        @php
                            $max = $dailyData->max('total') ?: 1;
                            $days = collect(range(6, 0))->map(fn($d) => now()->subDays($d)->toDateString());
                        @endphp
                        @foreach($days as $day)
                            @php
                                $row = $dailyData->firstWhere('day', $day);
                                $total = $row->total ?? 0;
                                $h = $total > 0 ? max(8, round($total / $max * 100)) : 4;
                            @endphp
                            <div class="flex-1 flex flex-col items-center gap-1">
                                <div class="w-full bg-brand-100 rounded-t" style="height:{{ $h }}px"></div>
                                <span class="text-[10px] text-gray-400">{{ \Carbon\Carbon::parse($day)->format('d/m') }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>

                <!-- Ventes par canal -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Ventes par canal</h2>
                    @foreach($channelData as $c)
                        <div class="flex items-center justify-between py-2 border-b border-gray-50">
                            <span class="capitalize">{{ $c->channel }}</span>
                            <span class="font-semibold">{{ number_format($c->total, 0, ',', ' ') }} FCFA <span class="text-gray-400 text-sm">({{ $c->count }})</span></span>
                        </div>
                    @endforeach
                    @if($channelData->isEmpty())
                        <p class="text-gray-400 text-sm">Aucune vente sur la période.</p>
                    @endif
                </div>

                <!-- Top produits -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Top produits (7 jours)</h2>
                    @foreach($topProducts as $p)
                        <div class="flex items-center justify-between py-2 border-b border-gray-50">
                            <span>{{ $p->product_name }}</span>
                            <span class="font-semibold text-brand-700">{{ $p->qty }} vendus</span>
                        </div>
                    @endforeach
                    @if($topProducts->isEmpty())
                        <p class="text-gray-400 text-sm">Aucune vente.</p>
                    @endif
                </div>

                <!-- Alertes -->
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <h2 class="font-semibold mb-4">Alertes & anomalies (24h)</h2>
                    @forelse($anomalies as $a)
                        <div class="p-3 rounded-lg mb-2 {{ $a['type'] === 'danger' ? 'bg-red-50 border border-red-200' : 'bg-amber-50 border border-amber-200' }}">
                            <p class="text-sm font-semibold {{ $a['type'] === 'danger' ? 'text-red-700' : 'text-amber-700' }}">
                                {{ $a['type'] === 'danger' ? '🔴' : '🟡' }} {{ $a['title'] }}
                            </p>
                            <p class="text-xs text-gray-600 mt-1">{{ $a['detail'] }}</p>
                        </div>
                    @empty
                        <p class="text-sm text-green-600">✅ Aucune anomalie détectée.</p>
                    @endforelse
                    <p class="text-xs text-gray-400 mt-3">Annulations, remises et écarts sont analysés automatiquement.</p>
                </div>
            </div>
        </main>
    </div>
</div>
@endsection
