@extends('layouts.app')

@section('title', 'Stocks — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Gestion des stocks</h1>
                    <p class="text-gray-500 text-sm">Fiches techniques, réceptions, pertes, inventaire</p>
                </div>
                <div class="flex gap-2">
                    <a href="{{ route('stock.movements') }}" class="px-4 py-2 bg-white border rounded-lg font-medium hover:bg-gray-50">Mouvements</a>
                    <button onclick="document.getElementById('ingModal').classList.remove('hidden')" class="px-4 py-2 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700">+ Ingrédient</button>
                </div>
            </div>

            @if(session('success'))
                <div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-700 text-sm">{{ session('success') }}</div>
            @endif

            <!-- KPIs stock -->
            <div class="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Valeur du stock</p>
                    <p class="text-2xl font-bold text-brand-700">{{ number_format($stockValue, 0, ',', ' ') }} FCFA</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Ingrédients</p>
                    <p class="text-2xl font-bold">{{ $ingredients->count() }}</p>
                </div>
                <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                    <p class="text-sm text-gray-500">Alertes stock bas</p>
                    <p class="text-2xl font-bold {{ $lowStock->count() > 0 ? 'text-red-600' : 'text-green-600' }}">{{ $lowStock->count() }}</p>
                </div>
            </div>

            <!-- Alertes stock bas -->
            @if($lowStock->isNotEmpty())
                <div class="mb-6 p-4 rounded-xl bg-red-50 border border-red-200">
                    <h2 class="font-semibold text-red-700 mb-2">⚠️ Stock bas — à réapprovisionner</h2>
                    <div class="flex flex-wrap gap-2">
                        @foreach($lowStock as $i)
                            <span class="px-3 py-1 bg-white rounded-full text-sm border border-red-200">{{ $i->name }} ({{ $i->stock_qty }} {{ $i->unit }})</span>
                        @endforeach
                    </div>
                </div>
            @endif

            <!-- Table ingrédients -->
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden mb-6">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-left text-gray-500">
                        <tr>
                            <th class="px-4 py-3">Ingrédient</th>
                            <th class="px-4 py-3">Dépôt</th>
                            <th class="px-4 py-3 text-right">Stock</th>
                            <th class="px-4 py-3 text-right">Seuil</th>
                            <th class="px-4 py-3 text-right">Coût unit.</th>
                            <th class="px-4 py-3 text-right">Valeur</th>
                            <th class="px-4 py-3 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach($ingredients as $i)
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 font-medium">{{ $i->name }}</td>
                                <td class="px-4 py-3">{{ $i->depot?->name ?? '—' }}</td>
                                <td class="px-4 py-3 text-right {{ $i->isLowStock() ? 'text-red-600 font-semibold' : '' }}">{{ $i->stock_qty }} {{ $i->unit }}</td>
                                <td class="px-4 py-3 text-right text-gray-400">{{ $i->min_stock }}</td>
                                <td class="px-4 py-3 text-right">{{ number_format($i->cost, 0, ',', ' ') }} FCFA</td>
                                <td class="px-4 py-3 text-right">{{ number_format($i->stock_qty * $i->cost, 0, ',', ' ') }} FCFA</td>
                                <td class="px-4 py-3 text-center">
                                    <button onclick="openReceive({{ $i->id }}, '{{ addslashes($i->name) }}')" class="text-green-600 hover:text-green-800 text-xs font-medium">Réception</button>
                                    <button onclick="openLoss({{ $i->id }}, '{{ addslashes($i->name) }}')" class="text-red-600 hover:text-red-800 text-xs font-medium ml-2">Perte</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Fiches techniques -->
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="px-4 py-3 bg-gray-50 font-semibold">Fiches techniques (recettes)</div>
                <div class="p-4">
                    <form method="POST" action="{{ route('stock.recipes.store') }}" class="flex gap-2 flex-wrap items-end">
                        @csrf
                        <div>
                            <label class="block text-xs text-gray-500 mb-1">Produit</label>
                            <select name="product_id" required class="px-3 py-2 border rounded-lg text-sm">
                                @foreach($products as $p)
                                    <option value="{{ $p->id }}">{{ $p->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs text-gray-500 mb-1">Ingrédient</label>
                            <select name="ingredient_id" required class="px-3 py-2 border rounded-lg text-sm">
                                @foreach($ingredients as $i)
                                    <option value="{{ $i->id }}">{{ $i->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs text-gray-500 mb-1">Quantité</label>
                            <input name="quantity" type="number" step="0.001" min="0.001" required class="px-3 py-2 border rounded-lg text-sm w-28">
                        </div>
                        <button class="px-4 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium">Ajouter à la fiche</button>
                    </form>
                    <p class="text-xs text-gray-400 mt-2">Chaque vente déstocke automatiquement les ingrédients de la fiche technique du produit.</p>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modal ingrédient -->
<div id="ingModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-4">Nouvel ingrédient</h2>
        <form method="POST" action="{{ route('stock.ingredients.store') }}">
            @csrf
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium mb-1">Nom</label>
                    <input name="name" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Unité</label>
                        <select name="unit" class="w-full px-3 py-2 border rounded-lg text-sm">
                            <option value="g">gramme (g)</option>
                            <option value="kg">kilo (kg)</option>
                            <option value="l">litre (l)</option>
                            <option value="cl">centilitre (cl)</option>
                            <option value="unité">unité</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Dépôt</label>
                        <select name="depot_id" class="w-full px-3 py-2 border rounded-lg text-sm">
                            <option value="">—</option>
                            @foreach($depots as $d)
                                <option value="{{ $d->id }}">{{ $d->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium mb-1">Seuil d'alerte</label>
                        <input name="min_stock" type="number" step="0.001" value="0" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Coût unitaire (FCFA)</label>
                        <input name="cost" type="number" step="0.01" value="0" class="w-full px-3 py-2 border rounded-lg text-sm">
                    </div>
                </div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#ingModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-brand-600 text-white rounded-lg font-semibold">Ajouter</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal réception -->
<div id="recvModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-1">Réception fournisseur</h2>
        <p class="text-sm text-gray-500 mb-4" id="recvName"></p>
        <form method="POST" action="{{ route('stock.receive') }}">
            @csrf
            <input type="hidden" name="ingredient_id" id="recvIngId">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium mb-1">Quantité reçue</label>
                    <input name="quantity" type="number" step="0.001" min="0.001" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Coût unitaire (FCFA)</label>
                    <input name="unit_cost" type="number" step="0.01" min="0" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Référence (n° facture)</label>
                    <input name="reference" class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#recvModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-green-600 text-white rounded-lg font-semibold">Enregistrer</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal perte -->
<div id="lossModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.classList.add('hidden')"></div>
    <div class="absolute inset-0 m-auto w-full max-w-md h-fit bg-white rounded-2xl shadow-2xl p-6">
        <h2 class="font-bold text-lg mb-1">Déclarer une perte</h2>
        <p class="text-sm text-gray-500 mb-4" id="lossName"></p>
        <form method="POST" action="{{ route('stock.loss') }}">
            @csrf
            <input type="hidden" name="ingredient_id" id="lossIngId">
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-medium mb-1">Quantité perdue</label>
                    <input name="quantity" type="number" step="0.001" min="0.001" required class="w-full px-3 py-2 border rounded-lg text-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Motif</label>
                    <select name="reason" required class="w-full px-3 py-2 border rounded-lg text-sm">
                        <option value="casse">Casse</option>
                        <option value="perime">Périmé</option>
                        <option value="repas_personnel">Repas du personnel</option>
                        <option value="autre">Autre</option>
                    </select>
                </div>
            </div>
            <div class="flex gap-2 mt-5">
                <button type="button" onclick="this.closest('#lossModal').classList.add('hidden')" class="flex-1 py-2.5 border rounded-lg font-medium">Annuler</button>
                <button type="submit" class="flex-1 py-2.5 bg-red-600 text-white rounded-lg font-semibold">Déclarer</button>
            </div>
        </form>
    </div>
</div>

<script>
function openReceive(id, name) {
    document.getElementById('recvIngId').value = id;
    document.getElementById('recvName').textContent = name;
    document.getElementById('recvModal').classList.remove('hidden');
}
function openLoss(id, name) {
    document.getElementById('lossIngId').value = id;
    document.getElementById('lossName').textContent = name;
    document.getElementById('lossModal').classList.remove('hidden');
}
</script>
@endsection
