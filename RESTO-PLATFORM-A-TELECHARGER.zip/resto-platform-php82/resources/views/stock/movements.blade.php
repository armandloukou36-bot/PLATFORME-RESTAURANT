@extends('layouts.app')

@section('title', 'Mouvements de stock — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-6 overflow-y-auto">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold">Mouvements de stock</h1>
                    <p class="text-gray-500 text-sm">Entrées, sorties, ventes, pertes — traçabilité complète</p>
                </div>
                <a href="{{ route('stock') }}" class="px-4 py-2 bg-white border rounded-lg font-medium hover:bg-gray-50">← Retour stocks</a>
            </div>

            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 text-left text-gray-500">
                        <tr>
                            <th class="px-4 py-3">Date</th>
                            <th class="px-4 py-3">Ingrédient</th>
                            <th class="px-4 py-3">Type</th>
                            <th class="px-4 py-3 text-right">Quantité</th>
                            <th class="px-4 py-3 text-right">Coût</th>
                            <th class="px-4 py-3">Référence</th>
                            <th class="px-4 py-3">Utilisateur</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach($movements as $m)
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 text-gray-500">{{ $m->created_at->format('d/m H:i') }}</td>
                                <td class="px-4 py-3 font-medium">{{ $m->ingredient?->name }}</td>
                                <td class="px-4 py-3">
                                    @php
                                        $colors = ['in' => 'bg-green-100 text-green-700', 'sale' => 'bg-blue-100 text-blue-700', 'loss' => 'bg-red-100 text-red-700', 'out' => 'bg-gray-100 text-gray-700'];
                                    @endphp
                                    <span class="px-2 py-0.5 rounded text-xs font-medium {{ $colors[$m->type] ?? 'bg-gray-100' }}">
                                        {{ match($m->type) { 'in' => 'Entrée', 'sale' => 'Vente', 'loss' => 'Perte', 'out' => 'Sortie', default => $m->type } }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-right font-semibold {{ $m->quantity < 0 ? 'text-red-600' : 'text-green-600' }}">{{ $m->quantity }} {{ $m->ingredient?->unit }}</td>
                                <td class="px-4 py-3 text-right">{{ number_format($m->unit_cost, 0, ',', ' ') }} FCFA</td>
                                <td class="px-4 py-3 text-gray-500">{{ $m->reference ?? ($m->reason ?? '—') }}</td>
                                <td class="px-4 py-3">{{ $m->user?->name ?? '—' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @if($movements->isEmpty())
                    <p class="p-6 text-center text-gray-400">Aucun mouvement enregistré.</p>
                @endif
            </div>
        </main>
    </div>
</div>
@endsection
