@extends('layouts.app')

@section('title', 'Copilote — ' . $est->name)

@section('body')
<div class="min-h-screen flex">
    @include('partials.sidebar')

    <div class="flex-1 flex flex-col min-w-0">
        @include('partials.topbar')

        <main class="flex-1 p-4 lg:p-6 overflow-y-auto">
            <div class="max-w-2xl mx-auto">
                <div class="mb-6">
                    <h1 class="text-2xl font-bold">🤖 Copilote IA</h1>
                    <p class="text-gray-500 text-sm">Posez vos questions par écrit ou à la voix (IA-04)</p>
                </div>

                <div class="bg-white rounded-2xl border border-gray-200 shadow-sm flex flex-col h-[60vh]">
                    <!-- Zone conversation -->
                    <div id="chatBox" class="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
                        <div class="flex items-start gap-2">
                            <div class="w-8 h-8 rounded-full bg-brand-600 text-white flex items-center justify-center text-sm shrink-0">🤖</div>
                            <div class="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm max-w-[80%]">
                                Bonjour ! Je peux vous renseigner sur la marge des plats, le chiffre d'affaires, les top produits, le stock bas, les commandes en cours et les prévisions.
                            </div>
                        </div>
                    </div>

                    <!-- Saisie -->
                    <div class="p-3 border-t">
                        <div class="flex items-center gap-2">
                            <button onclick="toggleVoice()" id="voiceBtn" class="w-11 h-11 rounded-full bg-brand-600 hover:bg-brand-700 text-white flex items-center justify-center shrink-0" title="Parler">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 18v-6a4 4 0 00-4-4H6a4 4 0 00-4 4v6a4 4 0 004 4h2a4 4 0 004-4zM6 8V6a6 6 0 0112 0v2"/><path d="M19 10v2a3 3 0 01-3 3"/></svg>
                            </button>
                            <input id="questionInput" placeholder="Ex : Quel plat a la meilleure marge ? ou CA du jour ?" class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none text-sm">
                            <button onclick="ask()" class="px-5 py-2.5 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700 shrink-0">Envoyer</button>
                        </div>
                        <p class="text-[11px] text-gray-400 mt-2">💡 Suggestions : « marge », « CA du jour », « top produits », « stock bas », « prévision »</p>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
let listening = false;
function addMsg(role, text) {
    const chat = document.getElementById('chatBox');
    const isBot = role === 'bot';
    const div = document.createElement('div');
    div.className = 'flex items-start gap-2 ' + (isBot ? '' : 'justify-end');
    div.innerHTML = isBot
        ? `<div class="w-8 h-8 rounded-full bg-brand-600 text-white flex items-center justify-center text-sm shrink-0">🤖</div>
           <div class="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm max-w-[80%]">${text}</div>`
        : `<div class="bg-brand-600 text-white rounded-lg px-3 py-2 text-sm max-w-[80%]">${text}</div>`;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

async function ask() {
    const q = document.getElementById('questionInput').value.trim();
    if (!q) return;
    addMsg('user', q);
    document.getElementById('questionInput').value = '';
    const res = await fetch('/copilot/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        body: JSON.stringify({ question: q })
    });
    const data = await res.json();
    addMsg('bot', data.answer);
}

function toggleVoice() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert('La reconnaissance vocale n\'est pas supportée par ce navigateur. Utilisez Chrome.');
        return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = 'fr-FR';
    rec.interimResults = false;
    document.getElementById('voiceBtn').classList.add('bg-red-500');
    rec.onresult = (e) => {
        const text = e.results[0][0].transcript;
        document.getElementById('questionInput').value = text;
        document.getElementById('voiceBtn').classList.remove('bg-red-500');
        ask();
    };
    rec.onerror = () => document.getElementById('voiceBtn').classList.remove('bg-red-500');
    rec.onend = () => document.getElementById('voiceBtn').classList.remove('bg-red-500');
    rec.start();
}

// Touche Entrée pour envoyer
document.getElementById('questionInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') ask(); });
</script>
@endsection
