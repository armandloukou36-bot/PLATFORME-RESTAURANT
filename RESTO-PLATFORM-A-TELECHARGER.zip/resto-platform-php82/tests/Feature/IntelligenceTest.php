<?php

namespace Tests\Feature;

use App\Models\Depot;
use App\Models\Establishment;
use App\Models\Ingredient;
use App\Models\Order;
use App\Models\Product;
use App\Models\RecipeItem;
use App\Models\Reservation;
use App\Models\User;
use App\Services\ForecastService;
use App\Services\MenuEngineeringService;
use App\Services\PurchaseSuggestionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class IntelligenceTest extends TestCase
{
    use RefreshDatabase;

    private Establishment $est;
    private User $manager;

    protected function setUp(): void
    {
        parent::setUp();
        $this->est = Establishment::create(['name' => 'Test', 'currency' => 'FCFA']);
        $this->manager = User::create([
            'establishment_id' => $this->est->id, 'name' => 'Gérant',
            'email' => 'g@test.ci', 'password' => 'password', 'role' => 'manager', 'is_active' => true,
        ]);
    }

    private function createOrderWithSales(float $total, int $daysAgo = 1): void
    {
        Order::create([
            'establishment_id' => $this->est->id,
            'user_id' => $this->manager->id,
            'order_number' => '#' . random_int(1000, 9999),
            'status' => 'paid',
            'total' => $total,
            'created_at' => now()->subDays($daysAgo),
            'paid_at' => now()->subDays($daysAgo)->addMinutes(10),
        ]);
    }

    public function test_forecast_service_returns_predictions(): void
    {
        // Historique de ventes
        for ($i = 0; $i < 14; $i++) {
            $this->createOrderWithSales(5000, $i);
        }

        $forecast = app(ForecastService::class)->forecast($this->est->id);
        $this->assertArrayHasKey('revenue_forecast', $forecast);
        $this->assertArrayHasKey('confidence', $forecast);
        $this->assertGreaterThan(0, $forecast['revenue_forecast']);

        $week = app(ForecastService::class)->forecastWeek($this->est->id);
        $this->assertCount(7, $week);
    }

    public function test_intelligence_page_accessible(): void
    {
        $this->actingAs($this->manager)->get('/intelligence')->assertOk()->assertSee('Intelligence');
    }

    public function test_purchase_suggestion_detects_low_stock(): void
    {
        $depot = Depot::create(['establishment_id' => $this->est->id, 'name' => 'Réserve']);
        $ing = Ingredient::create([
            'establishment_id' => $this->est->id, 'depot_id' => $depot->id,
            'name' => 'Banane', 'unit' => 'g', 'stock_qty' => 100, 'min_stock' => 50, 'cost' => 300,
        ]);

        // Consommation : 700g sur 7 jours = 100g/jour
        \App\Models\StockMovement::create([
            'establishment_id' => $this->est->id, 'ingredient_id' => $ing->id,
            'depot_id' => $depot->id, 'type' => 'sale', 'quantity' => -700,
            'unit_cost' => 300, 'reference' => 'test', 'created_at' => now()->subDays(7),
        ]);

        $suggestions = app(PurchaseSuggestionService::class)->suggest($this->est->id, 7);
        $this->assertNotEmpty($suggestions);
        $this->assertEquals('Banane', $suggestions[0]['ingredient']);
        $this->assertGreaterThan(0, $suggestions[0]['to_order']);
    }

    public function test_menu_engineering_classifies_products(): void
    {
        $depot = Depot::create(['establishment_id' => $this->est->id, 'name' => 'Réserve']);
        $ing = Ingredient::create([
            'establishment_id' => $this->est->id, 'depot_id' => $depot->id,
            'name' => 'Ing', 'unit' => 'g', 'stock_qty' => 1000, 'min_stock' => 0, 'cost' => 100,
        ]);
        $product = Product::create([
            'establishment_id' => $this->est->id, 'name' => 'Alloco', 'price' => 1500,
            'is_active' => true, 'is_available' => true,
        ]);
        RecipeItem::create([
            'establishment_id' => $this->est->id, 'product_id' => $product->id,
            'ingredient_id' => $ing->id, 'quantity' => 100,
        ]);

        // Commande payée contenant Alloco
        $order = Order::create([
            'establishment_id' => $this->est->id, 'user_id' => $this->manager->id,
            'order_number' => '#0001', 'status' => 'paid', 'total' => 1500,
            'created_at' => now(), 'paid_at' => now(),
        ]);
        $order->items()->create([
            'product_id' => $product->id, 'product_name' => 'Alloco',
            'unit_price' => 1500, 'quantity' => 10, 'status' => 'served',
        ]);

        $matrix = app(MenuEngineeringService::class)->analyze($this->est->id);
        $this->assertNotEmpty($matrix);
        $this->assertArrayHasKey('category', $matrix[0]);
        $this->assertContains($matrix[0]['category'], ['star', 'cash_cow', 'puzzle', 'dog']);
    }

    public function test_reservation_crud(): void
    {
        $this->actingAs($this->manager);

        $this->post('/reservations', [
            'customer_name' => 'Jean', 'customer_phone' => '+2250700000000',
            'guests' => 4, 'reserved_at' => now()->addDay()->format('Y-m-d H:i'),
        ])->assertRedirect();

        $res = Reservation::first();
        $this->assertEquals('confirmed', $res->status);

        $this->post("/reservations/{$res->id}/status", ['status' => 'completed'])->assertRedirect();
        $this->assertEquals('completed', $res->fresh()->status);
    }
}
