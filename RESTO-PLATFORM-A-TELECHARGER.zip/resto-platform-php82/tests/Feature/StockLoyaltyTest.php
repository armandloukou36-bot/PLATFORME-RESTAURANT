<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\Depot;
use App\Models\Establishment;
use App\Models\Ingredient;
use App\Models\Order;
use App\Models\Product;
use App\Models\RecipeItem;
use App\Models\Table;
use App\Models\User;
use App\Services\AnomalyService;
use App\Services\LoyaltyService;
use App\Services\StockService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class StockLoyaltyTest extends TestCase
{
    use RefreshDatabase;

    private Establishment $est;
    private User $manager;
    private Table $table;
    private Product $product;
    private Ingredient $ingredient;

    protected function setUp(): void
    {
        parent::setUp();
        $this->est = Establishment::create(['name' => 'Test', 'currency' => 'FCFA']);
        $this->manager = User::create([
            'establishment_id' => $this->est->id, 'name' => 'Gérant',
            'email' => 'g@test.ci', 'password' => 'password', 'role' => 'manager', 'is_active' => true,
        ]);
        $this->table = Table::create([
            'establishment_id' => $this->est->id, 'name' => 'T1', 'qr_token' => 'qrcode123', 'status' => 'free',
        ]);
        $depot = Depot::create(['establishment_id' => $this->est->id, 'name' => 'Réserve']);
        $this->ingredient = Ingredient::create([
            'establishment_id' => $this->est->id, 'depot_id' => $depot->id,
            'name' => 'Banane', 'unit' => 'g', 'stock_qty' => 1000, 'min_stock' => 100, 'cost' => 300,
        ]);
        $this->product = Product::create([
            'establishment_id' => $this->est->id, 'name' => 'Alloco', 'price' => 1500,
            'is_active' => true, 'is_available' => true,
        ]);
        RecipeItem::create([
            'establishment_id' => $this->est->id, 'product_id' => $this->product->id,
            'ingredient_id' => $this->ingredient->id, 'quantity' => 250,
        ]);
    }

    public function test_destock_order_reduces_ingredient_stock(): void
    {
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->manager->id, 'order_number' => '#0001', 'status' => 'paid',
        ]);
        $order->items()->create([
            'product_id' => $this->product->id, 'product_name' => 'Alloco',
            'unit_price' => 1500, 'quantity' => 2, 'status' => 'served',
        ]);

        app(StockService::class)->destockOrder($order);

        // 2 × 250g = 500g déstockés
        $this->assertEquals(500, $this->ingredient->fresh()->stock_qty);
        $this->assertDatabaseHas('stock_movements', ['type' => 'sale', 'reference' => '#0001']);
    }

    public function test_receive_increases_stock_and_logs(): void
    {
        app(StockService::class)->receive($this->ingredient->id, 500, 350, 'FAC-001');
        $this->assertEquals(1500, $this->ingredient->fresh()->stock_qty);
        $this->assertEquals(350, $this->ingredient->fresh()->cost);
        $this->assertDatabaseHas('stock_movements', ['type' => 'in', 'reference' => 'FAC-001']);
    }

    public function test_loss_decreases_stock(): void
    {
        app(StockService::class)->loss($this->ingredient->id, 200, 'casse');
        $this->assertEquals(800, $this->ingredient->fresh()->stock_qty);
        $this->assertDatabaseHas('stock_movements', ['type' => 'loss', 'reason' => 'casse']);
    }

    public function test_loyalty_earns_points_on_paid_order(): void
    {
        $order = Order::create([
            'establishment_id' => $this->est->id, 'user_id' => $this->manager->id,
            'order_number' => '#0001', 'status' => 'paid', 'total' => 5000,
        ]);

        $customer = app(LoyaltyService::class)->earnPoints($order, '+2250700000000');

        $this->assertNotNull($customer);
        $this->assertEquals(5, $customer->fresh()->loyalty_points);
        $this->assertEquals(5000, $customer->fresh()->total_spent);
        $this->assertDatabaseHas('loyalty_transactions', ['type' => 'earn', 'points' => 5]);
    }

    public function test_client_can_order_via_qr_code(): void
    {
        $this->get("/m/qrcode123")->assertOk()->assertSee('Alloco');

        $this->postJson('/m/qrcode123/order', [
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
            'customer_phone' => '+2250700000000',
        ])->assertOk()->assertJson(['status' => 'sent']);

        $order = Order::first();
        $this->assertEquals(1500, $order->total);
        $this->assertEquals('sent', $order->status);
    }

    public function test_anomaly_detection_flags_paid_then_cancelled(): void
    {
        Order::create([
            'establishment_id' => $this->est->id, 'user_id' => $this->manager->id,
            'order_number' => '#0001', 'status' => 'cancelled', 'paid_at' => now(),
        ]);

        $anomalies = app(AnomalyService::class)->detect($this->est->id);
        $this->assertNotEmpty($anomalies);
        $this->assertStringContainsString('Annulations après encaissement', $anomalies[0]['title']);
    }

    public function test_stock_page_accessible_by_manager(): void
    {
        $this->actingAs($this->manager)->get('/stock')->assertOk()->assertSee('Gestion des stocks');
    }
}
