<?php

namespace Tests\Feature;

use App\Models\Establishment;
use App\Models\Order;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OrderFlowTest extends TestCase
{
    use RefreshDatabase;

    private Establishment $est;
    private User $server;
    private Table $table;
    private Product $product;

    protected function setUp(): void
    {
        parent::setUp();
        $this->est = Establishment::create(['name' => 'Test Resto', 'currency' => 'FCFA']);
        $this->server = User::create([
            'establishment_id' => $this->est->id,
            'name' => 'Serveur', 'email' => 's@test.ci', 'password' => 'password',
            'role' => 'server', 'is_active' => true, 'pin' => '3456',
        ]);
        $this->table = Table::create([
            'establishment_id' => $this->est->id, 'name' => 'T1', 'qr_token' => 'abc', 'status' => 'free',
        ]);
        $this->product = Product::create([
            'establishment_id' => $this->est->id, 'name' => 'Alloco', 'price' => 1500,
            'is_active' => true, 'is_available' => true,
        ]);
    }

    public function test_authenticated_user_can_access_floor(): void
    {
        $this->actingAs($this->server)
            ->get('/floor')
            ->assertOk()
            ->assertSee('Plan de salle');
    }

    public function test_create_order_and_add_item(): void
    {
        $this->actingAs($this->server);

        $res = $this->postJson('/orders', [
            'table_id' => $this->table->id, 'channel' => 'dine_in', 'guest_count' => 2,
        ])->assertOk()->json('order');

        $this->assertEquals('open', $res['status']);
        $this->assertEquals('#0001', $res['order_number']);

        $this->postJson("/orders/{$res['id']}/items", [
            'product_id' => $this->product->id, 'quantity' => 2,
        ])->assertOk();

        $order = Order::find($res['id']);
        $this->assertEquals(3000, $order->total);
        $this->assertEquals(1, $order->items()->count());
    }

    public function test_send_order_to_kitchen_creates_event(): void
    {
        $this->actingAs($this->server);
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->server->id, 'order_number' => '#0001', 'status' => 'open',
        ]);
        $order->items()->create([
            'product_id' => $this->product->id, 'product_name' => 'Alloco',
            'unit_price' => 1500, 'quantity' => 1, 'status' => 'new',
        ]);

        $this->post("/orders/{$order->id}/send")->assertOk();

        $this->assertEquals('sent', $order->fresh()->status);
        $this->assertDatabaseHas('events', ['type' => 'order.sent']);
    }

    public function test_pay_order_marks_paid_and_table_to_clean(): void
    {
        $this->actingAs($this->server);
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->server->id, 'order_number' => '#0001', 'status' => 'sent',
            'subtotal' => 1500, 'total' => 1500,
        ]);

        $this->postJson("/orders/{$order->id}/pay", [
            'payments' => [['method' => 'cash', 'amount' => 1500, 'change_due' => 0]],
        ])->assertOk();

        $this->assertEquals('paid', $order->fresh()->status);
        $this->assertEquals('to_clean', $this->table->fresh()->status);
        $this->assertDatabaseHas('payments', ['order_id' => $order->id, 'method' => 'cash']);
    }

    public function test_cancel_order_requires_reason_and_logs_audit(): void
    {
        $this->actingAs($this->server);
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->server->id, 'order_number' => '#0001', 'status' => 'open',
        ]);

        $this->postJson("/orders/{$order->id}/cancel", ['reason' => 'Client parti', 'pin' => '3456'])
            ->assertOk();

        $this->assertEquals('cancelled', $order->fresh()->status);
        $this->assertDatabaseHas('audit_logs', ['action' => 'order.cancelled']);
    }

    public function test_cannot_access_other_establishment_order(): void
    {
        $other = Establishment::create(['name' => 'Autre']);
        $otherOrder = Order::create([
            'establishment_id' => $other->id, 'order_number' => '#9999', 'status' => 'open',
        ]);

        $this->actingAs($this->server)
            ->getJson("/orders/{$otherOrder->id}")
            ->assertForbidden();
    }
}
