<?php

namespace Tests\Feature;

use App\Models\Courier;
use App\Models\Delivery;
use App\Models\Establishment;
use App\Models\EventModel;
use App\Models\Order;
use App\Models\PriceRule;
use App\Models\Product;
use App\Models\User;
use App\Services\PricingService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ExpansionTest extends TestCase
{
    use RefreshDatabase;

    private Establishment $est;
    private User $manager;

    protected function setUp(): void
    {
        parent::setUp();
        $this->est = Establishment::create(['name' => 'Test', 'currency' => 'FCFA']);
        $this->manager = User::create([
            'establishment_id' => $this->est->id, 'name' => 'Gérant',
            'email' => 'g@test.ci', 'password' => 'password', 'role' => 'manager', 'is_active' => true,
        ]);
    }

    public function test_expansion_page_accessible(): void
    {
        $this->actingAs($this->manager)->get('/expansion')->assertOk()->assertSee('Expansion');
    }

    public function test_create_courier(): void
    {
        $this->actingAs($this->manager)
            ->post('/expansion/couriers', ['name' => 'Yao', 'phone' => '0700000001', 'vehicle' => 'moto'])
            ->assertRedirect();

        $this->assertDatabaseHas('couriers', ['name' => 'Yao', 'is_available' => true]);
    }

    public function test_create_delivery_and_mark_delivered_pays_order(): void
    {
        $this->actingAs($this->manager);

        $courier = Courier::create([
            'establishment_id' => $this->est->id, 'name' => 'Yao', 'phone' => '0700000001',
        ]);
        $order = Order::create([
            'establishment_id' => $this->est->id, 'user_id' => $this->manager->id,
            'order_number' => '#0001', 'channel' => 'delivery', 'status' => 'sent',
            'total' => 3500, 'subtotal' => 3500,
        ]);

        $this->post('/expansion/deliveries', [
            'order_id' => $order->id, 'courier_id' => $courier->id,
            'contact_name' => 'Client', 'contact_phone' => '0700000002',
            'address' => 'Cocody', 'delivery_fee' => 1000,
        ])->assertRedirect();

        $delivery = Delivery::first();
        $this->assertEquals('assigned', $delivery->status);

        // Marquer livrée → encaissement
        $this->post("/expansion/deliveries/{$delivery->id}/status", [
            'status' => 'delivered', 'payment_method' => 'cash', 'collected_amount' => 4500,
        ])->assertRedirect();

        $this->assertEquals('delivered', $delivery->fresh()->status);
        $this->assertEquals('paid', $order->fresh()->status);
        $this->assertDatabaseHas('payments', ['order_id' => $order->id, 'method' => 'cash', 'amount' => 4500]);
    }

    public function test_price_rule_applies_discount(): void
    {
        $product = Product::create([
            'establishment_id' => $this->est->id, 'name' => 'Bissap', 'price' => 1000,
            'is_active' => true, 'is_available' => true,
        ]);
        PriceRule::create([
            'establishment_id' => $this->est->id, 'product_id' => $product->id,
            'name' => 'Happy hour', 'day_of_week' => 'all',
            'start_time' => '00:00', 'end_time' => '23:59', 'discount_percent' => 20, 'is_active' => true,
        ]);

        $result = app(PricingService::class)->effectivePrice($product);
        $this->assertEquals(800, $result['effective_price']);
        $this->assertEquals(20, $result['discount_percent']);
        $this->assertTrue($result['is_discounted']);
    }

    public function test_price_rule_outside_hours_no_discount(): void
    {
        $product = Product::create([
            'establishment_id' => $this->est->id, 'name' => 'Bissap', 'price' => 1000,
            'is_active' => true, 'is_available' => true,
        ]);
        PriceRule::create([
            'establishment_id' => $this->est->id, 'product_id' => $product->id,
            'name' => 'Happy hour', 'day_of_week' => 'all',
            'start_time' => '09:00', 'end_time' => '10:00', 'discount_percent' => 20, 'is_active' => true,
        ]);

        // À 15h, hors plage → pas de remise
        $result = app(PricingService::class)->effectivePrice($product, now()->setTime(15, 0));
        $this->assertFalse($result['is_discounted']);
        $this->assertEquals(1000, $result['effective_price']);
    }

    public function test_event_model_crud(): void
    {
        $this->actingAs($this->manager)
            ->post('/expansion/events', ['name' => 'Soirée VIP', 'entry_fee' => 5000])
            ->assertRedirect();

        $event = EventModel::first();
        $this->assertEquals('Soirée VIP', $event->name);
        $this->assertFalse($event->is_active);

        $this->post("/expansion/events/{$event->id}/toggle")->assertRedirect();
        $this->assertTrue($event->fresh()->is_active);
    }
}
