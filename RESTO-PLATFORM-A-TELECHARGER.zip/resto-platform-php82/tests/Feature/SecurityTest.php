<?php

namespace Tests\Feature;

use App\Models\Establishment;
use App\Models\Order;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SecurityTest extends TestCase
{
    use RefreshDatabase;

    private Establishment $est;
    private Establishment $otherEst;
    private User $server;
    private User $manager;
    private Table $table;

    protected function setUp(): void
    {
        parent::setUp();
        $this->est = Establishment::create(['name' => 'Resto A']);
        $this->otherEst = Establishment::create(['name' => 'Resto B']);

        $this->server = User::create([
            'establishment_id' => $this->est->id, 'name' => 'Serveur',
            'email' => 's@a.ci', 'password' => 'password', 'role' => 'server',
            'is_active' => true, 'pin' => '1234',
        ]);
        $this->manager = User::create([
            'establishment_id' => $this->est->id, 'name' => 'Gérant',
            'email' => 'g@a.ci', 'password' => 'password', 'role' => 'manager',
            'is_active' => true,
        ]);
        $this->table = Table::create([
            'establishment_id' => $this->est->id, 'name' => 'T1', 'qr_token' => 'abc123', 'status' => 'free',
        ]);
    }

    public function test_cannot_add_product_from_another_establishment(): void
    {
        // Produit appartenant à l'autre établissement
        $foreignProduct = Product::create([
            'establishment_id' => $this->otherEst->id, 'name' => 'Plat étranger', 'price' => 100000,
        ]);
        // Produit du bon établissement
        $ownProduct = Product::create([
            'establishment_id' => $this->est->id, 'name' => 'Alloco', 'price' => 1500,
        ]);

        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->server->id, 'order_number' => '#0001', 'status' => 'open',
        ]);

        $this->actingAs($this->server);

        // Tenter d'ajouter le produit d'un autre établissement → 404/403
        $this->postJson("/orders/{$order->id}/items", [
            'product_id' => $foreignProduct->id, 'quantity' => 1,
        ])->assertNotFound();

        // Le produit du bon établissement s'ajoute
        $this->postJson("/orders/{$order->id}/items", [
            'product_id' => $ownProduct->id, 'quantity' => 1,
        ])->assertOk();

        $items = $order->fresh()->items;
        $this->assertCount(1, $items);
        $this->assertEquals('Alloco', $items->first()->product_name);
    }

    public function test_annulation_without_pin_is_rejected_for_server(): void
    {
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->server->id, 'order_number' => '#0001', 'status' => 'open',
        ]);

        $this->actingAs($this->server)
            ->postJson("/orders/{$order->id}/cancel", ['reason' => 'test'])
            ->assertForbidden(); // pas de PIN → 403

        $this->assertEquals('open', $order->fresh()->status);
    }

    public function test_annulation_with_correct_pin_succeeds(): void
    {
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->server->id, 'order_number' => '#0001', 'status' => 'open',
        ]);

        $this->actingAs($this->server)
            ->postJson("/orders/{$order->id}/cancel", ['reason' => 'test', 'pin' => '1234'])
            ->assertOk();

        $this->assertEquals('cancelled', $order->fresh()->status);
    }

    public function test_manager_can_annulate_without_pin(): void
    {
        $order = Order::create([
            'establishment_id' => $this->est->id, 'table_id' => $this->table->id,
            'user_id' => $this->manager->id, 'order_number' => '#0001', 'status' => 'open',
        ]);

        $this->actingAs($this->manager)
            ->postJson("/orders/{$order->id}/cancel", ['reason' => 'test'])
            ->assertOk();
    }

    public function test_cannot_view_order_from_another_establishment(): void
    {
        $foreignOrder = Order::create([
            'establishment_id' => $this->otherEst->id, 'order_number' => '#9999', 'status' => 'open',
        ]);

        $this->actingAs($this->server)
            ->getJson("/orders/{$foreignOrder->id}")
            ->assertForbidden();
    }

    public function test_isolation_resolutions_via_qr_scoped_products(): void
    {
        // Le QR de la table A ne commande que les produits de A
        $foreignProduct = Product::create([
            'establishment_id' => $this->otherEst->id, 'name' => 'Plat étranger', 'price' => 100000,
        ]);

        $res = $this->postJson('/m/abc123/order', [
            'items' => [['product_id' => $foreignProduct->id, 'quantity' => 1]],
        ]);

        // Produit étranger ignoré → commande vide mais statut sent
        $res->assertOk()->assertJson(['status' => 'sent']);
        $order = Order::where('establishment_id', $this->est->id)->latest()->first();
        $this->assertEquals(0, $order->items()->count());
    }
}
