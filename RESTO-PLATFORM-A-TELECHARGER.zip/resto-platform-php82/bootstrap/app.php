<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
                // Routes publiques de l'app client (QR code) : pas de session, pas de CSRF
                $middleware->validateCsrfTokens(except: [
                    'm/*/order',
                ]);

                // Alias de middleware pour le contrôle d'accès par rôle
                $middleware->alias([
                    'role' => \App\Http\Middleware\EnsureRole::class,
                ]);
            })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
