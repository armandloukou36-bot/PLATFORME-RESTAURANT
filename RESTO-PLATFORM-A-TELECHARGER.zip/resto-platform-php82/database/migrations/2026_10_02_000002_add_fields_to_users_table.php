<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('establishment_id')->nullable()->constrained()->nullOnDelete();
            $table->string('role', 32)->default('server'); // owner, manager, cashier, server, kitchen, bar, stock
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('phone')->nullable();
            $table->string('pin', 6)->nullable(); // PIN personnel pour actions sensibles
            $table->boolean('is_active')->default(true);
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('establishment_id');
            $table->dropColumn(['role', 'first_name', 'last_name', 'phone', 'pin', 'is_active']);
        });
    }
};
