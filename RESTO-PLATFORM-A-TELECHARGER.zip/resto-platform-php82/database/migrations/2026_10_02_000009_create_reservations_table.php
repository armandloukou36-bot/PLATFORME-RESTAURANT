<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Réservations en ligne (INN-02)
        Schema::create('reservations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('table_id')->nullable()->constrained()->nullOnDelete();
            $table->string('customer_name');
            $table->string('customer_phone');
            $table->integer('guests')->default(1);
            $table->dateTime('reserved_at');
            $table->string('status', 16)->default('pending'); // pending, confirmed, cancelled, completed, no_show
            $table->decimal('deposit', 12, 2)->default(0); // acompte Mobile Money
            $table->string('deposit_method', 24)->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
            $table->index(['establishment_id', 'reserved_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reservations');
    }
};
