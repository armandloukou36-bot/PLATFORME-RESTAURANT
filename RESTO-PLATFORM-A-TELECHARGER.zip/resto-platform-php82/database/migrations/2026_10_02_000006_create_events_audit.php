<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Journal d'événements temps réel (SSE) + traçabilité
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->nullable()->constrained()->nullOnDelete();
            $table->string('type', 40); // order.sent, item.ready, table.status, payment.made...
            $table->json('payload')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['establishment_id', 'created_at']);
        });

        // Journal d'audit (actions sensibles : annulation, remise, ouverture tiroir)
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('action', 60);
            $table->string('entity_type', 40)->nullable();
            $table->unsignedBigInteger('entity_id')->nullable();
            $table->json('details')->nullable();
            $table->string('ip', 45)->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['establishment_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('events');
    }
};
