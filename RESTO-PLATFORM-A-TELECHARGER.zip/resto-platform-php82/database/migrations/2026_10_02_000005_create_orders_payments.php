<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Commandes
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('table_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete(); // serveur
            $table->string('order_number', 20)->nullable(); // #2925
            $table->string('channel', 16)->default('dine_in'); // dine_in, takeaway, delivery, counter
            $table->string('status', 24)->default('open'); // open, sent, in_progress, ready, served, paid, cancelled
            $table->unsignedInteger('guest_count')->default(1);
            $table->string('customer_name')->nullable();
            $table->string('customer_phone')->nullable();
            $table->text('note')->nullable();
            $table->decimal('subtotal', 12, 2)->default(0);
            $table->decimal('discount', 12, 2)->default(0);
            $table->decimal('total', 12, 2)->default(0);
            $table->timestamp('sent_at')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();
        });

        // Lignes de commande
        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('station_id')->nullable()->constrained()->nullOnDelete();
            $table->string('product_name');
            $table->decimal('unit_price', 12, 2)->default(0);
            $table->unsignedInteger('quantity')->default(1);
            $table->text('notes')->nullable(); // "bien cuit", "allergie arachide"
            $table->string('status', 16)->default('new'); // new, in_progress, ready, served, cancelled
            $table->string('wave', 16)->default('main'); // starter, main, dessert (vagues)
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        // Options choisies sur une ligne
        Schema::create('order_item_options', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_item_id')->constrained()->cascadeOnDelete();
            $table->string('option_name');
            $table->string('choice_name');
            $table->decimal('price_delta', 12, 2)->default(0);
            $table->timestamps();
        });

        // Paiements
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('method', 24); // cash, card, orange_money, mtn_momo, moov, wave, voucher, account
            $table->decimal('amount', 12, 2);
            $table->decimal('change_due', 12, 2)->default(0);
            $table->string('reference')->nullable();
            $table->timestamps();
        });

        // Sessions de caisse (ouverture / clôture)
        Schema::create('cash_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->decimal('opening_amount', 12, 2)->default(0);
            $table->decimal('closing_amount', 12, 2)->nullable();
            $table->decimal('counted_amount', 12, 2)->nullable();
            $table->decimal('difference', 12, 2)->nullable();
            $table->string('status', 16)->default('open'); // open, closed
            $table->timestamp('opened_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cash_sessions');
        Schema::dropIfExists('payments');
        Schema::dropIfExists('order_item_options');
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
    }
};
