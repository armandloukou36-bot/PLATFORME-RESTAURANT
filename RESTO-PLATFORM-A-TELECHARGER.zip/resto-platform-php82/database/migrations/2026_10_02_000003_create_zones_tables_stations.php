<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Zones de salle (terrasse, VIP, salle...)
        Schema::create('zones', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });

        // Tables
        Schema::create('tables', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('zone_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('qr_token', 64)->unique();
            $table->unsignedInteger('capacity')->default(4);
            $table->string('status', 24)->default('free'); // free, occupied, order_sent, ready, bill_requested, to_clean
            $table->timestamps();
        });

        // Postes de production (grill, froid, bar, pâtisserie, passe)
        Schema::create('stations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('type', 24)->default('kitchen'); // kitchen, bar, pass
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stations');
        Schema::dropIfExists('tables');
        Schema::dropIfExists('zones');
    }
};
