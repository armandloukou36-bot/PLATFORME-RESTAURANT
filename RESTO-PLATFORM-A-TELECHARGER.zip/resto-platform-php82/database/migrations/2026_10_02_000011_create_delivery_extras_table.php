<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Tarification dynamique / happy hours — IA-10
        Schema::create('price_rules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained()->cascadeOnDelete(); // null = règle globale
            $table->string('name'); // ex: "Happy hour"
            $table->string('day_of_week', 16)->nullable(); // monday...sunday, null=tous les jours
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->decimal('discount_percent', 5, 2)->default(0); // ex: 20.00 = -20%
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Modèles événements — INN-06 (menu fixe, billetterie)
        Schema::create('event_models', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->decimal('entry_fee', 12, 2)->default(0); // billetterie
            $table->boolean('is_active')->default(false);
            $table->timestamps();
        });

        Schema::create('event_model_products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_model_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $table->decimal('price', 12, 2)->nullable(); // prix fixe du menu événement
            $table->boolean('is_included')->default(false); // consommations prépayées incluses
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('event_model_products');
        Schema::dropIfExists('event_models');
        Schema::dropIfExists('price_rules');
    }
};
