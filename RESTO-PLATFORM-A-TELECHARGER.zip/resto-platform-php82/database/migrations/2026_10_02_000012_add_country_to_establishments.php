<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Multi-pays (point 3) : pays + chars de devise par établissement
        Schema::table('establishments', function (Blueprint $table) {
            $table->string('country', 64)->default('Côte d\'Ivoire')->after('timezone');
            $table->string('currency_symbol', 8)->default('FCFA')->after('currency');
        });
    }

    public function down(): void
    {
        Schema::table('establishments', function (Blueprint $table) {
            $table->dropColumn(['country', 'currency_symbol']);
        });
    }
};
