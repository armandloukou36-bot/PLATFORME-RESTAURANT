<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Dépôts (réserve, cuisine, bar)
        Schema::create('depots', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('type', 16)->default('storage'); // storage, kitchen, bar
            $table->timestamps();
        });

        // Ingrédients / matières premières
        Schema::create('ingredients', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('depot_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('unit', 16)->default('g'); // g, kg, l, cl, unité
            $table->decimal('stock_qty', 12, 3)->default(0);
            $table->decimal('min_stock', 12, 3)->default(0);
            $table->decimal('cost', 12, 2)->default(0); // coût d'achat unitaire
            $table->string('barcode')->nullable();
            $table->timestamps();
        });

        // Fiches techniques (recettes) : produit → ingrédient + quantité
        Schema::create('recipe_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->foreignId('ingredient_id')->constrained()->cascadeOnDelete();
            $table->decimal('quantity', 12, 3)->default(0);
            $table->timestamps();
            $table->unique(['product_id', 'ingredient_id']);
        });

        // Mouvements de stock (entrées, sorties, ventes, pertes)
        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->foreignId('ingredient_id')->constrained()->cascadeOnDelete();
            $table->foreignId('depot_id')->nullable()->constrained()->nullOnDelete();
            $table->string('type', 16); // in, out, sale, loss, transfer_in, transfer_out
            $table->decimal('quantity', 12, 3);
            $table->decimal('unit_cost', 12, 2)->default(0);
            $table->string('reference')->nullable(); // n° commande, n° réception
            $table->string('reason')->nullable(); // casse, périmé, repas personnel
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamp('created_at')->useCurrent();
            $table->index(['ingredient_id', 'created_at']);
        });

        // Fournisseurs
        Schema::create('suppliers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('establishment_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('contact')->nullable();
            $table->string('phone')->nullable();
            $table->string('email')->nullable();
            $table->string('address')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('suppliers');
        Schema::dropIfExists('stock_movements');
        Schema::dropIfExists('recipe_items');
        Schema::dropIfExists('ingredients');
        Schema::dropIfExists('depots');
    }
};
