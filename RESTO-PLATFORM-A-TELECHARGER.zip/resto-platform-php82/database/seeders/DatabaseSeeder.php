<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Establishment;
use App\Models\Product;
use App\Models\ProductOption;
use App\Models\ProductOptionChoice;
use App\Models\Station;
use App\Models\Table;
use App\Models\User;
use App\Models\Zone;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ===== Établissement =====
        $est = Establishment::create([
            'name' => 'Maquis Le Baobab',
            'legal_name' => 'LE BAOBAB SARL',
            'ncc' => 'CI-2024-B-12345',
            'address' => 'Cocody, Abidjan, Côte d\'Ivoire',
            'phone' => '+225 07 00 00 00 00',
            'email' => 'contact@lebaobab.ci',
            'currency' => 'FCFA',
            'currency_symbol' => 'FCFA',
            'country' => 'Côte d\'Ivoire',
            'timezone' => 'Africa/Abidjan',
        ]);

        // ===== Super-administrateur (console SaaS, sans établissement) =====
                User::create([
                    'establishment_id' => null,
                    'name' => 'Super Admin',
                    'email' => 'admin@resto.ci',
                    'password' => 'password',
                    'role' => 'superadmin',
                    'first_name' => 'Super',
                    'last_name' => 'Admin',
                    'pin' => '0000',
                    'is_active' => true,
                ]);

                // ===== Utilisateurs par rôle =====
                $users = [
            ['name' => 'Gérant', 'email' => 'gerant@lebaobab.ci', 'role' => 'manager', 'first_name' => 'Awa', 'last_name' => 'Kouassi', 'pin' => '1234'],
            ['name' => 'Caissier', 'email' => 'caisse@lebaobab.ci', 'role' => 'cashier', 'first_name' => 'Jean', 'last_name' => 'Traoré', 'pin' => '2345'],
            ['name' => 'Serveur 1', 'email' => 'serveur1@lebaobab.ci', 'role' => 'server', 'first_name' => 'Moussa', 'last_name' => 'Diabaté', 'pin' => '3456'],
            ['name' => 'Serveur 2', 'email' => 'serveur2@lebaobab.ci', 'role' => 'server', 'first_name' => 'Fatou', 'last_name' => 'Ndiaye', 'pin' => '4567'],
            ['name' => 'Cuisinier', 'email' => 'cuisine@lebaobab.ci', 'role' => 'kitchen', 'first_name' => 'Koffi', 'last_name' => 'Mensah', 'pin' => '5678'],
            ['name' => 'Barman', 'email' => 'bar@lebaobab.ci', 'role' => 'bar', 'first_name' => 'Yao', 'last_name' => 'Konan', 'pin' => '6789'],
        ];
        foreach ($users as $u) {
            User::create([
                'establishment_id' => $est->id,
                'name' => $u['name'],
                'email' => $u['email'],
                'password' => 'password',
                'role' => $u['role'],
                'first_name' => $u['first_name'],
                'last_name' => $u['last_name'],
                'pin' => $u['pin'],
                'is_active' => true,
            ]);
        }

        // ===== Zones =====
        $zones = ['Terrasse', 'Salle principale', 'VIP'];
        $zoneModels = [];
        foreach ($zones as $i => $z) {
            $zoneModels[] = Zone::create(['establishment_id' => $est->id, 'name' => $z, 'sort_order' => $i]);
        }

        // ===== Tables =====
        $tableNames = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12', 'VIP1', 'VIP2'];
        foreach ($tableNames as $i => $t) {
            $zone = $zoneModels[$i < 6 ? 0 : ($i < 12 ? 1 : 2)];
            Table::create([
                'establishment_id' => $est->id,
                'zone_id' => $zone->id,
                'name' => $t,
                'qr_token' => 'table-' . str_replace(' ', '-', strtolower($t)),
                'capacity' => $i < 12 ? 4 : 6,
                'status' => 'free',
            ]);
        }

        // ===== Postes =====
        $stations = [
            ['name' => 'Grill', 'type' => 'kitchen'],
            ['name' => 'Friture', 'type' => 'kitchen'],
            ['name' => 'Froid', 'type' => 'kitchen'],
            ['name' => 'Pâtisserie', 'type' => 'kitchen'],
            ['name' => 'Bar', 'type' => 'bar'],
            ['name' => 'Passe', 'type' => 'pass'],
        ];
        $stationModels = [];
        foreach ($stations as $i => $s) {
            $stationModels[$s['name']] = Station::create([
                'establishment_id' => $est->id, 'name' => $s['name'], 'type' => $s['type'], 'sort_order' => $i,
            ]);
        }

        // ===== Catégories =====
        $cats = ['Entrées', 'Plats', 'Grillades', 'Poissons', 'Desserts', 'Boissons', 'Cocktails'];
        $catModels = [];
        foreach ($cats as $i => $c) {
            $catModels[$c] = Category::create(['establishment_id' => $est->id, 'name' => $c, 'sort_order' => $i]);
        }

        // ===== Produits =====
        $products = [
            ['Alloco', 'Plats', 'Friture', 1500, 0, 8, 'Bananes plantain frites, servies avec sauce piment'],
            ['Attiéké Poisson', 'Plats', 'Grill', 3500, 1, 15, 'Attiéké frais, poisson braisé, tomates et oignons'],
            ['Poulet Braisé', 'Grillades', 'Grill', 5000, 2, 20, 'Poulet fermier braisé, sauce piment maison'],
            ['Garba', 'Plats', 'Friture', 2000, 1, 10, 'Attiéké, thon frit, oignons et piment'],
            ['Kedjenou Poulet', 'Plats', 'Grill', 4500, 1, 25, 'Poulet mijoté aux légumes, à l\'étouffée'],
            ['Poisson Braisé Capitaine', 'Poissons', 'Grill', 8000, 1, 25, 'Capitaine entier braisé, accompagnements au choix'],
            ['Brochettes de Bœuf', 'Grillades', 'Grill', 3000, 2, 15, 'Brochettes marinées, oignons et moutarde'],
            ['Salade César', 'Entrées', 'Froid', 2500, 0, 10, 'Laitue, poulet grillé, parmesan, croûtons'],
            ['Crème Brûlée', 'Desserts', 'Pâtisserie', 2000, 0, 12, 'Crème vanille, caramel croquant'],
            ['Tiramisu', 'Desserts', 'Pâtisserie', 2500, 0, 10, 'Mascarpone, café, cacao'],
            ['Bissap', 'Boissons', 'Bar', 1000, 0, 3, 'Jus d\'hibiscus frais'],
            ['Jus de Gingembre', 'Boissons', 'Bar', 1000, 0, 3, 'Gingembre frais pressé'],
            ['Coca-Cola', 'Boissons', 'Bar', 1000, 0, 2, 'Canette 33cl'],
            ['Eau Minérale', 'Boissons', 'Bar', 500, 0, 1, 'Bouteille 50cl'],
            ['Mojito', 'Cocktails', 'Bar', 3500, 0, 8, 'Rhum, menthe fraîche, citron vert, eau gazeuse'],
            ['Pina Colada', 'Cocktails', 'Bar', 4000, 0, 8, 'Rhum, ananas, noix de coco'],
        ];

        $productModels = [];
        foreach ($products as [$name, $cat, $station, $price, $spice, $prep, $desc]) {
            $productModels[$name] = Product::create([
                'establishment_id' => $est->id,
                'category_id' => $catModels[$cat]->id,
                'station_id' => $stationModels[$station]->id,
                'name' => $name,
                'description' => $desc,
                'price' => $price,
                'allergens' => in_array($name, ['Alloco', 'Attiéké Poisson', 'Garba']) ? ['arachide'] : [],
                'spice_level' => $spice,
                'prep_time_min' => $prep,
                'is_active' => true,
                'is_available' => true,
            ]);
        }

        // ===== Options / suppléments =====
        $opt = ProductOption::create([
            'establishment_id' => $est->id, 'product_id' => $productModels['Attiéké Poisson']->id,
            'name' => 'Accompagnement', 'type' => 'single', 'required' => true,
        ]);
        foreach ([['Attiéké', 0], ['Frites', 500], ['Alloco', 500], ['Riz', 500]] as [$n, $p]) {
            ProductOptionChoice::create(['option_id' => $opt->id, 'name' => $n, 'price_delta' => $p]);
        }

        $opt2 = ProductOption::create([
            'establishment_id' => $est->id, 'product_id' => $productModels['Poulet Braisé']->id,
            'name' => 'Cuisson', 'type' => 'single', 'required' => false,
        ]);
        foreach ([['Bien cuit', 0], ['À point', 0], ['Saignant', 0]] as [$n, $p]) {
            ProductOptionChoice::create(['option_id' => $opt2->id, 'name' => $n, 'price_delta' => $p]);
        }

        $opt3 = ProductOption::create([
            'establishment_id' => $est->id, 'product_id' => $productModels['Poulet Braisé']->id,
            'name' => 'Suppléments', 'type' => 'multiple', 'required' => false,
        ]);
        foreach ([['Sauce piment', 0], ['Oignons', 0], ['Alloco', 500], ['Frites', 500]] as [$n, $p]) {
            ProductOptionChoice::create(['option_id' => $opt3->id, 'name' => $n, 'price_delta' => $p]);
        }

        $this->command->info('Seed terminé : établissement, 6 utilisateurs, 14 tables, 6 postes, 16 produits.');

                // ===== Dépôts =====
                $depots = [];
                foreach (['Réserve', 'Cuisine', 'Bar'] as $i => $d) {
                    $depots[$d] = \App\Models\Depot::create(['establishment_id' => $est->id, 'name' => $d, 'type' => $i === 2 ? 'bar' : ($i === 1 ? 'kitchen' : 'storage')]);
                }

                // ===== Ingrédients =====
                $ingredients = [
                    ['Banane plantain', 'g', 'Réserve', 20000, 5000, 300],
                    ['Attiéké', 'g', 'Réserve', 15000, 3000, 200],
                    ['Poulet fermier', 'g', 'Réserve', 10000, 2000, 1500],
                    ['Thon', 'g', 'Réserve', 8000, 2000, 2500],
                    ['Poisson capitaine', 'g', 'Réserve', 5000, 1000, 4000],
                    ['Riz', 'g', 'Réserve', 25000, 5000, 500],
                    ['Huile', 'l', 'Réserve', 20, 5, 1500],
                    ['Oignons', 'g', 'Réserve', 10000, 2000, 500],
                    ['Tomates', 'g', 'Réserve', 8000, 2000, 800],
                    ['Piment', 'g', 'Réserve', 3000, 500, 1000],
                    ['Bissap', 'g', 'Réserve', 5000, 1000, 800],
                    ['Gingembre', 'g', 'Réserve', 3000, 500, 1200],
                    ['Rhum', 'l', 'Bar', 10, 2, 8000],
                    ['Menthe', 'g', 'Bar', 2000, 500, 600],
                    ['Citron vert', 'unité', 'Bar', 100, 20, 150],
                ];
                $ingredientModels = [];
                foreach ($ingredients as [$name, $unit, $depot, $stock, $min, $cost]) {
                    $ingredientModels[$name] = \App\Models\Ingredient::create([
                        'establishment_id' => $est->id,
                        'depot_id' => $depots[$depot]->id,
                        'name' => $name,
                        'unit' => $unit,
                        'stock_qty' => $stock,
                        'min_stock' => $min,
                        'cost' => $cost,
                    ]);
                }

                // ===== Fiches techniques (recettes) =====
                $recipes = [
                    'Alloco' => [['Banane plantain', 250], ['Huile', 0.05], ['Piment', 5]],
                    'Attiéké Poisson' => [['Attiéké', 300], ['Poisson capitaine', 200], ['Tomates', 50], ['Oignons', 30]],
                    'Poulet Braisé' => [['Poulet fermier', 350], ['Huile', 0.1], ['Piment', 10], ['Oignons', 30]],
                    'Garba' => [['Attiéké', 300], ['Thon', 100], ['Oignons', 30], ['Piment', 5]],
                    'Bissap' => [['Bissap', 20], ['Gingembre', 5]],
                    'Mojito' => [['Rhum', 0.06], ['Menthe', 10], ['Citron vert', 1]],
                ];
                foreach ($recipes as $productName => $items) {
                    $product = $productModels[$productName] ?? null;
                    if (! $product) {
                        continue;
                    }
                    foreach ($items as [$ingName, $qty]) {
                        \App\Models\RecipeItem::create([
                            'establishment_id' => $est->id,
                            'product_id' => $product->id,
                            'ingredient_id' => $ingredientModels[$ingName]->id,
                            'quantity' => $qty,
                        ]);
                    }
                }

                $this->command->info('Stock ajouté : 3 dépôts, 15 ingrédients, fiches techniques préparées pour 6 produits.');
            }
        }
