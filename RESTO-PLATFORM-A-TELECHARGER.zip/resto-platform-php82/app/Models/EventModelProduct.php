<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EventModelProduct extends Model
{
    use HasFactory;

    protected $fillable = ['event_model_id', 'product_id', 'price', 'is_included'];

    protected $casts = [
        'price' => 'float',
        'is_included' => 'boolean',
    ];

    public function eventModel(): BelongsTo
    {
        return $this->belongsTo(EventModel::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
