<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ProductOption extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'product_id', 'name', 'type', 'required', 'sort_order',
    ];

    protected $casts = ['required' => 'boolean'];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function choices(): HasMany
    {
        return $this->hasMany(ProductOptionChoice::class, 'option_id');
    }
}
