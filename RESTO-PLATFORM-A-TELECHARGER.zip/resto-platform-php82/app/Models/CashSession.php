<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CashSession extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'user_id', 'opening_amount', 'closing_amount',
        'counted_amount', 'difference', 'status', 'opened_at', 'closed_at',
    ];

    protected $casts = [
        'opening_amount' => 'float',
        'closing_amount' => 'float',
        'counted_amount' => 'float',
        'difference' => 'float',
        'opened_at' => 'datetime',
        'closed_at' => 'datetime',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
