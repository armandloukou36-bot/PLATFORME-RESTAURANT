<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Ingredient extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'depot_id', 'name', 'unit',
        'stock_qty', 'min_stock', 'cost', 'barcode',
    ];

    protected $casts = [
        'stock_qty' => 'float',
        'min_stock' => 'float',
        'cost' => 'float',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function depot(): BelongsTo
    {
        return $this->belongsTo(Depot::class);
    }

    public function movements(): HasMany
    {
        return $this->hasMany(StockMovement::class);
    }

    public function isLowStock(): bool
    {
        return $this->min_stock > 0 && $this->stock_qty <= $this->min_stock;
    }
}
