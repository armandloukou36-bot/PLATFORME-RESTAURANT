<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class EventModel extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'name', 'starts_at', 'ends_at', 'entry_fee', 'is_active',
    ];

    protected $casts = [
        'entry_fee' => 'float',
        'is_active' => 'boolean',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function products(): HasMany
    {
        return $this->hasMany(EventModelProduct::class);
    }
}
