<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Reservation extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'table_id', 'customer_name', 'customer_phone',
        'guests', 'reserved_at', 'status', 'deposit', 'deposit_method', 'note',
    ];

    protected $casts = [
        'guests' => 'integer',
        'deposit' => 'float',
        'reserved_at' => 'datetime',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function table(): BelongsTo
    {
        return $this->belongsTo(Table::class);
    }
}
