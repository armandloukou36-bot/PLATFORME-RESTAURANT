<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Supplier extends Model
{
    use HasFactory;

    protected $fillable = ['establishment_id', 'name', 'contact', 'phone', 'email', 'address'];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }
}
