<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Customer extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'name', 'phone', 'email',
        'loyalty_points', 'loyalty_tier', 'total_spent',
    ];

    protected $casts = [
        'loyalty_points' => 'integer',
        'loyalty_tier' => 'integer',
        'total_spent' => 'float',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function loyaltyTransactions(): HasMany
    {
        return $this->hasMany(LoyaltyTransaction::class);
    }

    public function tierName(): string
    {
        return match ($this->loyalty_tier) {
            2 => 'Or',
            1 => 'Argent',
            default => 'Standard',
        };
    }
}
