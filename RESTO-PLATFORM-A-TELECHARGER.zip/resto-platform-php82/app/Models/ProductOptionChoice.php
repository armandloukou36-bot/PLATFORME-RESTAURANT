<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductOptionChoice extends Model
{
    use HasFactory;

    protected $fillable = ['option_id', 'name', 'price_delta', 'is_default', 'sort_order'];

    protected $casts = [
        'is_default' => 'boolean',
        'price_delta' => 'float',
    ];

    public function option(): BelongsTo
    {
        return $this->belongsTo(ProductOption::class, 'option_id');
    }
}
