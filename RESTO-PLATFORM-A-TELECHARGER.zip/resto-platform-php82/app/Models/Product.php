<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'category_id', 'station_id', 'name', 'description',
        'photo_path', 'price', 'allergens', 'spice_level', 'prep_time_min',
        'barcode', 'is_active', 'is_available', 'sort_order',
    ];

    protected $casts = [
        'allergens' => 'array',
        'is_active' => 'boolean',
        'is_available' => 'boolean',
        'price' => 'float',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function station(): BelongsTo
    {
        return $this->belongsTo(Station::class);
    }

    public function options(): HasMany
    {
        return $this->hasMany(ProductOption::class);
    }
}
