<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Delivery extends Model
{
    use HasFactory;

    protected $fillable = [
        'establishment_id', 'order_id', 'courier_id', 'status',
        'contact_name', 'contact_phone', 'address', 'city', 'landmark',
        'delivery_fee', 'collected_amount', 'payment_method',
        'assigned_at', 'picked_up_at', 'delivered_at',
    ];

    protected $casts = [
        'delivery_fee' => 'float',
        'collected_amount' => 'float',
        'assigned_at' => 'datetime',
        'picked_up_at' => 'datetime',
        'delivered_at' => 'datetime',
    ];

    public function establishment(): BelongsTo
    {
        return $this->belongsTo(Establishment::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function courier(): BelongsTo
    {
        return $this->belongsTo(Courier::class);
    }
}
