<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Vérifie que l'utilisateur a l'un des rôles autorisés pour accéder à la page.
 * Usage : ->middleware('role:manager,owner')
 */
class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();
        if (! $user) {
            return redirect()->route('login');
        }

        if (! in_array($user->role, $roles)) {
            abort(403, 'Accès réservé à un rôle autorisé.');
        }

        return $next($request);
    }
}
