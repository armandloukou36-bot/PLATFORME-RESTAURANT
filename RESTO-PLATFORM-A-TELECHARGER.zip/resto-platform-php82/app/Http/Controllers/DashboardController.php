<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Support\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $today = Carbon::today();

        // Chiffre d'affaires du jour (encaissé)
        $revenueToday = Payment::whereHas('order', fn ($q) => $q->where('establishment_id', $est->id))
            ->whereDate('created_at', $today)
            ->sum('amount');

        // Commandes du jour
        $ordersToday = Order::where('establishment_id', $est->id)
            ->whereDate('created_at', $today)
            ->count();

        // Commandes en cours (non payées)
        $openOrders = Order::where('establishment_id', $est->id)
            ->whereNotIn('status', ['paid', 'cancelled'])
            ->count();

        // Panier moyen
        $avgBasket = $ordersToday > 0 ? round($revenueToday / $ordersToday) : 0;

        // Ventes par canal (7 derniers jours)
        $channelData = Order::where('establishment_id', $est->id)
            ->where('created_at', '>=', Carbon::today()->subDays(7))
            ->where('status', 'paid')
            ->selectRaw('channel, COUNT(*) as count, SUM(total) as total')
            ->groupBy('channel')
            ->get();

        // Ventes par jour (7 derniers jours)
        $dailyData = Order::where('establishment_id', $est->id)
            ->where('created_at', '>=', Carbon::today()->subDays(6))
            ->where('status', 'paid')
            ->selectRaw('DATE(created_at) as day, SUM(total) as total')
            ->groupBy('day')
            ->orderBy('day')
            ->get();

        // Top produits
        $topProducts = \DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.establishment_id', $est->id)
            ->where('orders.created_at', '>=', Carbon::today()->subDays(7))
            ->where('orders.status', 'paid')
            ->selectRaw('order_items.product_name, SUM(order_items.quantity) as qty')
            ->groupBy('order_items.product_name')
            ->orderByDesc('qty')
            ->limit(5)
            ->get();

        // Alertes récentes (annulations, remises)
                $recentCancellations = Order::where('establishment_id', $est->id)
                    ->where('status', 'cancelled')
                    ->where('created_at', '>=', Carbon::today()->subHours(24))
                    ->count();

                // Détection d'anomalies (IA-03)
                $anomalies = app(\App\Services\AnomalyService::class)->detect($est->id);

                return view('dashboard.index', compact(
                    'est', 'revenueToday', 'ordersToday', 'openOrders', 'avgBasket',
                    'channelData', 'dailyData', 'topProducts', 'recentCancellations', 'anomalies'
                ));
    }
}
