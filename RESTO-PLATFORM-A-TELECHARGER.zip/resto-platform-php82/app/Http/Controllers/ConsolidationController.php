<?php

namespace App\Http\Controllers;

use App\Models\Establishment;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Support\Carbon;

/**
 * Consolidation multi-établissements (point 3 — multi-pays/devises).
 * Vue réservée au propriétaire/direction : agrège les ventes de tous les sites.
 */
class ConsolidationController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        // Réservé au propriétaire / direction
        if (! in_array($user->role, ['owner', 'manager'])) {
            abort(403, 'Accès réservé à la direction.');
        }

        $establishments = Establishment::where('is_active', true)->get();
        $today = Carbon::today();

        $rows = $establishments->map(function ($est) use ($today) {
            $revenue = Payment::whereHas('order', fn ($q) => $q->where('establishment_id', $est->id))
                ->whereDate('created_at', $today)->sum('amount');
            $orders = Order::where('establishment_id', $est->id)->whereDate('created_at', $today)->count();
            $open = Order::where('establishment_id', $est->id)->whereNotIn('status', ['paid', 'cancelled'])->count();

            return [
                'id' => $est->id,
                'name' => $est->name,
                'country' => $est->country,
                'currency' => $est->currency_symbol ?? $est->currency,
                'revenue' => $revenue,
                'orders' => $orders,
                'open' => $open,
            ];
        });

        $totalRevenue = $rows->sum('revenue');
        $totalOrders = $rows->sum('orders');

        return view('consolidation.index', compact('establishments', 'rows', 'totalRevenue', 'totalOrders', 'today'));
    }
}
