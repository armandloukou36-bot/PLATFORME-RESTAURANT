<?php

namespace App\Http\Controllers;

use App\Models\Depot;
use App\Models\Ingredient;
use App\Models\Product;
use App\Models\RecipeItem;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Services\StockService;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $ingredients = Ingredient::where('establishment_id', $est->id)
            ->with('depot')
            ->orderBy('name')
            ->get();

        $depots = Depot::where('establishment_id', $est->id)->get();
        $suppliers = Supplier::where('establishment_id', $est->id)->get();
        $products = Product::where('establishment_id', $est->id)->get();

        // Valeur du stock
        $stockValue = $ingredients->sum(fn ($i) => $i->stock_qty * $i->cost);
        $lowStock = $ingredients->filter->isLowStock();

        return view('stock.index', compact('est', 'ingredients', 'depots', 'suppliers', 'products', 'stockValue', 'lowStock'));
    }

    public function storeIngredient(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'unit' => 'required|in:g,kg,l,cl,unité',
            'depot_id' => 'nullable|exists:depots,id',
            'min_stock' => 'nullable|numeric|min:0',
            'cost' => 'nullable|numeric|min:0',
        ]);
        $data['establishment_id'] = $est->id;
        $data['min_stock'] = $data['min_stock'] ?? 0;
        $data['cost'] = $data['cost'] ?? 0;
        Ingredient::create($data);
        return back()->with('success', 'Ingrédient ajouté.');
    }

    public function receive(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'ingredient_id' => 'required|exists:ingredients,id',
            'quantity' => 'required|numeric|min:0.001',
            'unit_cost' => 'required|numeric|min:0',
            'reference' => 'nullable|string',
        ]);
        $ingredient = Ingredient::findOrFail($data['ingredient_id']);
        abort_unless($ingredient->establishment_id === $est->id, 403);

        app(StockService::class)->receive($data['ingredient_id'], $data['quantity'], $data['unit_cost'], $data['reference'] ?? null);
        return back()->with('success', 'Réception enregistrée.');
    }

    public function loss(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'ingredient_id' => 'required|exists:ingredients,id',
            'quantity' => 'required|numeric|min:0.001',
            'reason' => 'required|string|max:255',
        ]);
        $ingredient = Ingredient::findOrFail($data['ingredient_id']);
        abort_unless($ingredient->establishment_id === $est->id, 403);

        app(StockService::class)->loss($data['ingredient_id'], $data['quantity'], $data['reason']);
        return back()->with('success', 'Perte déclarée.');
    }

    public function storeRecipe(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'ingredient_id' => 'required|exists:ingredients,id',
            'quantity' => 'required|numeric|min:0.001',
        ]);
        $product = Product::findOrFail($data['product_id']);
        abort_unless($product->establishment_id === $est->id, 403);

        RecipeItem::updateOrCreate(
            ['product_id' => $data['product_id'], 'ingredient_id' => $data['ingredient_id']],
            ['establishment_id' => $est->id, 'quantity' => $data['quantity']]
        );
        return back()->with('success', 'Fiche technique mise à jour.');
    }

    public function movements()
    {
        $est = $this->establishment();
        $movements = StockMovement::where('establishment_id', $est->id)
            ->with('ingredient', 'user')
            ->orderByDesc('created_at')
            ->limit(100)
            ->get();
        return view('stock.movements', compact('est', 'movements'));
    }
}
