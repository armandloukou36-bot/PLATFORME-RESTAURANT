<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $from = $request->get('from', Carbon::today()->startOfMonth()->toDateString());
        $to = $request->get('to', Carbon::today()->toDateString());

        $orders = Order::where('establishment_id', $est->id)
            ->whereBetween('created_at', [Carbon::parse($from)->startOfDay(), Carbon::parse($to)->endOfDay()])
            ->with(['items', 'payments', 'table', 'user'])
            ->get();

        $paid = $orders->where('status', 'paid');
        $revenue = $paid->sum('total');
        $orderCount = $orders->count();
        $avgBasket = $paid->count() > 0 ? round($revenue / $paid->count()) : 0;

        // Par mode de paiement
        $byMethod = Payment::whereHas('order', fn ($q) => $q->where('establishment_id', $est->id)
            ->whereBetween('created_at', [Carbon::parse($from)->startOfDay(), Carbon::parse($to)->endOfDay()]))
            ->selectRaw('method, SUM(amount) as total')
            ->groupBy('method')
            ->get();

        // Par canal
        $byChannel = $paid->groupBy('channel')->map(fn ($g) => $g->sum('total'));

        // Top produits
        $topProducts = \DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.establishment_id', $est->id)
            ->whereBetween('orders.created_at', [Carbon::parse($from)->startOfDay(), Carbon::parse($to)->endOfDay()])
            ->where('orders.status', 'paid')
            ->selectRaw('order_items.product_name, SUM(order_items.quantity) as qty, SUM(order_items.quantity * order_items.unit_price) as total')
            ->groupBy('order_items.product_name')
            ->orderByDesc('qty')
            ->limit(10)
            ->get();

        // Par serveur
        $byServer = $paid->groupBy('user_id')->map(function ($g) {
            $user = $g->first()->user;
            return ['name' => $user?->name ?? '—', 'total' => $g->sum('total'), 'count' => $g->count()];
        });

        // Annulations
        $cancellations = $orders->where('status', 'cancelled')->count();

        return view('reports.index', compact(
            'est', 'from', 'to', 'revenue', 'orderCount', 'avgBasket',
            'byMethod', 'byChannel', 'topProducts', 'byServer', 'cancellations'
        ));
    }
}
