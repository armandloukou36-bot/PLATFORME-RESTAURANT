<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class SseController extends Controller
{
    public function stream(Request $request): StreamedResponse
    {
        $est = $this->establishment();

        // Le client EventSource envoie "Last-Event-ID" en header à la reconnexion.
        // Au premier chargement, on ne renvoie que les événements des 30 dernières
        // secondes pour éviter le replay massif des anciens événements (qui
        // provoquait des rechargements intempestifs de la page).
        $lastId = (int) ($request->header('Last-Event-ID') ?: $request->query('last_id', 0));
        $since = now()->subSeconds(30);

        // Durée de vie limitée de la connexion pour ne pas bloquer le serveur mono-thread.
        $maxDuration = 3; // secondes
        $start = microtime(true);

        return response()->stream(function () use ($est, $lastId, $since, $maxDuration, $start) {
            header('Content-Type: text/event-stream');
            header('Cache-Control: no-cache');
            header('X-Accel-Buffering: no');
            header('Connection: keep-alive');

            $cursor = $lastId;

            while (true) {
                $query = Event::where('id', '>', $cursor)
                    ->where('created_at', '>=', $since)
                    ->orderBy('id');
                if ($est) {
                    $query->where(function ($q) use ($est) {
                        $q->where('establishment_id', $est->id)->orWhereNull('establishment_id');
                    });
                }
                $events = $query->limit(50)->get();

                foreach ($events as $event) {
                    echo "id: {$event->id}\n";
                    echo "event: {$event->type}\n";
                    echo 'data: ' . json_encode($event->payload) . "\n\n";
                    $cursor = $event->id;
                }

                // Heartbeat
                echo ": ping\n\n";
                ob_flush();
                flush();

                // Sortir après la durée max → libère le serveur, le client se reconnecte
                if (microtime(true) - $start >= $maxDuration) {
                    break;
                }
                if (connection_aborted()) {
                    break;
                }

                usleep(300000); // 300ms
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache',
            'X-Accel-Buffering' => 'no',
        ]);
    }
}
