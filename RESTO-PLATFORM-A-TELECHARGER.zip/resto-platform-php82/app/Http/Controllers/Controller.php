<?php

namespace App\Http\Controllers;

use App\Models\Establishment;
use Illuminate\Support\Facades\Auth;

abstract class Controller
{
    protected function establishment(): ?Establishment
    {
        $user = Auth::user();
        if (! $user) {
            return null;
        }
        return $user->establishment_id
            ? Establishment::find($user->establishment_id)
            : Establishment::first();
    }
}
