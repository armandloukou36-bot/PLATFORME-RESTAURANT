<?php

namespace App\Http\Controllers;

use App\Models\Courier;
use App\Models\Delivery;
use App\Models\EventModel;
use App\Models\EventModelProduct;
use App\Models\Order;
use App\Models\PriceRule;
use App\Models\Product;
use Illuminate\Http\Request;

class ExpansionController extends Controller
{
    // ===== Vue principale : livraison, tarification, événements =====
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $couriers = Courier::where('establishment_id', $est->id)->withCount(['deliveries'])->get();
        $deliveries = Delivery::where('establishment_id', $est->id)
            ->with(['order', 'courier'])
            ->orderByDesc('created_at')
            ->limit(50)
            ->get();
        $priceRules = PriceRule::where('establishment_id', $est->id)->with('product')->get();
        $eventModels = EventModel::where('establishment_id', $est->id)->with('products')->get();
        $products = Product::where('establishment_id', $est->id)->get();

        // Commandes en attente de livraison (channel delivery, non livrées)
        $pendingOrders = Order::where('establishment_id', $est->id)
            ->where('channel', 'delivery')
            ->whereIn('status', ['sent', 'in_progress', 'ready'])
            ->whereDoesntHave('delivery')
            ->with('items')
            ->get();

        return view('expansion.index', compact('est', 'couriers', 'deliveries', 'priceRules', 'eventModels', 'products', 'pendingOrders'));
    }

    // ===== Livreurs =====
    public function storeCourier(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:40',
            'vehicle' => 'nullable|string|max:32',
        ]);
        $data['establishment_id'] = $est->id;
        Courier::create($data);
        return back()->with('success', 'Livreur ajouté.');
    }

    // ===== Livraisons =====
    public function createDelivery(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'order_id' => 'required|exists:orders,id',
            'courier_id' => 'nullable|exists:couriers,id',
            'contact_name' => 'required|string|max:255',
            'contact_phone' => 'required|string|max:40',
            'address' => 'required|string',
            'city' => 'nullable|string|max:255',
            'landmark' => 'nullable|string',
            'delivery_fee' => 'nullable|numeric|min:0',
            'payment_method' => 'nullable|in:cash,orange_money,mtn_momo,moov,wave,card',
        ]);
        $order = Order::findOrFail($data['order_id']);
        abort_unless($order->establishment_id === $est->id, 403);

        $data['establishment_id'] = $est->id;
        $data['delivery_fee'] = $data['delivery_fee'] ?? 0;
        $data['status'] = $data['courier_id'] ? 'assigned' : 'pending';

        $delivery = Delivery::create($data);
        if ($data['courier_id']) {
            $delivery->update(['assigned_at' => now()]);
            \App\Models\Event::create([
                'establishment_id' => $est->id,
                'type' => 'delivery.assigned',
                'payload' => ['delivery_id' => $delivery->id, 'order_id' => $order->id],
            ]);
        }

        return back()->with('success', 'Livraison créée.');
    }

    public function updateDeliveryStatus(Request $request, Delivery $delivery)
    {
        $est = $this->establishment();
        abort_unless($delivery->establishment_id === $est->id, 403);

        $data = $request->validate([
            'status' => 'required|in:pending,assigned,picked_up,in_transit,delivered,returned,cancelled',
            'collected_amount' => 'nullable|numeric|min:0',
            'payment_method' => 'nullable|string',
        ]);

        $timestamps = [
            'picked_up' => 'picked_up_at',
            'delivered' => 'delivered_at',
        ];
        $delivery->update($data);
        if (isset($timestamps[$data['status']])) {
            $delivery->update([$timestamps[$data['status']] => now()]);
        }

        // Si livrée : marquer la commande payée (encaissement à la livraison)
        if ($data['status'] === 'delivered') {
            $order = $delivery->order;
            if ($order && $order->status !== 'paid') {
                $amount = $delivery->collected_amount ?? $order->total + $delivery->delivery_fee;
                $order->update(['status' => 'paid', 'paid_at' => now()]);
                $order->payments()->create([
                    'user_id' => auth()->id(),
                    'method' => $data['payment_method'] ?? 'cash',
                    'amount' => $amount,
                ]);
                app(\App\Services\StockService::class)->destockOrder($order);
            }
        }

        \App\Models\Event::create([
            'establishment_id' => $est->id,
            'type' => 'delivery.' . $data['status'],
            'payload' => ['delivery_id' => $delivery->id],
        ]);

        return back()->with('success', 'Statut de livraison mis à jour.');
    }

    // ===== Tarification dynamique (IA-10) =====
    public function storePriceRule(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'product_id' => 'nullable|exists:products,id',
            'day_of_week' => 'nullable|string|max:16',
            'start_time' => 'nullable|date_format:H:i',
            'end_time' => 'nullable|date_format:H:i|after:start_time',
            'discount_percent' => 'required|numeric|min:0|max:90',
        ]);
        $data['establishment_id'] = $est->id;
        $data['day_of_week'] = $data['day_of_week'] ?? 'all';
        PriceRule::create($data);
        return back()->with('success', 'Règle de prix ajoutée.');
    }

    public function togglePriceRule(PriceRule $rule)
    {
        $est = $this->establishment();
        abort_unless($rule->establishment_id === $est->id, 403);
        $rule->update(['is_active' => ! $rule->is_active]);
        return back()->with('success', 'Règle mise à jour.');
    }

    // ===== Mode événement (INN-06) =====
    public function storeEvent(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'starts_at' => 'nullable|date',
            'ends_at' => 'nullable|date|after:starts_at',
            'entry_fee' => 'nullable|numeric|min:0',
        ]);
        $data['establishment_id'] = $est->id;
        $data['entry_fee'] = $data['entry_fee'] ?? 0;
        EventModel::create($data);
        return back()->with('success', 'Événement créé.');
    }

    public function toggleEvent(EventModel $event)
    {
        $est = $this->establishment();
        abort_unless($event->establishment_id === $est->id, 403);
        // Désactiver les autres
        EventModel::where('establishment_id', $est->id)->update(['is_active' => false]);
        $event->update(['is_active' => ! $event->is_active]);
        return back()->with('success', 'Mode événement mis à jour.');
    }

    public function addEventProduct(Request $request, EventModel $event)
    {
        $est = $this->establishment();
        abort_unless($event->establishment_id === $est->id, 403);
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'price' => 'nullable|numeric|min:0',
            'is_included' => 'nullable|boolean',
        ]);
        EventModelProduct::create([
            'event_model_id' => $event->id,
            'product_id' => $data['product_id'],
            'price' => $data['price'] ?? null,
            'is_included' => $data['is_included'] ?? false,
        ]);
        return back()->with('success', 'Produit ajouté au menu événement.');
    }
}
