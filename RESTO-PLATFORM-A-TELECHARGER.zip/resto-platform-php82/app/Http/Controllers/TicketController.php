<?php

namespace App\Http\Controllers;

use App\Models\Order;

class TicketController extends Controller
{
    // Reçu de caisse (client)
    public function receipt(Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        $order->load(['items.options', 'payments', 'table', 'user']);
        return view('tickets.receipt', compact('est', 'order'));
    }

    // Bon de commande cuisine (par poste)
    public function kitchen(Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        $order->load(['items.options', 'table', 'user']);
        return view('tickets.kitchen', compact('est', 'order'));
    }

    // Note provisoire (pré-addition)
    public function bill(Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        $order->load(['items.options', 'table', 'user']);
        return view('tickets.bill', compact('est', 'order'));
    }
}
