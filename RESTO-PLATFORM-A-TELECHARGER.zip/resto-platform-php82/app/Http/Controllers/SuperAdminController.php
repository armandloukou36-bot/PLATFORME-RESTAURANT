<?php

namespace App\Http\Controllers;

use App\Models\Establishment;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

/**
 * Console super-administrateur (SaaS).
 * Paramètre et crée les établissements + les comptes de leurs agents.
 */
class SuperAdminController extends Controller
{
    public function index()
    {
        $this->authorizeSuperAdmin();
        $establishments = Establishment::withCount('users')->orderBy('name')->get();
        return view('superadmin.index', compact('establishments'));
    }

    // ===== Établissements =====
    public function storeEstablishment(Request $request)
    {
        $this->authorizeSuperAdmin();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'legal_name' => 'nullable|string|max:255',
            'ncc' => 'nullable|string|max:64',
            'address' => 'nullable|string',
            'phone' => 'nullable|string|max:40',
            'email' => 'nullable|email',
            'country' => 'nullable|string|max:64',
            'currency' => 'nullable|string|max:8',
            'currency_symbol' => 'nullable|string|max:8',
            'timezone' => 'nullable|string|max:64',
        ]);
        $data['country'] = $data['country'] ?? 'Côte d\'Ivoire';
        $data['currency'] = $data['currency'] ?? 'FCFA';
        $data['currency_symbol'] = $data['currency_symbol'] ?? 'FCFA';
        $data['timezone'] = $data['timezone'] ?? 'Africa/Abidjan';
        $data['is_active'] = true;

        Establishment::create($data);
        return back()->with('success', 'Établissement créé.');
    }

    public function updateEstablishment(Request $request, Establishment $establishment)
    {
        $this->authorizeSuperAdmin();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'legal_name' => 'nullable|string|max:255',
            'ncc' => 'nullable|string|max:64',
            'address' => 'nullable|string',
            'phone' => 'nullable|string|max:40',
            'email' => 'nullable|email',
            'country' => 'nullable|string|max:64',
            'currency' => 'nullable|string|max:8',
            'currency_symbol' => 'nullable|string|max:8',
            'timezone' => 'nullable|string|max:64',
            'is_active' => 'nullable|boolean',
        ]);
        $data['is_active'] = $request->boolean('is_active');
        $establishment->update($data);
        return back()->with('success', 'Établissement mis à jour.');
    }

    public function uploadLogo(Request $request, Establishment $establishment)
    {
        $this->authorizeSuperAdmin();
        $request->validate(['logo' => 'required|image|mimes:png,jpg,jpeg,webp|max:2048']);

        $path = $request->file('logo')->store('logos', 'public');
        $establishment->update(['logo_path' => $path]);

        return back()->with('success', 'Logo mis à jour.');
    }

    // ===== Agents (comptes utilisateurs) =====
    public function agents(Establishment $establishment)
    {
        $this->authorizeSuperAdmin();
        $agents = User::where('establishment_id', $establishment->id)->orderBy('name')->get();
        return view('superadmin.agents', compact('establishment', 'agents'));
    }

    public function storeAgent(Request $request, Establishment $establishment)
    {
        $this->authorizeSuperAdmin();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'role' => 'required|in:manager,cashier,server,kitchen,bar,stock',
            'pin' => 'nullable|digits:4',
            'password' => 'required|min:6',
        ]);

        User::create([
            'establishment_id' => $establishment->id,
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'role' => $data['role'],
            'pin' => $data['pin'] ?? null,
            'is_active' => true,
        ]);

        return back()->with('success', 'Agent créé.');
    }

    public function toggleAgent(User $user)
    {
        $this->authorizeSuperAdmin();
        $user->update(['is_active' => ! $user->is_active]);
        return back()->with('success', 'Statut de l\'agent mis à jour.');
    }

    private function authorizeSuperAdmin(): void
    {
        if (auth()->user()->role !== 'superadmin') {
            abort(403, 'Accès réservé au super-administrateur.');
        }
    }
}
