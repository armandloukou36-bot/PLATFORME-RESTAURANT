<?php

namespace App\Http\Controllers;

use App\Services\CopilotService;
use Illuminate\Http\Request;

class CopilotController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }
        return view('copilot.index', compact('est'));
    }

    // Répond à une question (écrite ou transcrite par la voix)
    public function ask(Request $request)
    {
        $est = $this->establishment();
        abort_unless($est, 403);

        $data = $request->validate(['question' => 'required|string|max:500']);
        $answer = app(CopilotService::class)->answer($est->id, $data['question']);

        return response()->json(['answer' => $answer]);
    }
}
