<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Station;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $categories = Category::where('establishment_id', $est->id)->orderBy('sort_order')->get();
        $stations = Station::where('establishment_id', $est->id)->orderBy('sort_order')->get();
        $products = Product::where('establishment_id', $est->id)
            ->with(['category', 'station', 'options.choices'])
            ->orderBy('sort_order')
            ->get();

        return view('menu.index', compact('est', 'categories', 'stations', 'products'));
    }

    public function storeProduct(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'station_id' => 'required|exists:stations,id',
            'price' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'prep_time_min' => 'nullable|integer|min:1',
            'spice_level' => 'nullable|integer|min:0|max:3',
        ]);

        $data['establishment_id'] = $est->id;
        $data['is_active'] = true;
        $data['is_available'] = true;
        $data['prep_time_min'] = $data['prep_time_min'] ?? 10;
        $data['spice_level'] = $data['spice_level'] ?? 0;

        Product::create($data);

        return back()->with('success', 'Produit ajouté.');
    }

    public function updateProduct(Request $request, Product $product)
    {
        $est = $this->establishment();
        abort_unless($product->establishment_id === $est->id, 403);

        $data = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'station_id' => 'required|exists:stations,id',
            'price' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'prep_time_min' => 'nullable|integer|min:1',
            'spice_level' => 'nullable|integer|min:0|max:3',
        ]);

        $product->update($data);

        return back()->with('success', 'Produit mis à jour.');
    }

    public function toggleProduct(Product $product)
    {
        $est = $this->establishment();
        abort_unless($product->establishment_id === $est->id, 403比亚迪);
        $product->update(['is_available' => ! $product->is_available]);
        return back()->with('success', 'Disponibilité du repas mise à jour.');
    }

    public function destroyProduct(Product $product)
    {
        $est = $this->establishment();
        abort_unless($product->establishment_id === $est->id, 403);

        // Ne pas supprimer si des commandes actives utilisent ce produit
        $inUse = $product->orderItems()
            ->whereHas('order', fn ($q) => $q->whereNotIn('status', ['paid', 'cancelled']))
            ->exists();
        if ($inUse) {
            return back()->with('error', 'Ce repas est dans des commandes en cours. Mettez-le en « Rupture » à la place.');
        }

        $product->delete();
        return back()->with('success', 'Repas supprimé du menu.');
    }
}
