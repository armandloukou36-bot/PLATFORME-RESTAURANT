<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderItemOption;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Table;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PosController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $categories = Category::where('establishment_id', $est->id)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get();

        $products = Product::where('establishment_id', $est->id)
            ->where('is_active', true)
            ->with('options.choices')
            ->orderBy('sort_order')
            ->get();

        $tables = Table::where('establishment_id', $est->id)->get();

        return view('pos.index', compact('est', 'categories', 'products', 'tables'));
    }

    /**
     * Vente rapide en un SEUL appel : crée la commande, ajoute les articles
     * et encaisse dans une transaction. Évite les N appels séquentiels.
     */
    public function quickSale(Request $request)
    {
        $est = $this->establishment();

        $data = $request->validate([
            'channel' => 'required|in:dine_in,takeaway,delivery,counter',
            'table_id' => 'nullable|exists:tables,id',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'payments' => 'required|array|min:1',
            'payments.*.method' => 'required|in:cash,card,orange_money,mtn_momo,moov,wave,voucher,account',
            'payments.*.amount' => 'required|numeric|min:0',
            'payments.*.change_due' => 'nullable|numeric|min:0',
        ]);

        $order = DB::transaction(function () use ($est, $data) {
            // 1. Commande
            $order = Order::create([
                'establishment_id' => $est->id,
                'table_id' => $data['table_id'] ?? null,
                'user_id' => auth()->id(),
                'order_number' => $this->nextOrderNumber($est->id),
                'channel' => $data['channel'],
                'guest_count' => 1,
                'status' => 'open',
            ]);

            // 2. Articles (les produits doivent appartenir à l'établissement)
            $subtotal = 0;
            foreach ($data['items'] as $item) {
                $product = Product::where('id', $item['product_id'])
                    ->where('establishment_id', $est->id)
                    ->first();
                if (! $product) {
                    continue;
                }
                $order->items()->create([
                    'product_id' => $product->id,
                    'station_id' => $product->station_id,
                    'product_name' => $product->name,
                    'unit_price' => $product->price,
                    'quantity' => $item['quantity'],
                    'status' => 'served',
                    'wave' => 'main',
                ]);
                $subtotal += $product->price * $item['quantity'];
            }
            $order->update(['subtotal' => $subtotal, 'total' => $subtotal]);

            // 3. Paiements
            foreach ($data['payments'] as $p) {
                try {
                    $order->payments()->create([
                        'user_id' => auth()->id(),
                        'method' => $p['method'],
                        'amount' => $p['amount'],
                        'change_due' => $p['change_due'] ?? 0,
                    ]);
                } catch (\Throwable $e) {
                    // ignorer un doublon éventuel
                }
            }

            // 4. Finaliser : payée + déstockage + table
            $order->update(['status' => 'paid', 'paid_at' => now()]);
            app(\App\Services\StockService::class)->destockOrder($order);
            if ($order->table_id) {
                Table::where('id', $order->table_id)->update(['status' => 'to_clean']);
            }

            \App\Models\Event::create([
                'establishment_id' => $est->id,
                'type' => 'order.paid',
                'payload' => ['order_id' => $order->id, 'order_number' => $order->order_number],
            ]);

            return $order;
        });

        return response()->json(['order' => $order->load('items')]);
    }

    private function nextOrderNumber(int $estId): string
    {
        $last = Order::where('establishment_id', $estId)->max('id');
        return '#' . str_pad(($last ?? 0) + 1, 4, '0', STR_PAD_LEFT);
    }

    public function orders()
    {
        $est = $this->establishment();
        $orders = Order::where('establishment_id', $est->id)
            ->whereNotIn('status', ['cancelled'])
            ->with(['table', 'items', 'payments'])
            ->orderByDesc('created_at')
            ->limit(50)
            ->get();

        return response()->json($orders);
    }

    public function orderDetail(Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        return response()->json($order->load(['items.options', 'table', 'payments', 'user']));
    }
}
