<?php

namespace App\Http\Controllers;

use App\Models\Establishment;
use App\Models\Order;
use App\Models\Product;
use App\Models\Table;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    // Page menu public accessible par QR code de table
    public function menu(Request $request, string $qrToken)
    {
        $table = Table::where('qr_token', $qrToken)->with('establishment')->first();
        if (! $table) {
            abort(404, 'Table introuvable. Vérifiez le QR code.');
        }
        $est = $table->establishment;

        $categories = $est->categories()->where('is_active', true)->orderBy('sort_order')->get();
        $products = $est->products()
            ->where('is_active', true)
            ->where('is_available', true)
            ->with('options.choices', 'category')
            ->orderBy('sort_order')
            ->get();

        // Données JSON pour les recommandations client (IA-05)
        $productsJson = $products->map(fn ($p) => [
            'id' => $p->id,
            'name' => $p->name,
            'price' => (float) $p->price,
            'category' => $p->category?->name,
        ])->values()->toJson();

        return view('client.menu', compact('est', 'table', 'categories', 'products', 'productsJson'));
    }

    // Créer une commande depuis le client (table)
    public function store(Request $request, string $qrToken)
    {
        $table = Table::where('qr_token', $qrToken)->firstOrFail();
        $est = $table->establishment;

        $data = $request->validate([
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'items.*.notes' => 'nullable|string',
            'customer_name' => 'nullable|string|max:255',
            'customer_phone' => 'nullable|string|max:40',
        ]);

        // Réutiliser la commande ouverte de la table
        $order = Order::where('establishment_id', $est->id)
            ->where('table_id', $table->id)
            ->whereNotIn('status', ['paid', 'cancelled'])
            ->latest()
            ->first();

        if (! $order) {
            $order = Order::create([
                'establishment_id' => $est->id,
                'table_id' => $table->id,
                'order_number' => $this->nextOrderNumber($est->id),
                'channel' => 'dine_in',
                'guest_count' => 1,
                'customer_name' => $data['customer_name'] ?? null,
                'customer_phone' => $data['customer_phone'] ?? null,
                'status' => 'open',
            ]);
            $table->update(['status' => 'occupied']);
        }

        foreach ($data['items'] as $item) {
                    $product = Product::where('id', $item['product_id'])
                        ->where('establishment_id', $est->id)
                        ->first();
                    if (! $product) {
                        continue; // ignorer les produits d'un autre établissement
                    }
                    $order->items()->create([
                        'product_id' => $product->id,
                        'station_id' => $product->station_id,
                        'product_name' => $product->name,
                        'unit_price' => $product->price,
                        'quantity' => $item['quantity'],
                        'notes' => $item['notes'] ?? null,
                        'status' => 'new',
                        'wave' => 'main',
                    ]);
                }

                // Recalculer le total
                $order->load('items');
                $subtotal = $order->items->sum(fn ($i) => $i->lineTotal());
                $order->update(['subtotal' => $subtotal, 'total' => $subtotal]);

        // Envoyer en cuisine automatiquement
        $order->update(['status' => 'sent', 'sent_at' => now()]);
        \App\Models\Event::create([
            'establishment_id' => $est->id,
            'type' => 'order.sent',
            'payload' => [
                'order_id' => $order->id,
                'order_number' => $order->order_number,
                'table' => $table->name,
                'source' => 'client',
            ],
        ]);

        return response()->json([
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'status' => $order->status,
        ]);
    }

    // Suivi de commande en direct
    public function track(Request $request, int $orderId)
    {
        $order = Order::with(['items', 'table'])->findOrFail($orderId);
        return response()->json([
            'order_number' => $order->order_number,
            'status' => $order->status,
            'table' => $order->table?->name,
            'items' => $order->items->map(fn ($i) => [
                'name' => $i->product_name,
                'qty' => $i->quantity,
                'status' => $i->status,
            ]),
            'total' => $order->total,
        ]);
    }

    private function nextOrderNumber(int $estId): string
    {
        $last = Order::where('establishment_id', $estId)->max('id');
        return '#' . str_pad(($last ?? 0) + 1, 4, '0', STR_PAD_LEFT);
    }
}
