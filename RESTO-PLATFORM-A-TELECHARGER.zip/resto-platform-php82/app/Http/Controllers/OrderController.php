<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Event;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderItemOption;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Table;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    // Créer une commande (ou réutiliser la commande ouverte de la table)
    public function store(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'table_id' => 'nullable|exists:tables,id',
            'channel' => 'required|in:dine_in,takeaway,delivery,counter',
            'guest_count' => 'nullable|integer|min:1',
            'customer_name' => 'nullable|string|max:255',
            'customer_phone' => 'nullable|string|max:40',
            'note' => 'nullable|string',
        ]);

        // Réutiliser une commande ouverte existante sur cette table
                $order = null;
                if (! empty($data['table_id'])) {
                    $order = Order::where('establishment_id', $est->id)
                        ->where('table_id', $data['table_id'])
                        ->whereNotIn('status', ['paid', 'cancelled'])
                        ->latest()
                        ->first();
                }

                if (! $order) {
                    $order = Order::create([
                        'establishment_id' => $est->id,
                        'table_id' => $data['table_id'] ?? null,
                        'user_id' => auth()->id(),
                        'order_number' => $this->nextOrderNumber($est->id),
                        'channel' => $data['channel'],
                        'guest_count' => $data['guest_count'] ?? 1,
                        'customer_name' => $data['customer_name'] ?? null,
                        'customer_phone' => $data['customer_phone'] ?? null,
                        'note' => $data['note'] ?? null,
                        'status' => 'open',
                    ]);

                    if (! empty($data['table_id'])) {
                        Table::where('id', $data['table_id'])->update(['status' => 'occupied']);
                        $this->emit('table.status', ['table_id' => $data['table_id'], 'status' => 'occupied']);
                    }
                }

        return response()->json(['order' => $order->load('items')]);
    }

    // Ajouter un article à la commande
    public function addItem(Request $request, Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);

        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'notes' => 'nullable|string',
            'wave' => 'nullable|in:starter,main,dessert',
            'options' => 'nullable|array',
            'options.*.name' => 'required|string',
            'options.*.choice' => 'required|string',
            'options.*.price_delta' => 'nullable|numeric',
        ]);

        $product = Product::where('id', $data['product_id'])
            ->where('establishment_id', $order->establishment_id)
            ->firstOrFail();

        $item = OrderItem::create([
            'order_id' => $order->id,
            'product_id' => $product->id,
            'station_id' => $product->station_id,
            'product_name' => $product->name,
            'unit_price' => $product->price,
            'quantity' => $data['quantity'],
            'notes' => $data['notes'] ?? null,
            'status' => 'new',
            'wave' => $data['wave'] ?? 'main',
            'sort_order' => $order->items()->count(),
        ]);

        foreach ($data['options'] ?? [] as $opt) {
            OrderItemOption::create([
                'order_item_id' => $item->id,
                'option_name' => $opt['name'],
                'choice_name' => $opt['choice'],
                'price_delta' => $opt['price_delta'] ?? 0,
            ]);
        }

        $this->recalculate($order);

        return response()->json(['item' => $item->load('options'), 'order' => $order->fresh()->load('items')]);
    }

    // Envoyer la commande en cuisine / bar
    public function send(Request $request, Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);

        $order->update(['status' => 'sent', 'sent_at' => now()]);

        // Marquer les articles non servis comme "new" (prêts à être pris en cuisine)
        $order->items()->where('status', 'new')->update(['status' => 'new']);

        $this->emit('order.sent', [
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'table' => $order->table?->name,
            'items' => $order->items->map(fn ($i) => [
                'id' => $i->id,
                'name' => $i->product_name,
                'qty' => $i->quantity,
                'station' => $i->station?->name,
                'notes' => $i->notes,
            ]),
        ]);

        return response()->json(['order' => $order->fresh()->load('items')]);
    }

    // Mettre à jour le statut d'un article (new → in_progress → ready → served)
    public function updateItemStatus(Request $request, OrderItem $item)
    {
        $est = $this->establishment();
        abort_unless($item->order->establishment_id === $est->id, 403);

        $data = $request->validate(['status' => 'required|in:new,in_progress,ready,served,cancelled']);
        $item->update(['status' => $data['status']]);

        $this->emit('item.status', [
            'item_id' => $item->id,
            'order_id' => $item->order_id,
            'status' => $data['status'],
            'product_name' => $item->product_name,
        ]);

        // Si tous les articles sont servis → commande "served"
        $order = $item->order;
        if ($order->items()->whereNotIn('status', ['served', 'cancelled'])->count() === 0) {
            $order->update(['status' => 'served']);
            if ($order->table_id) {
                Table::where('id', $order->table_id)->update(['status' => 'bill_requested']);
                $this->emit('table.status', ['table_id' => $order->table_id, 'status' => 'bill_requested']);
            }
        }

        return response()->json(['ok' => true]);
    }

    // Paiement
    public function pay(Request $request, Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);

        $data = $request->validate([
                    'payments' => 'required|array|min:1',
                    'payments.*.method' => 'required|in:cash,card,orange_money,mtn_momo,moov,wave,voucher,account',
                    'payments.*.amount' => 'required|numeric|min:0',
                    'payments.*.change_due' => 'nullable|numeric|min:0',
                    'payments.*.reference' => 'nullable|string',
                    'customer_phone' => 'nullable|string|max:40',
                ]);

                DB::transaction(function () use ($order, $data) {
                    foreach ($data['payments'] as $p) {
                        Payment::create([
                            'order_id' => $order->id,
                            'user_id' => auth()->id(),
                            'method' => $p['method'],
                            'amount' => $p['amount'],
                            'change_due' => $p['change_due'] ?? 0,
                            'reference' => $p['reference'] ?? null,
                        ]);
                    }
                    $order->update(['status' => 'paid', 'paid_at' => now()]);
                    if ($order->table_id) {
                        Table::where('id', $order->table_id)->update(['status' => 'to_clean']);
                        $this->emit('table.status', ['table_id' => $order->table_id, 'status' => 'to_clean']);
                    }

                    // Déstockage automatique par fiche technique (STK-01)
                    app(\App\Services\StockService::class)->destockOrder($order);

                    // Fidélité : créditer les points si téléphone fourni (INN-01)
                    if (! empty($data['customer_phone'])) {
                        app(\App\Services\LoyaltyService::class)->earnPoints($order, $data['customer_phone']);
                    }
                });

        $this->emit('order.paid', ['order_id' => $order->id, 'order_number' => $order->order_number]);

        return response()->json(['order' => $order->fresh()->load('payments')]);
    }

    // Annulation (avec journalisation) — action sensible, exige un PIN
    public function cancel(Request $request, Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        $this->requirePin($request);

        $data = $request->validate(['reason' => 'required|string|max:255']);

        $order->update(['status' => 'cancelled']);
        if ($order->table_id) {
            Table::where('id', $order->table_id)->update(['status' => 'free']);
            $this->emit('table.status', ['table_id' => $order->table_id, 'status' => 'free']);
        }

        AuditLog::create([
            'establishment_id' => $est->id,
            'user_id' => auth()->id(),
            'action' => 'order.cancelled',
            'entity_type' => 'order',
            'entity_id' => $order->id,
            'details' => ['reason' => $data['reason'], 'order_number' => $order->order_number],
            'ip' => $request->ip(),
        ]);

        $this->emit('order.cancelled', ['order_id' => $order->id]);

        return response()->json(['ok' => true]);
    }

    // Remise
    public function discount(Request $request, Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        $this->requirePin($request);

        $data = $request->validate(['discount' => 'required|numeric|min:0']);
        $order->update(['discount' => $data['discount']]);
        $this->recalculate($order);

        AuditLog::create([
            'establishment_id' => $est->id,
            'user_id' => auth()->id(),
            'action' => 'order.discount',
            'entity_type' => 'order',
            'entity_id' => $order->id,
            'details' => ['discount' => $data['discount']],
            'ip' => $request->ip(),
        ]);

        return response()->json(['order' => $order->fresh()->load('items')]);
    }

    public function show(Order $order)
    {
        $est = $this->establishment();
        abort_unless($order->establishment_id === $est->id, 403);
        return response()->json($order->load(['items.options', 'table', 'payments']));
    }

    private function requirePin(Request $request): void
    {
        $pin = $request->input('pin');
        $user = auth()->user();

        // Les gérants/propriétaires sont autorisés ; sinon le PIN est obligatoire
        if ($user->isManager()) {
            return;
        }

        if (! $pin || ! hash_equals((string) $user->pin, (string) $pin)) {
            abort(403, 'Code PIN invalide requis pour cette action.');
        }
    }

    private function recalculate(Order $order): void
    {
        $subtotal = $order->items->sum(fn ($i) => $i->lineTotal());
        $order->update([
            'subtotal' => $subtotal,
            'total' => max(0, $subtotal - $order->discount),
        ]);
    }

    private function nextOrderNumber(int $estId): string
    {
        $last = Order::where('establishment_id', $estId)
            ->whereDate('created_at', today())
            ->max('id');
        return '#' . str_pad(($last ?? 0) + 1, 4, '0', STR_PAD_LEFT);
    }

    private function emit(string $type, array $payload): void
    {
        Event::create([
            'establishment_id' => $this->establishment()?->id,
            'type' => $type,
            'payload' => $payload,
        ]);
    }
}
