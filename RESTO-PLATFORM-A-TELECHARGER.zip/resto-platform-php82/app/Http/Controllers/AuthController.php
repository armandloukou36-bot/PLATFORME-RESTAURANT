<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $user = Auth::user();
            if (! $user->is_active) {
                Auth::logout();
                return back()->withErrors(['email' => 'Ce compte est désactivé.']);
            }
            $request->session()->regenerate();

            // Toujours rediriger vers l'interface de son rôle,
            // sauf si l'utilisateur avait demandé une URL interne (ex: consultation d'une page précise).
            $intended = $request->session()->pull('url.intended');
            $home = $this->homeFor($user);
            if ($intended && str_starts_with($intended, '/') && ! str_contains($intended, '/login')) {
                return redirect($intended);
            }
            return redirect($home);
        }

        return back()->withErrors(['email' => 'Identifiants incorrects.']);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }

    private function homeFor($user): string
    {
        return match ($user->role) {
            'superadmin' => '/admin',
            'kitchen' => '/kds',
            'bar' => '/kds?station=bar',
            'cashier' => '/pos',
            'server' => '/floor',
            default => '/dashboard',
        };
    }
}
