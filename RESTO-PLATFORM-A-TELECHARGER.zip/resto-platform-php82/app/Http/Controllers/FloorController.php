<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\Table;
use App\Models\Zone;

class FloorController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $zones = Zone::where('establishment_id', $est->id)
            ->with(['tables' => fn ($q) => $q->orderBy('name')])
            ->orderBy('sort_order')
            ->get();

        $categories = Category::where('establishment_id', $est->id)
            ->where('is_active', true)->orderBy('sort_order')->get();

        $products = Product::where('establishment_id', $est->id)
            ->where('is_active', true)->orderBy('sort_order')->get();

        // Statut réel des tables (commande active)
        $tables = Table::where('establishment_id', $est->id)->get();
        $activeOrders = Order::where('establishment_id', $est->id)
            ->whereNotIn('status', ['paid', 'cancelled'])
            ->with('items')
            ->get()
            ->groupBy('table_id');

        return view('floor.index', compact('est', 'zones', 'tables', 'activeOrders', 'categories', 'products'));
    }
}
