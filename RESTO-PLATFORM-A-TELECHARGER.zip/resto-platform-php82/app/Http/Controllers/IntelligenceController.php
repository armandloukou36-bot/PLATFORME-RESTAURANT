<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use App\Services\ForecastService;
use App\Services\MenuEngineeringService;
use App\Services\PurchaseSuggestionService;
use Illuminate\Http\Request;

class IntelligenceController extends Controller
{
    public function index(Request $request)
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        // IA-01 : prévisions
        $forecastService = app(ForecastService::class);
        $weekForecast = $forecastService->forecastWeek($est->id);

        // IA-02 : commandes fournisseurs suggérées
        $purchaseSuggestions = app(PurchaseSuggestionService::class)->suggest($est->id);

        // IA-06 : menu engineering
        $menuMatrix = app(MenuEngineeringService::class)->analyze($est->id);
        $menuGroups = collect($menuMatrix)->groupBy('category');

        return view('intelligence.index', compact('est', 'weekForecast', 'purchaseSuggestions', 'menuMatrix', 'menuGroups'));
    }

    // Réservations (INN-02)
    public function reservations()
    {
        $est = $this->establishment();
        $reservations = Reservation::where('establishment_id', $est->id)
            ->orderByDesc('reserved_at')
            ->limit(50)
            ->get();

        return view('intelligence.reservations', compact('est', 'reservations'));
    }

    public function storeReservation(Request $request)
    {
        $est = $this->establishment();
        $data = $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_phone' => 'required|string|max:40',
            'guests' => 'required|integer|min:1',
            'reserved_at' => 'required|date',
            'table_id' => 'nullable|exists:tables,id',
            'deposit' => 'nullable|numeric|min:0',
            'deposit_method' => 'nullable|string|max:24',
            'note' => 'nullable|string',
        ]);
        $data['establishment_id'] = $est->id;
        $data['status'] = 'confirmed';
        $data['deposit'] = $data['deposit'] ?? 0;

        Reservation::create($data);
        return back()->with('success', 'Réservation confirmée.');
    }

    public function updateReservation(Reservation $reservation, Request $request)
    {
        $est = $this->establishment();
        abort_unless($reservation->establishment_id === $est->id, 403);

        $data = $request->validate(['status' => 'required|in:pending,confirmed,cancelled,completed,no_show']);
        $reservation->update(['status' => $data['status']]);
        return back()->with('success', 'Statut mis à jour.');
    }
}
