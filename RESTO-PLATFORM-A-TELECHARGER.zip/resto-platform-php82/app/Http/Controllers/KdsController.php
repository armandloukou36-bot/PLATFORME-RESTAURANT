<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Station;

class KdsController extends Controller
{
    public function index()
    {
        $est = $this->establishment();
        if (! $est) {
            return redirect()->route('login');
        }

        $user = auth()->user();
        $stationFilter = request('station');

        // Postes visibles : si barman → bar, si cuisinier → cuisine, sinon tous
        $stations = Station::where('establishment_id', $est->id)->orderBy('sort_order')->get();

        $query = Order::where('establishment_id', $est->id)
            ->whereIn('status', ['sent', 'in_progress'])
            ->with(['items' => fn ($q) => $q->whereNotIn('status', ['served', 'cancelled'])->with('options', 'station'), 'table']);

        if ($stationFilter) {
            $query->whereHas('items', fn ($q) => $q->where('station_id', $stationFilter));
        } elseif ($user->role === 'bar') {
            $query->whereHas('items', fn ($q) => $q->whereHas('station', fn ($s) => $s->where('type', 'bar')));
        } elseif ($user->role === 'kitchen') {
            $query->whereHas('items', fn ($q) => $q->whereHas('station', fn ($s) => $s->where('type', 'kitchen')));
        }

        $orders = $query->orderBy('sent_at')->get();

        return view('kds.index', compact('est', 'stations', 'orders', 'stationFilter'));
    }
}
