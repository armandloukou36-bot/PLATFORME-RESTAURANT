<?php

namespace App\Services;

use Illuminate\Support\Carbon;

/**
 * Prévision des ventes (IA-01).
 * Algorithme simple et fiable, hors ligne :
 * moyenne mobile pondérée par jour de semaine + tendance sur 4 semaines.
 */
class ForecastService
{
    private const LOOKBACK_DAYS = 28; // 4 semaines d'historique

    /**
     * Prévoit le CA et le nombre de commandes pour un jour donné.
     */
    public function forecast(int $establishmentId, ?Carbon $target = null): array
    {
        $target = $target ?? Carbon::today();
        $dow = $target->dayOfWeek;

        $history = \App\Models\Order::where('establishment_id', $establishmentId)
            ->where('status', 'paid')
            ->where('created_at', '>=', $target->copy()->subDays(self::LOOKBACK_DAYS))
            ->where('created_at', '<', $target->copy()->addDay())
            ->get();

        // Regrouper par jour de la semaine (0=Dimanche ... 6=Samedi)
        $byDow = collect(range(0, 6))->mapWithKeys(fn ($d) => [$d => collect()]);
        $allDow = collect([]);

        foreach ($history as $o) {
            $day = $o->created_at->dayOfWeek;
            $byDow[$day]->push($o);
        }

        // Moyenne du même jour de semaine (poids 0.7) + moyenne globale (poids 0.3)
        $sameDow = $byDow[$dow];
        $avgSameDow = $sameDow->count() > 0 ? $sameDow->avg('total') : 0;
        $avgGlobal = $history->count() > 0 ? $history->avg('total') : 0;

        $samedowCount = $sameDow->count() > 0 ? $sameDow->avg(fn ($o) => 1) : 0;
        $countSameDow = $sameDow->count() > 0 ? $sameDow->count() / max(1, self::LOOKBACK_DAYS / 7) : 0;

        $revenueForecast = $avgSameDow * 0.7 + $avgGlobal * 0.3;
        $orderForecast = $countSameDow;

        return [
            'date' => $target->format('Y-m-d'),
            'revenue_forecast' => round($revenueForecast),
            'orders_forecast' => round($orderForecast),
            'confidence' => $history->count() > 10 ? 'haute' : ($history->count() > 3 ? 'moyenne' : 'faible'),
            'samples' => $sameDow->count(),
        ];
    }

    /**
     * Prévisions pour les 7 prochains jours.
     */
    public function forecastWeek(int $establishmentId): array
    {
        $out = [];
        for ($i = 1; $i <= 7; $i++) {
            $out[] = $this->forecast($establishmentId, Carbon::today()->addDays($i));
        }
        return $out;
    }
}
