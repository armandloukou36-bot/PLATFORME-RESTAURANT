<?php

namespace App\Services;

use App\Models\PriceRule;

/**
 * Tarification dynamique (IA-10).
 * Applique les happy hours : une règle horaire (ex. -20% entre 15h et 18h)
 * diminue le prix d'un produit si la règle correspond au jour/heure courant.
 */
class PricingService
{
    /**
     * Calcule le prix effectif d'un produit à un instant donné.
     */
    public function effectivePrice(\App\Models\Product $product, ?\DateTimeInterface $at = null): array
    {
        $at = $at ?? now();
        $basePrice = $product->price;
        $discount = 0;

        $rules = PriceRule::where('establishment_id', $product->establishment_id)
            ->where('is_active', true)
            ->where(function ($q) use ($product) {
                $q->whereNull('product_id')->orWhere('product_id', $product->id);
            })
            ->get();

        foreach ($rules as $rule) {
            if (! $this->ruleMatches($rule, $at)) {
                continue;
            }
            $discount = max($discount, $rule->discount_percent);
        }

        $effective = $basePrice * (1 - $discount / 100);

        return [
            'base_price' => $basePrice,
            'effective_price' => round($effective, 2),
            'discount_percent' => $discount,
            'is_discounted' => $discount > 0,
            'rule_name' => $discount > 0 ? $this->matchedRuleName($product, $at) : null,
        ];
    }

    private function ruleMatches(PriceRule $rule, \DateTimeInterface $at): bool
    {
        // Jour de la semaine
        $dayMap = [1 => 'monday', 7 => 'sunday', 5 => 'friday'];
        $today = strtolower($at->format('l'));
        if ($rule->day_of_week && $rule->day_of_week !== 'all' && $rule->day_of_week !== $today) {
            return false;
        }

        // Plage horaire
        if ($rule->start_time && $rule->end_time) {
            $time = $at->format('H:i');
            $start = substr($rule->start_time, 0, 5);
            $end = substr($rule->end_time, 0, 5);
            if ($time < $start || $time > $end) {
                return false;
            }
        }

        return true;
    }

    private function matchedRuleName(\App\Models\Product $product, \DateTimeInterface $at): ?string
    {
        $rule = PriceRule::where('establishment_id', $product->establishment_id)
            ->where('is_active', true)
            ->where(fn ($q) => $q->whereNull('product_id')->orWhere('product_id', $product->id))
            ->get()
            ->first(fn ($r) => $this->ruleMatches($r, $at));

        return $rule?->name;
    }
}
