<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\LoyaltyTransaction;
use App\Models\Order;

class LoyaltyService
{
    // Points gagnés par tranche de 1000 FCFA
    private const POINTS_PER_1000 = 1;

    /**
     * Crédite les points de fidélité d'un client à partir d'une commande payée (INN-01).
     */
    public function earnPoints(Order $order, ?string $phone = null): ?Customer
    {
        if (! $phone) {
            return null;
        }

        $customer = Customer::firstOrCreate(
            ['establishment_id' => $order->establishment_id, 'phone' => $phone],
            ['name' => $order->customer_name, 'loyalty_points' => 0, 'loyalty_tier' => 0, 'total_spent' => 0]
        );

        $points = (int) floor($order->total / 1000) * self::POINTS_PER_1000;

        $customer->increment('loyalty_points', $points);
        $customer->increment('total_spent', $order->total);
        $customer->update(['loyalty_tier' => $this->tierFor($customer->total_spent)]);

        LoyaltyTransaction::create([
            'establishment_id' => $order->establishment_id,
            'customer_id' => $customer->id,
            'order_id' => $order->id,
            'type' => 'earn',
            'points' => $points,
            'reason' => 'Commande ' . $order->order_number,
            'created_at' => now(),
        ]);

        return $customer;
    }

    private function tierFor(float $totalSpent): int
    {
        if ($totalSpent >= 200000) {
            return 2; // Or
        }
        if ($totalSpent >= 50000) {
            return 1; // Argent
        }
        return 0;
    }
}
