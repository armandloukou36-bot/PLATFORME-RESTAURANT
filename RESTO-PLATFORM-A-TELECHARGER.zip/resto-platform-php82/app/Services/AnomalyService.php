<?php

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Support\Carbon;

class AnomalyService
{
    /**
     * Détecte les anomalies de fraude interne (IA-03) :
     * - annulations après encaissement
     * - remises répétées
     * - écarts de stock inexpliqués
     */
    public function detect(int $establishmentId, int $hours = 24): array
    {
        $anomalies = [];
        $since = Carbon::now()->subHours($hours);

        // 1. Annulations après encaissement (commande payée puis annulée)
        $paidThenCancelled = Order::where('establishment_id', $establishmentId)
            ->where('status', 'cancelled')
            ->where('paid_at', '!=', null)
            ->where('created_at', '>=', $since)
            ->count();
        if ($paidThenCancelled > 0) {
            $anomalies[] = [
                'type' => 'danger',
                'title' => 'Annulations après encaissement',
                'detail' => "{$paidThenCancelled} commande(s) payée(s) puis annulée(s) — risque de fraude.",
            ];
        }

        // 2. Remises répétées (plus de 3 remises sur la période)
        $discounts = AuditLog::where('establishment_id', $establishmentId)
            ->where('action', 'order.discount')
            ->where('created_at', '>=', $since)
            ->count();
        if ($discounts > 3) {
            $anomalies[] = [
                'type' => 'warning',
                'title' => 'Remises répétées',
                'detail' => "{$discounts} remises appliquées en {$hours}h — vérifier les motifs.",
            ];
        }

        // 3. Annulations sans motif (trop nombreuses)
        $cancellations = Order::where('establishment_id', $establishmentId)
            ->where('status', 'cancelled')
            ->where('created_at', '>=', $since)
            ->count();
        if ($cancellations > 5) {
            $anomalies[] = [
                'type' => 'warning',
                'title' => 'Taux d\'annulation élevé',
                'detail' => "{$cancellations} annulations en {$hours}h.",
            ];
        }

        // 4. Paiements en espèces très élevés (potentiel blanchiment)
        $bigCash = Payment::whereHas('order', fn ($q) => $q->where('establishment_id', $establishmentId))
            ->where('method', 'cash')
            ->where('amount', '>', 100000)
            ->where('created_at', '>=', $since)
            ->count();
        if ($bigCash > 0) {
            $anomalies[] = [
                'type' => 'warning',
                'title' => 'Gros paiements en espèces',
                'detail' => "{$bigCash} paiement(s) en espèces > 100 000 FCFA.",
            ];
        }

        return $anomalies;
    }
}
