<?php

namespace App\Services;

use App\Models\Ingredient;
use App\Models\Order;
use App\Models\RecipeItem;
use App\Models\StockMovement;
use Illuminate\Support\Facades\DB;

class StockService
{
    /**
     * Déstocke automatiquement les ingrédients d'une commande payée
     * selon les fiches techniques (STK-01).
     */
    public function destockOrder(Order $order): void
    {
        DB::transaction(function () use ($order) {
            foreach ($order->items as $item) {
                if (! $item->product_id) {
                    continue;
                }
                $recipes = RecipeItem::where('product_id', $item->product_id)->get();
                foreach ($recipes as $recipe) {
                    $ingredient = Ingredient::find($recipe->ingredient_id);
                    if (! $ingredient) {
                        continue;
                    }
                    $qty = $recipe->quantity * $item->quantity;
                    $ingredient->decrement('stock_qty', $qty);

                    StockMovement::create([
                        'establishment_id' => $order->establishment_id,
                        'ingredient_id' => $ingredient->id,
                        'depot_id' => $ingredient->depot_id,
                        'type' => 'sale',
                        'quantity' => -$qty,
                        'unit_cost' => $ingredient->cost,
                        'reference' => $order->order_number,
                        'user_id' => $order->user_id,
                        'created_at' => now(),
                    ]);
                }
            }
        });
    }

    /**
     * Réception fournisseur : augmente le stock et journalise (STK-03).
     */
    public function receive(int $ingredientId, float $qty, float $unitCost, ?string $reference = null): void
    {
        DB::transaction(function () use ($ingredientId, $qty, $unitCost, $reference) {
            $ingredient = Ingredient::findOrFail($ingredientId);
            $ingredient->increment('stock_qty', $qty);
            $ingredient->update(['cost' => $unitCost]);

            StockMovement::create([
                'establishment_id' => $ingredient->establishment_id,
                'ingredient_id' => $ingredient->id,
                'depot_id' => $ingredient->depot_id,
                'type' => 'in',
                'quantity' => $qty,
                'unit_cost' => $unitCost,
                'reference' => $reference,
                'user_id' => auth()->id(),
                'created_at' => now(),
            ]);
        });
    }

    /**
     * Déclaration de perte (casse, périmé, repas personnel) — STK-06.
     */
    public function loss(int $ingredientId, float $qty, string $reason): void
    {
        DB::transaction(function () use ($ingredientId, $qty, $reason) {
            $ingredient = Ingredient::findOrFail($ingredientId);
            $ingredient->decrement('stock_qty', $qty);

            StockMovement::create([
                'establishment_id' => $ingredient->establishment_id,
                'ingredient_id' => $ingredient->id,
                'depot_id' => $ingredient->depot_id,
                'type' => 'loss',
                'quantity' => -$qty,
                'unit_cost' => $ingredient->cost,
                'reason' => $reason,
                'user_id' => auth()->id(),
                'created_at' => now(),
            ]);
        });
    }

    /**
     * Coût de revient d'un produit (somme des ingrédients de sa fiche) — STK-07.
     */
    public function productCost(int $productId): float
    {
        return RecipeItem::where('product_id', $productId)
            ->with('ingredient')
            ->get()
            ->sum(fn ($r) => $r->quantity * ($r->ingredient?->cost ?? 0));
    }
}
