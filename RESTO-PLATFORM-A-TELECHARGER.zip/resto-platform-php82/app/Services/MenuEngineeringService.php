<?php

namespace App\Services;

/**
 * Menu engineering (IA-06).
 * Classe chaque plat selon sa marge et sa popularité :
 * - Stars : marge forte + forte popularité
 * - Vaches à lait : marge forte + faible popularité
 * - Énigmes : marge faible + forte popularité
 * - Poids morts : marge faible + faible popularité
 */
class MenuEngineeringService
{
    public function analyze(int $establishmentId): array
    {
        // Ventes par produit (30 derniers jours)
        $rows = \DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.establishment_id', $establishmentId)
            ->where('orders.status', 'paid')
            ->whereDate('orders.created_at', '>=', now()->subDays(30))
            ->selectRaw('order_items.product_id, order_items.product_name, 
                        SUM(order_items.quantity) as qty, 
                        SUM(order_items.quantity * order_items.unit_price) as revenue')
            ->groupBy('order_items.product_id', 'order_items.product_name')
            ->get();

        if ($rows->isEmpty()) {
            return [];
        }

        // Coûts de revient
        $stockService = app(StockService::class);
        $products = \App\Models\Product::where('establishment_id', $establishmentId)->get();

        $items = [];
        foreach ($rows as $row) {
            $product = $products->firstWhere('id', $row->product_id);
            $cost = $product ? $stockService->productCost($product->id) : 0;
            $price = $product?->price ?? ($row->revenue / max(1, $row->qty));
            $margin = $price - $cost;
            $marginRate = $price > 0 ? $margin / $price : 0;

            $items[] = [
                'product_id' => $row->product_id,
                'name' => $row->product_name,
                'qty' => $row->qty,
                'revenue' => $row->revenue,
                'price' => $price,
                'cost' => $cost,
                'margin_rate' => round($marginRate, 2),
                'margin' => round($margin, 0),
            ];
        }

        $maxQty = max(1, collect($items)->max('qty'));
        $avgMargin = collect($items)->avg('margin_rate');

        foreach ($items as &$item) {
            $popularity = $item['qty'] / $maxQty; // 0..1
            $isPopular = $popularity >= 0.5;
            $isProfitable = $item['margin_rate'] >= $avgMargin;

            $item['category'] = match (true) {
                $isPopular && $isProfitable => 'star',
                ! $isPopular && $isProfitable => 'cash_cow',
                $isPopular && ! $isProfitable => 'puzzle',
                default => 'dog',
            };
        }
        unset($item);

        return $items;
    }
}
