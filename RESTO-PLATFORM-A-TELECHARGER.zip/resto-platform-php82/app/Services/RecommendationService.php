<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Collection;

/**
 * Recommandations au client (IA-05).
 * Suggère un accompagnement, une boisson ou un dessert selon la commande.
 */
class RecommendationService
{
    /**
     * @param Collection $cartProducts  Produits déjà dans le panier (avec category)
     */
    public function suggest(Collection $cartProducts, int $establishmentId): array
    {
        $available = Product::where('establishment_id', $establishmentId)
            ->where('is_active', true)
            ->where('is_available', true)
            ->with('category')
            ->get();

        $cartNames = $cartProducts->pluck('id');

        $hasStarter = $cartProducts->contains(fn ($p) => $p->category?->name === 'Entrées');
        $hasMain = $cartProducts->contains(fn ($p) => in_array($p->category?->name, ['Plats', 'Grillades', 'Poissons']));
        $hasDessert = $cartProducts->contains(fn ($p) => $p->category?->name === 'Desserts');
        $hasDrink = $cartProducts->contains(fn ($p) => in_array($p->category?->name, ['Boissons', 'Cocktails']));

        $suggestions = [];

        if ($hasMain && ! $hasDessert) {
            $dessert = $available->where('category.name', 'Desserts')->first();
            if ($dessert) {
                $suggestions[] = ['type' => 'dessert', 'label' => 'Dessert', 'product' => $dessert];
            }
        }

        if (! $hasDrink) {
            $drink = $available->where('category.name', 'Boissons')->first();
            if ($drink) {
                $suggestions[] = ['type' => 'drink', 'label' => 'Boisson', 'product' => $drink];
            }
        }

        if ($hasMain && ! $hasStarter) {
            $starter = $available->where('category.name', 'Entrées')->first();
            if ($starter) {
                $suggestions[] = ['type' => 'starter', 'label' => 'Entrée', 'product' => $starter];
            }
        }

        return $suggestions;
    }
}
