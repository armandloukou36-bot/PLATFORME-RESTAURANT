<?php

namespace App\Services;

use App\Models\Ingredient;

/**
 * Commande fournisseur suggérée (IA-02).
 * À partir des prévisions de ventes et du stock, suggère les quantités à commander
 * pour éviter les ruptures et le surstock.
 */
class PurchaseSuggestionService
{
    /**
     * Génère les suggestions d'achat pour les ingrédients sous le seuil.
     * targetDays = couverture de stock visée (en jours de consommation).
     */
    public function suggest(int $establishmentId, int $targetDays = 7): array
    {
        // Consommation moyenne par jour de chaque ingrédient (30 jours)
        $consumption = \DB::table('stock_movements')
            ->where('establishment_id', $establishmentId)
            ->where('type', 'sale')
            ->where('created_at', '>=', now()->subDays(30))
            ->selectRaw('ingredient_id, ABS(SUM(quantity)) as consumed')
            ->groupBy('ingredient_id')
            ->get()
            ->keyBy('ingredient_id');

        $ingredients = Ingredient::where('establishment_id', $establishmentId)
            ->with('depot')
            ->get();

        $suggestions = [];
        foreach ($ingredients as $ing) {
            $dailyUse = ($consumption[$ing->id]->consumed ?? 0) / 30;
            if ($dailyUse <= 0) {
                continue; // pas de consommation → pas de suggestion
            }

            $stockDays = $dailyUse > 0 ? $ing->stock_qty / $dailyUse : 999;
            $needed = $dailyUse * $targetDays;
            $toOrder = max(0, round($needed - $ing->stock_qty));

            if ($toOrder > 0) {
                $suggestions[] = [
                    'ingredient' => $ing->name,
                    'unit' => $ing->unit,
                    'stock_qty' => $ing->stock_qty,
                    'daily_use' => round($dailyUse, 2),
                    'stock_days' => round($stockDays, 1),
                    'target_days' => $targetDays,
                    'to_order' => $toOrder,
                    'depot' => $ing->depot?->name,
                ];
            }
        }

        // Trier par urgence (stock en jours croissant)
        usort($suggestions, fn ($a, $b) => $a['stock_days'] <=> $b['stock_days']);

        return $suggestions;
    }
}
