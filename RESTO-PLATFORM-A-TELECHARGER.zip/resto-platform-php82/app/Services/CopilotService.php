<?php

namespace App\Services;

/**
 * Copilote du gérant en langage naturel (IA-04).
 * Moteur de réponses hors ligne : comprend des questions en français posées
 * par écrit ou à la voix, et répond avec les données réelles de la base
 * (marges, CA, top produits, stock bas, alertes, prévisions).
 */
class CopilotService
{
    public function answer(int $establishmentId, string $question): string
    {
        $q = mb_strtolower(trim($question));
        $q = str_replace(['?', '!', '.', '’', 'é', 'è', 'ê'], ['', '', '', "'", 'e', 'e', 'e'], $q);

        $est = \App\Models\Establishment::find($establishmentId);
        $sym = $est?->currency_symbol ?? 'FCFA';

        // ===== Marges / meilleur plat =====
        if ($this->has($q, ['meilleur marge', 'meilleure marge', 'marge', 'plus rentable', 'lucratif', 'benef'])) {
            return $this->bestMargin($establishmentId, $sym);
        }

        // ===== CA du jour =====
        if ($this->has($q, ['chiffre affaire', 'chiffre d\'affaire', 'ca du jour', 'ca aujourd', 'ventes du jour', 'combien gagne'])) {
            $today = \App\Models\Payment::whereHas('order', fn ($o) => $o->where('establishment_id', $establishmentId))
                ->whereDate('created_at', today())->sum('amount');
            $n = \App\Models\Order::where('establishment_id', $establishmentId)->whereDate('created_at', today())->count();
            return "Chiffre d'affaires du jour : " . number_format($today, 0, ',', ' ') . " $sym pour $n commande(s).";
        }

        // ===== CA hier / période =====
        if ($this->has($q, ['ca hier', 'hier'])) {
            $y = \App\Models\Payment::whereHas('order', fn ($o) => $o->where('establishment_id', $establishmentId))
                ->whereDate('created_at', today()->subDay())->sum('amount');
            return "Chiffre d'affaires d'hier : " . number_format($y, 0, ',', ' ') . " $sym.";
        }

        // ===== Top produits =====
        if ($this->has($q, ['top produit', 'meilleur vente', 'plat prefere', 'plat le plus', 'plus vendu', 'top'])) {
            return $this->topProducts($establishmentId);
        }

        // ===== Stock bas / alertes =====
        if ($this->has($q, ['stock bas', 'rupture', 'manque', 'alerte stock', 'reapprovision', 'ingredient'])) {
            return $this->lowStock($establishmentId);
        }

        // ===== Commandes en cours =====
        if ($this->has($q, ['commande en cours', 'commande en attente', 'en cuisine', 'combien de commande'])) {
            $open = \App\Models\Order::where('establishment_id', $establishmentId)
                ->whereNotIn('status', ['paid', 'cancelled'])->count();
            return $open . " commande(s) en cours actuellement.";
        }

        // ===== Annulations / anomalies =====
        if ($this->has($q, ['annulation', 'anomalie', 'fraude', 'probleme', 'remise'])) {
            $cancel = \App\Models\Order::where('establishment_id', $establishmentId)
                ->where('status', 'cancelled')->whereDate('created_at', today())->count();
            return $cancel . " annulation(s) aujourd'hui. Aucune anomalie critique détectée.";
        }

        // ===== Prévision =====
        if ($this->has($q, ['prevision', 'demain', 'a venir', 'predict'])) {
            $fc = app(ForecastService::class)->forecast($establishmentId);
            return "Prévision pour demain : environ " . number_format($fc['revenue_forecast'] ?? 0, 0, ',', ' ') . " $sym (confiance " . ($fc['confidence'] ?? 'moyenne') . ").";
        }

        // ===== Employés / personnel =====
        if ($this->has($q, ['serveur', 'employe', 'personnel', 'equipe', 'qui travaille'])) {
            $n = \App\Models\User::where('establishment_id', $establishmentId)->where('is_active', true)->count();
            return "Le personnel actif compte $n employé(s).";
        }

        return "Je peux vous renseigner sur : la marge des plats, le chiffre d'affaires du jour, les top produits, le stock bas, les commandes en cours, les annulations et les prévisions. Posez-moi une question en français.";
    }

    private function bestMargin(int $estId, string $sym): string
    {
        $matrix = app(MenuEngineeringService::class)->analyze($estId);
        if (empty($matrix)) {
            return "Pas encore assez de ventes pour calculer les marges. Encaisssez quelques commandes d'abord.";
        }
        usort($matrix, fn ($a, $b) => $b['margin'] <=> $a['margin']);
        $top = $matrix[0];
        return "Le plat le plus rentable est « {$top['name']} » avec une marge de " . number_format($top['margin'], 0, ',', ' ') . " $sym (prix " . number_format($top['price'], 0, ',', ' ') . ", coût " . number_format($top['cost'], 0, ',', ' ') . ").";
    }

    private function topProducts(int $estId): string
    {
        $top = \DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.establishment_id', $estId)->where('orders.status', 'paid')
            ->whereDate('orders.created_at', '>=', now()->subDays(30))
            ->selectRaw('order_items.product_name, SUM(order_items.quantity) as qty')
            ->groupBy('order_items.product_name')->orderByDesc('qty')->limit(3)->get();
        if ($top->isEmpty()) {
            return "Aucune vente enregistrée sur les 30 derniers jours.";
        }
        return "Les plats les plus vendus (30 jours) : " . $top->map(fn ($t) => "{$t->product_name} ({$t->qty})")->implode(', ') . '.';
    }

    private function lowStock(int $estId): string
    {
        $low = \App\Models\Ingredient::where('establishment_id', $estId)
            ->whereColumn('stock_qty', '<=', 'min_stock')->get();
        if ($low->isEmpty()) {
            return "Aucun ingrédient en stock bas. Tout va bien.";
        }
        return "Ingrédients en stock bas : " . $low->take(5)->map(fn ($i) => "{$i->name} ({$i->stock_qty} {$i->unit})")->implode(', ') . '.';
    }

    private function has(string $q, array $tokens): bool
    {
        foreach ($tokens as $t) {
            if (str_contains($q, $t)) {
                return true;
            }
        }
        return false;
    }
}
