<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class CreateSuperAdmin extends Command
{
    protected $signature = 'superadmin:create {--email=admin@resto.ci} {--password=password}';

    protected $description = 'Crée ou met à jour le compte super-administrateur avec un mot de passe Bcrypt correct.';

    public function handle(): int
    {
        $email = $this->option('email');
        $password = $this->option('password');

        $user = User::where('email', $email)->first();

        if ($user) {
            $user->update([
                'role' => 'superadmin',
                'password' => $password, // Laravel hache automatiquement (cast 'hashed')
                'is_active' => true,
            ]);
            $this->info("Super-admin mis à jour : {$email}");
        } else {
            User::create([
                'establishment_id' => null,
                'name' => 'Super Admin',
                'email' => $email,
                'password' => $password,
                'role' => 'superadmin',
                'pin' => '0000',
                'is_active' => true,
            ]);
            $this->info("Super-admin créé : {$email}");
        }

        return self::SUCCESS;
    }
}
